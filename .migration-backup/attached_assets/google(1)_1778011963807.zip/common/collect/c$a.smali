.class Lcom/google/common/collect/c$a;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/Iterator;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/common/collect/c;->D0()Ljava/util/Iterator;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/Iterator<",
        "Ljava/util/Map$Entry<",
        "TK;TV;>;>;"
    }
.end annotation


# instance fields
.field a:Ljava/util/Map$Entry;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map$Entry<",
            "TK;TV;>;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation
.end field

.field final synthetic b:Ljava/util/Iterator;

.field final synthetic c:Lcom/google/common/collect/c;


# direct methods
.method constructor <init>(Lcom/google/common/collect/c;Ljava/util/Iterator;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010
        }
        names = {
            "this$0",
            "val$iterator"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/google/common/collect/c$a;->c:Lcom/google/common/collect/c;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput-object p2, p0, Lcom/google/common/collect/c$a;->b:Ljava/util/Iterator;

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public a()Ljava/util/Map$Entry;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map$Entry<",
            "TK;TV;>;"
        }
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "/ s@s~~of@@n~~~~~ @.i~~~b@~~@tSo@o~@~b M@@~ olf@ @l@u~@ Ko~o   @~ mvb@rd @~c4-   i1i@@ ~ yta@~~ "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/google/common/collect/c$a;->b:Ljava/util/Iterator;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x6

    check-cast v0, Ljava/util/Map$Entry;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    iput-object v0, p0, Lcom/google/common/collect/c$a;->a:Ljava/util/Map$Entry;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    new-instance v1, Lcom/google/common/collect/c$b;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget-object v2, p0, Lcom/google/common/collect/c$a;->c:Lcom/google/common/collect/c;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-direct {v1, v2, v0}, Lcom/google/common/collect/c$b;-><init>(Lcom/google/common/collect/c;Ljava/util/Map$Entry;)V

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x2

    return-object v1
.end method

.method public hasNext()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/common/collect/c$a;->b:Ljava/util/Iterator;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    return v0
.end method

.method public bridge synthetic next()Ljava/lang/Object;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/common/collect/c$a;->a()Ljava/util/Map$Entry;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x1

    return-object v0
.end method

.method public remove()V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/common/collect/c$a;->a:Ljava/util/Map$Entry;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget-object v1, p0, Lcom/google/common/collect/c$a;->b:Ljava/util/Iterator;

    const/4 v3, 0x3

    invoke-interface {v1}, Ljava/util/Iterator;->remove()V

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/google/common/collect/c$a;->c:Lcom/google/common/collect/c;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-static {v1, v0}, Lcom/google/common/collect/c;->A0(Lcom/google/common/collect/c;Ljava/lang/Object;)V

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/google/common/collect/c$a;->a:Ljava/util/Map$Entry;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-void

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    const-string v1, "  smnx  ttaiesanthce llocales( v))t rno  es(ctoolm"

    const-string/jumbo v1, "itsha rt(vcom t ono nextcleo)lsll ee)a cnal ts  (s"

    const/4 v3, 0x5

    const-string/jumbo v1, "iha ol(oe)x tcteoerltl  s l) el cnsmva noos(ea ttn"

    const-string/jumbo v1, "no calls to next() since the last call to remove()"

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    throw v0
.end method
