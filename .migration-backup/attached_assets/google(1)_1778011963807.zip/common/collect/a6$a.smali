.class Lcom/google/common/collect/a6$a;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/Iterator;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/common/collect/a6;->iterator()Ljava/util/Iterator;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/Iterator<",
        "TE;>;"
    }
.end annotation


# instance fields
.field a:I

.field b:I

.field c:I

.field final synthetic d:Lcom/google/common/collect/a6;


# direct methods
.method constructor <init>(Lcom/google/common/collect/a6;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            "this$0"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    iput-object p1, p0, Lcom/google/common/collect/a6$a;->d:Lcom/google/common/collect/a6;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-static {p1}, Lcom/google/common/collect/a6;->a(Lcom/google/common/collect/a6;)I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    iput v0, p0, Lcom/google/common/collect/a6$a;->a:I

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {p1}, Lcom/google/common/collect/a6;->o()I

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    iput p1, p0, Lcom/google/common/collect/a6$a;->b:I

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    const/4 p1, -0x1

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    iput p1, p0, Lcom/google/common/collect/a6$a;->c:I

    const/4 v1, 0x1

    move v2, v1

    return-void
.end method

.method private a()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/common/collect/a6$a;->d:Lcom/google/common/collect/a6;

    const/4 v3, 0x3

    invoke-static {v0}, Lcom/google/common/collect/a6;->a(Lcom/google/common/collect/a6;)I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    iget v1, p0, Lcom/google/common/collect/a6$a;->a:I

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-ne v0, v1, :cond_0

    return-void

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    new-instance v0, Ljava/util/ConcurrentModificationException;

    const/4 v3, 0x6

    invoke-direct {v0}, Ljava/util/ConcurrentModificationException;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    throw v0
.end method


# virtual methods
.method b()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget v0, p0, Lcom/google/common/collect/a6$a;->a:I

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    add-int/lit8 v0, v0, 0x20

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    iput v0, p0, Lcom/google/common/collect/a6$a;->a:I

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-void
.end method

.method public hasNext()Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget v0, p0, Lcom/google/common/collect/a6$a;->b:I

    const/4 v2, 0x4

    if-ltz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/4 v0, 0x0

    :goto_0
    const/4 v1, 0x2

    move v2, v1

    return v0
.end method

.method public next()Ljava/lang/Object;
    .locals 5
    .annotation runtime Lcom/google/common/collect/me;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TE;"
        }
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-direct {p0}, Lcom/google/common/collect/a6$a;->a()V

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {p0}, Lcom/google/common/collect/a6$a;->hasNext()Z

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x3

    if-eqz v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x3

    iget v0, p0, Lcom/google/common/collect/a6$a;->b:I

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    iput v0, p0, Lcom/google/common/collect/a6$a;->c:I

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/google/common/collect/a6$a;->d:Lcom/google/common/collect/a6;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-static {v1, v0}, Lcom/google/common/collect/a6;->b(Lcom/google/common/collect/a6;I)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    iget-object v1, p0, Lcom/google/common/collect/a6$a;->d:Lcom/google/common/collect/a6;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget v2, p0, Lcom/google/common/collect/a6$a;->b:I

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {v1, v2}, Lcom/google/common/collect/a6;->p(I)I

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x1

    iput v1, p0, Lcom/google/common/collect/a6$a;->b:I

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x7

    return-object v0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    new-instance v0, Ljava/util/NoSuchElementException;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-direct {v0}, Ljava/util/NoSuchElementException;-><init>()V

    const/4 v3, 0x7

    move v4, v3

    throw v0
.end method

.method public remove()V
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-direct {p0}, Lcom/google/common/collect/a6$a;->a()V

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x4

    iget v0, p0, Lcom/google/common/collect/a6$a;->c:I

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x1

    if-ltz v0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    const/4 v0, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    goto :goto_0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    const/4 v0, 0x0

    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-static {v0}, Lcom/google/common/collect/e4;->e(Z)V

    const/4 v4, 0x0

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/google/common/collect/a6$a;->b()V

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/google/common/collect/a6$a;->d:Lcom/google/common/collect/a6;

    const/4 v4, 0x4

    const/4 v3, 0x3

    iget v1, p0, Lcom/google/common/collect/a6$a;->c:I

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-static {v0, v1}, Lcom/google/common/collect/a6;->b(Lcom/google/common/collect/a6;I)Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Lcom/google/common/collect/a6;->remove(Ljava/lang/Object;)Z

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/google/common/collect/a6$a;->d:Lcom/google/common/collect/a6;

    const/4 v4, 0x4

    iget v1, p0, Lcom/google/common/collect/a6$a;->b:I

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget v2, p0, Lcom/google/common/collect/a6$a;->c:I

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {v0, v1, v2}, Lcom/google/common/collect/a6;->d(II)I

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x7

    iput v0, p0, Lcom/google/common/collect/a6$a;->b:I

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/4 v0, -0x1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    iput v0, p0, Lcom/google/common/collect/a6$a;->c:I

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x0

    return-void
.end method
