.class final Lcom/google/common/collect/gg;
.super Ljava/lang/Object;


# annotations
.annotation runtime Lcom/google/common/collect/d7;
.end annotation

.annotation build Lx4/b;
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method

.method public static a(Ljava/util/SortedSet;)Ljava/util/Comparator;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "sortedSet"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/util/SortedSet<",
            "TE;>;)",
            "Ljava/util/Comparator<",
            "-TE;>;"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-interface {p0}, Ljava/util/SortedSet;->comparator()Ljava/util/Comparator;

    move-result-object p0

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x0

    if-nez p0, :cond_0

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-static {}, Lcom/google/common/collect/le;->A()Lcom/google/common/collect/le;

    move-result-object p0

    :cond_0
    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-object p0
.end method

.method public static b(Ljava/util/Comparator;Ljava/lang/Iterable;)Z
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "comparator",
            "elements"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Comparator<",
            "*>;",
            "Ljava/lang/Iterable<",
            "*>;)Z"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-static {p0}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-static {p1}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    instance-of v0, p1, Ljava/util/SortedSet;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    check-cast p1, Ljava/util/SortedSet;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-static {p1}, Lcom/google/common/collect/gg;->a(Ljava/util/SortedSet;)Ljava/util/Comparator;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    instance-of v0, p1, Lcom/google/common/collect/fg;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    if-eqz v0, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    check-cast p1, Lcom/google/common/collect/fg;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-interface {p1}, Lcom/google/common/collect/fg;->comparator()Ljava/util/Comparator;

    move-result-object p1

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-interface {p0, p1}, Ljava/util/Comparator;->equals(Ljava/lang/Object;)Z

    move-result p0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    return p0

    :cond_1
    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    const/4 p0, 0x0

    const/4 v1, 0x2

    move v2, v1

    return p0
.end method
