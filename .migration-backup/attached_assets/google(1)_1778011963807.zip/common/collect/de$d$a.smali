.class Lcom/google/common/collect/de$d$a;
.super Lcom/google/common/collect/e;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/common/collect/de$d;->e()Ljava/util/Iterator;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/common/collect/e<",
        "TE;>;"
    }
.end annotation


# instance fields
.field final synthetic c:Ljava/util/Iterator;

.field final synthetic d:Lcom/google/common/collect/de$d;


# direct methods
.method constructor <init>(Lcom/google/common/collect/de$d;Ljava/util/Iterator;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010
        }
        names = {
            "this$0",
            "val$iterator1"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/google/common/collect/de$d$a;->d:Lcom/google/common/collect/de$d;

    const/4 v1, 0x5

    const/4 v0, 0x3

    iput-object p2, p0, Lcom/google/common/collect/de$d$a;->c:Ljava/util/Iterator;

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-direct {p0}, Lcom/google/common/collect/e;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x7

    return-void
.end method


# virtual methods
.method protected a()Ljava/lang/Object;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TE;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    :cond_0
    const/4 v4, 0x6

    const-string/jumbo v3, "~@s~@ S l~- n4oi@~@ f~.t@@f@1o o~  oc t~~l/@os/@bM ~i  @~~ ~ ab@@@y~~~u~d~@b@r@ @@  K~~~i~@ @~ov"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/google/common/collect/de$d$a;->c:Ljava/util/Iterator;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    if-eqz v0, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/google/common/collect/de$d$a;->c:Ljava/util/Iterator;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x7

    check-cast v0, Lcom/google/common/collect/ae$a;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-interface {v0}, Lcom/google/common/collect/ae$a;->a()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-interface {v0}, Lcom/google/common/collect/ae$a;->getCount()I

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    iget-object v2, p0, Lcom/google/common/collect/de$d$a;->d:Lcom/google/common/collect/de$d;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    iget-object v2, v2, Lcom/google/common/collect/de$d;->d:Lcom/google/common/collect/ae;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-interface {v2, v1}, Lcom/google/common/collect/ae;->I1(Ljava/lang/Object;)I

    move-result v2

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    if-le v0, v2, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    return-object v1

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/google/common/collect/e;->b()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    return-object v0
.end method
