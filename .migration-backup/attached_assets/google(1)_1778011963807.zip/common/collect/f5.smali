.class public final synthetic Lcom/google/common/collect/f5;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Ljava/lang/Object;)Ljava/util/Spliterator$OfLong;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "n s~s @@~bm~f~~i@~ll1 @ -@~@~~o o@~ oa cob~ ~@~o ~ ~My   @/v  @ @K@rd@i @.tuS~~~~b~/fo4@@@~i@@t~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    check-cast p0, Ljava/util/Spliterator$OfLong;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-object p0
.end method
