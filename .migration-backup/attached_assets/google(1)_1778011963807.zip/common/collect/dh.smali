.class public final synthetic Lcom/google/common/collect/dh;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Ljava/lang/Object;)Ljava/util/stream/Stream;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " @siM.~l4@y@~~ ~r @~i @s@@l@~uc  d~K~ o~~at~  ~@~i@ @ ~o@  @ Son~b@1/f~-o@@/~mtb@@fo~vb~@ ~~ @~ "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    invoke-static {p0}, Ljava/util/stream/Stream;->of(Ljava/lang/Object;)Ljava/util/stream/Stream;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-object p0
.end method
