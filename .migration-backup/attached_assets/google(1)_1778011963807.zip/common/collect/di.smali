.class public final synthetic Lcom/google/common/collect/di;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a()Ljava/util/stream/DoubleStream;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "m~s@4 @i~~ ~@  @b/@ @~ f bdoKf@a~i@ @-o~os@ oc @~~~~v@~ ~rl~i  ~n@to.~ y~~l~@ tM@@@@@~o1@~/bu S "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    invoke-static {}, Ljava/util/stream/DoubleStream;->empty()Ljava/util/stream/DoubleStream;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-object v0
.end method
