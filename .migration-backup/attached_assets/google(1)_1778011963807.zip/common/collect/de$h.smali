.class abstract Lcom/google/common/collect/de$h;
.super Lcom/google/common/collect/uf$k;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/collect/de;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x408
    name = "h"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<E:",
        "Ljava/lang/Object;",
        ">",
        "Lcom/google/common/collect/uf$k<",
        "TE;>;"
    }
.end annotation


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/google/common/collect/uf$k;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public clear()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "f~s@@ oM/@~~ @i @i- ~ b@o~@@ v~ url@ton ~~  @~ ~db~4~~t~@s@~oS~o~ ~~@yf~@b1/o ml@ai@ @~~ @@ K.@c"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/google/common/collect/de$h;->f()Lcom/google/common/collect/ae;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-interface {v0}, Ljava/util/Collection;->clear()V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-void
.end method

.method public contains(Ljava/lang/Object;)Z
    .locals 3
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "o"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/common/collect/de$h;->f()Lcom/google/common/collect/ae;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-interface {v0, p1}, Lcom/google/common/collect/ae;->contains(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    return p1
.end method

.method public containsAll(Ljava/util/Collection;)Z
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "c"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Collection<",
            "*>;)Z"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/common/collect/de$h;->f()Lcom/google/common/collect/ae;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-interface {v0, p1}, Lcom/google/common/collect/ae;->containsAll(Ljava/util/Collection;)Z

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x3

    return p1
.end method

.method abstract f()Lcom/google/common/collect/ae;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/collect/ae<",
            "TE;>;"
        }
    .end annotation
.end method

.method public isEmpty()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/common/collect/de$h;->f()Lcom/google/common/collect/ae;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    return v0
.end method

.method public abstract iterator()Ljava/util/Iterator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Iterator<",
            "TE;>;"
        }
    .end annotation
.end method

.method public remove(Ljava/lang/Object;)Z
    .locals 4
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "o"
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/common/collect/de$h;->f()Lcom/google/common/collect/ae;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    const v1, 0x7fffffff

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-interface {v0, p1, v1}, Lcom/google/common/collect/ae;->S0(Ljava/lang/Object;I)I

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-lez p1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    const/4 p1, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    const/4 p1, 0x0

    :goto_0
    const/4 v2, 0x1

    move v3, v2

    return p1
.end method

.method public size()I
    .locals 3

    const/4 v1, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/common/collect/de$h;->f()Lcom/google/common/collect/ae;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x2

    invoke-interface {v0}, Lcom/google/common/collect/ae;->entrySet()Ljava/util/Set;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x0

    invoke-interface {v0}, Ljava/util/Set;->size()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    return v0
.end method
