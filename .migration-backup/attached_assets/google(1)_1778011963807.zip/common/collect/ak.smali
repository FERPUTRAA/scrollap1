.class public final synthetic Lcom/google/common/collect/ak;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:[Ljava/util/stream/DoubleStream;


# direct methods
.method public synthetic constructor <init>([Ljava/util/stream/DoubleStream;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/google/common/collect/ak;->a:[Ljava/util/stream/DoubleStream;

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@is~cf M t/-4 l~~   y~~~i~@@@l@afo ~i@~t@~~o @~ ~@@rb@@@omd @~.@o@b~ob  ~@s @~/ S~v~1 K~ ~@@un~o"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/common/collect/ak;->a:[Ljava/util/stream/DoubleStream;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-static {v0}, Lcom/google/common/collect/hk;->h([Ljava/util/stream/DoubleStream;)V

    const/4 v2, 0x3

    const/4 v1, 0x2

    return-void
.end method
