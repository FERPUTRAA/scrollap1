.class final Lcom/google/common/collect/de$g;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/Comparator;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/collect/de;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "g"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/Comparator<",
        "Lcom/google/common/collect/ae$a<",
        "*>;>;"
    }
.end annotation


# static fields
.field static final a:Lcom/google/common/collect/de$g;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v1, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    new-instance v0, Lcom/google/common/collect/de$g;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-direct {v0}, Lcom/google/common/collect/de$g;-><init>()V

    const/4 v2, 0x3

    sput-object v0, Lcom/google/common/collect/de$g;->a:Lcom/google/common/collect/de$g;

    const/4 v2, 0x0

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public a(Lcom/google/common/collect/ae$a;Lcom/google/common/collect/ae$a;)I
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "entry1",
            "entry2"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/collect/ae$a<",
            "*>;",
            "Lcom/google/common/collect/ae$a<",
            "*>;)I"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-interface {p2}, Lcom/google/common/collect/ae$a;->getCount()I

    move-result p2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-interface {p1}, Lcom/google/common/collect/ae$a;->getCount()I

    move-result p1

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x6

    sub-int/2addr p2, p1

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x5

    return p2
.end method

.method public bridge synthetic compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "entry1",
            "entry2"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x5

    check-cast p1, Lcom/google/common/collect/ae$a;

    const/4 v1, 0x0

    check-cast p2, Lcom/google/common/collect/ae$a;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-virtual {p0, p1, p2}, Lcom/google/common/collect/de$g;->a(Lcom/google/common/collect/ae$a;Lcom/google/common/collect/ae$a;)I

    move-result p1

    const/4 v1, 0x2

    const/4 v0, 0x2

    return p1
.end method
