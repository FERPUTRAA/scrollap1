.class abstract Lcom/google/common/collect/d9$e;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/Iterator;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/collect/d9;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x400
    name = "e"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Ljava/util/Iterator<",
        "TT;>;"
    }
.end annotation


# instance fields
.field a:Lcom/google/common/collect/d9$b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/collect/d9$b<",
            "TK;TV;>;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation
.end field

.field b:Lcom/google/common/collect/d9$b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/collect/d9$b<",
            "TK;TV;>;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation
.end field

.field c:I

.field d:I

.field final synthetic e:Lcom/google/common/collect/d9;


# direct methods
.method constructor <init>(Lcom/google/common/collect/d9;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            "this$0"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    iput-object p1, p0, Lcom/google/common/collect/d9$e;->e:Lcom/google/common/collect/d9;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-static {p1}, Lcom/google/common/collect/d9;->d(Lcom/google/common/collect/d9;)Lcom/google/common/collect/d9$b;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/google/common/collect/d9$e;->a:Lcom/google/common/collect/d9$b;

    const/4 v2, 0x4

    const/4 v0, 0x0

    or-int/2addr v1, v0

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/google/common/collect/d9$e;->b:Lcom/google/common/collect/d9$b;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-static {p1}, Lcom/google/common/collect/d9;->e(Lcom/google/common/collect/d9;)I

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    iput v0, p0, Lcom/google/common/collect/d9$e;->c:I

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {p1}, Lcom/google/common/collect/d9;->size()I

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x6

    iput p1, p0, Lcom/google/common/collect/d9$e;->d:I

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-void
.end method


# virtual methods
.method abstract a(Lcom/google/common/collect/d9$b;)Ljava/lang/Object;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "entry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/collect/d9$b<",
            "TK;TV;>;)TT;"
        }
    .end annotation
.end method

.method public hasNext()Z
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "otsSb~ @fy~@ . ~@ ~fadtu~@@@m~~1~b~ o@@vib o4@@~ ~  @cr~  ~@@n@i@-~@ @o~M~l/@@~ ~s i~o@~~ lo/  ~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/common/collect/d9$e;->e:Lcom/google/common/collect/d9;

    const/4 v2, 0x4

    move v3, v2

    invoke-static {v0}, Lcom/google/common/collect/d9;->e(Lcom/google/common/collect/d9;)I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    iget v1, p0, Lcom/google/common/collect/d9$e;->c:I

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-ne v0, v1, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/common/collect/d9$e;->a:Lcom/google/common/collect/d9$b;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget v0, p0, Lcom/google/common/collect/d9$e;->d:I

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-lez v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    const/4 v0, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    return v0

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    new-instance v0, Ljava/util/ConcurrentModificationException;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-direct {v0}, Ljava/util/ConcurrentModificationException;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    throw v0
.end method

.method public next()Ljava/lang/Object;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/google/common/collect/d9$e;->hasNext()Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    move v3, v2

    iget-object v0, p0, Lcom/google/common/collect/d9$e;->a:Lcom/google/common/collect/d9$b;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    iget-object v1, v0, Lcom/google/common/collect/d9$b;->nextInKeyInsertionOrder:Lcom/google/common/collect/d9$b;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    iput-object v1, p0, Lcom/google/common/collect/d9$e;->a:Lcom/google/common/collect/d9$b;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/google/common/collect/d9$e;->b:Lcom/google/common/collect/d9$b;

    const/4 v3, 0x6

    const/4 v2, 0x4

    iget v1, p0, Lcom/google/common/collect/d9$e;->d:I

    const/4 v3, 0x3

    add-int/lit8 v1, v1, -0x1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    iput v1, p0, Lcom/google/common/collect/d9$e;->d:I

    const/4 v3, 0x0

    const/4 v2, 0x3

    invoke-virtual {p0, v0}, Lcom/google/common/collect/d9$e;->a(Lcom/google/common/collect/d9$b;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    return-object v0

    :cond_0
    const/4 v3, 0x1

    new-instance v0, Ljava/util/NoSuchElementException;

    const/4 v2, 0x7

    move v3, v2

    invoke-direct {v0}, Ljava/util/NoSuchElementException;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    throw v0
.end method

.method public remove()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/common/collect/d9$e;->e:Lcom/google/common/collect/d9;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-static {v0}, Lcom/google/common/collect/d9;->e(Lcom/google/common/collect/d9;)I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x3

    iget v1, p0, Lcom/google/common/collect/d9$e;->c:I

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-ne v0, v1, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/common/collect/d9$e;->b:Lcom/google/common/collect/d9$b;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/google/common/collect/d9$e;->e:Lcom/google/common/collect/d9;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-static {v1, v0}, Lcom/google/common/collect/d9;->f(Lcom/google/common/collect/d9;Lcom/google/common/collect/d9$b;)V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/google/common/collect/d9$e;->e:Lcom/google/common/collect/d9;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-static {v0}, Lcom/google/common/collect/d9;->e(Lcom/google/common/collect/d9;)I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    iput v0, p0, Lcom/google/common/collect/d9$e;->c:I

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    const/4 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/google/common/collect/d9$e;->b:Lcom/google/common/collect/d9$b;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-void

    :cond_0
    const/4 v3, 0x6

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v3, 0x1

    const-string v1, "a(emetl)o ototvt ss tamsll nrnsllcc xnh  )aiec  e("

    const-string/jumbo v1, "r stm) eotste ox t(anniocl ssc lt (l acalhelov)e n"

    const/4 v3, 0x6

    const-string v1, " lisoestloooalltva s  e t)(e  ctn ce)xrmnct(ne hoa"

    const-string/jumbo v1, "no calls to next() since the last call to remove()"

    const/4 v3, 0x3

    const/4 v2, 0x6

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    throw v0

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    new-instance v0, Ljava/util/ConcurrentModificationException;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-direct {v0}, Ljava/util/ConcurrentModificationException;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    throw v0
.end method
