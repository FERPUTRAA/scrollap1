.class public final synthetic Lcom/google/common/collect/bj;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(J)Ljava/util/stream/LongStream;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~bs~m@1 s@@@no c~@a b~ iK@ ~ ~o ~~~~ @~  /or y~~/4f@@@ @~ o-lt @Mti@~f@u@v ~b.@@~iol~S~od@ ~@@~~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    invoke-static {p0, p1}, Ljava/util/stream/LongStream;->of(J)Ljava/util/stream/LongStream;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-object p0
.end method
