.class public final synthetic Lcom/google/common/collect/bi;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Ljava/util/OptionalDouble;)D
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~@s ~@~@o @s~ fiK~@ @S @ ~ @ @/~vo~~u /f4t~M~~o~@nm@di-~ brc.l i@ @~~t@~~ ~ ~@b~@ o lo1@o@b~ay @"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x6

    invoke-virtual {p0}, Ljava/util/OptionalDouble;->getAsDouble()D

    move-result-wide v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-wide v0
.end method
