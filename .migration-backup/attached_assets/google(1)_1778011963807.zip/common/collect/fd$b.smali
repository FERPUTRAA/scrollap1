.class public final Lcom/google/common/collect/fd$b;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/collect/fd;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<B:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# static fields
.field private static final d:I = -0x1


# instance fields
.field private final a:Ljava/util/Comparator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Comparator<",
            "TB;>;"
        }
    .end annotation
.end field

.field private b:I

.field private c:I


# direct methods
.method private constructor <init>(Ljava/util/Comparator;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "comparator"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Comparator<",
            "TB;>;)V"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    const/4 v0, -0x1

    const/4 v2, 0x2

    const/4 v1, 0x0

    iput v0, p0, Lcom/google/common/collect/fd$b;->b:I

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    const v0, 0x7fffffff

    const/4 v2, 0x1

    iput v0, p0, Lcom/google/common/collect/fd$b;->c:I

    const/4 v2, 0x7

    invoke-static {p1}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    check-cast p1, Ljava/util/Comparator;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    iput-object p1, p0, Lcom/google/common/collect/fd$b;->a:Ljava/util/Comparator;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-void
.end method

.method synthetic constructor <init>(Ljava/util/Comparator;Lcom/google/common/collect/fd$a;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-direct {p0, p1}, Lcom/google/common/collect/fd$b;-><init>(Ljava/util/Comparator;)V

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method

.method static synthetic a(Lcom/google/common/collect/fd$b;)Lcom/google/common/collect/le;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "f~s .@~o i @-~~@@/~@i@~ 1m~@riM@~@lb/tf~ l S~c  o@@~~~K@~~~@ @ 4od v ~@a~  bs~t~  n~~ubooo@@@@@ "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x3

    invoke-direct {p0}, Lcom/google/common/collect/fd$b;->g()Lcom/google/common/collect/le;

    move-result-object p0

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-object p0
.end method

.method static synthetic b(Lcom/google/common/collect/fd$b;)I
    .locals 2

    const/4 v1, 0x4

    iget p0, p0, Lcom/google/common/collect/fd$b;->c:I

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x5

    return p0
.end method

.method private g()Lcom/google/common/collect/le;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:TB;>()",
            "Lcom/google/common/collect/le<",
            "TT;>;"
        }
    .end annotation

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/common/collect/fd$b;->a:Ljava/util/Comparator;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-static {v0}, Lcom/google/common/collect/le;->i(Ljava/util/Comparator;)Lcom/google/common/collect/le;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-object v0
.end method


# virtual methods
.method public c()Lcom/google/common/collect/fd;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:TB;>()",
            "Lcom/google/common/collect/fd<",
            "TT;>;"
        }
    .end annotation

    const/4 v2, 0x7

    invoke-static {}, Ljava/util/Collections;->emptySet()Ljava/util/Set;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {p0, v0}, Lcom/google/common/collect/fd$b;->d(Ljava/lang/Iterable;)Lcom/google/common/collect/fd;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-object v0
.end method

.method public d(Ljava/lang/Iterable;)Lcom/google/common/collect/fd;
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "initialContents"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:TB;>(",
            "Ljava/lang/Iterable<",
            "+TT;>;)",
            "Lcom/google/common/collect/fd<",
            "TT;>;"
        }
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x6

    new-instance v0, Lcom/google/common/collect/fd;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    iget v1, p0, Lcom/google/common/collect/fd$b;->b:I

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget v2, p0, Lcom/google/common/collect/fd$b;->c:I

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-static {v1, v2, p1}, Lcom/google/common/collect/fd;->p(IILjava/lang/Iterable;)I

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    const/4 v2, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-direct {v0, p0, v1, v2}, Lcom/google/common/collect/fd;-><init>(Lcom/google/common/collect/fd$b;ILcom/google/common/collect/fd$a;)V

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x3

    if-eqz v1, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Lcom/google/common/collect/fd;->offer(Ljava/lang/Object;)Z

    const/4 v4, 0x3

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    return-object v0
.end method

.method public e(I)Lcom/google/common/collect/fd$b;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "expectedSize"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Lcom/google/common/collect/fd$b<",
            "TB;>;"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    if-ltz p1, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-static {v0}, Lcom/google/common/base/u0;->d(Z)V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    iput p1, p0, Lcom/google/common/collect/fd$b;->b:I

    const/4 v2, 0x4

    return-object p0
.end method

.method public f(I)Lcom/google/common/collect/fd$b;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "maximumSize"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Lcom/google/common/collect/fd$b<",
            "TB;>;"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    if-lez p1, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-static {v0}, Lcom/google/common/base/u0;->d(Z)V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    iput p1, p0, Lcom/google/common/collect/fd$b;->c:I

    const/4 v2, 0x4

    return-object p0
.end method
