.class public final synthetic Lcom/google/common/collect/ej;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(D)Ljava/util/OptionalDouble;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~~s~@i 1o o @s@K@ d @b/-c~~u nt @l/y@~o ~b~~  ~4f@@@@@o@@b   @v~~romi~M t@~@So@~f~~~i ~ .@@ l~~a"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    invoke-static {p0, p1}, Ljava/util/OptionalDouble;->of(D)Ljava/util/OptionalDouble;

    move-result-object p0

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-object p0
.end method
