.class public final synthetic Lcom/google/common/collect/dl;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/function/BinaryOperator;


# instance fields
.field public final synthetic a:Ljava/util/function/BinaryOperator;


# direct methods
.method public synthetic constructor <init>(Ljava/util/function/BinaryOperator;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/google/common/collect/dl;->a:Ljava/util/function/BinaryOperator;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public final apply(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " ~s.~@ ~y@ol @iK/i@@s~   @@@c~~v~o  4@~@bn~~ @@1~a~S-@~ ~dl~b t~~f~ M@om~ @f u@@~b@i@~oo  / @o~t"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/common/collect/dl;->a:Ljava/util/function/BinaryOperator;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    check-cast p1, Lcom/google/common/collect/ol$b;

    check-cast p2, Lcom/google/common/collect/ol$b;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-static {v0, p1, p2}, Lcom/google/common/collect/ol;->d(Ljava/util/function/BinaryOperator;Lcom/google/common/collect/ol$b;Lcom/google/common/collect/ol$b;)Lcom/google/common/collect/ol$b;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object p1
.end method
