.class final Lcom/google/common/collect/e7$b;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/io/Serializable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/collect/e7;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<C::",
        "Ljava/lang/Comparable;",
        ">",
        "Ljava/lang/Object;",
        "Ljava/io/Serializable;"
    }
.end annotation

.annotation build Lx4/c;
.end annotation

.annotation build Lx4/d;
.end annotation


# static fields
.field private static final serialVersionUID:J


# instance fields
.field private final domain:Lcom/google/common/collect/c7;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/collect/c7<",
            "TC;>;"
        }
    .end annotation
.end field


# direct methods
.method private constructor <init>(Lcom/google/common/collect/c7;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "domain"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/collect/c7<",
            "TC;>;)V"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/google/common/collect/e7$b;->domain:Lcom/google/common/collect/c7;

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/common/collect/c7;Lcom/google/common/collect/e7$a;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-direct {p0, p1}, Lcom/google/common/collect/e7$b;-><init>(Lcom/google/common/collect/c7;)V

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method

.method private readResolve()Ljava/lang/Object;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~os ~4 o on@@@@i @~~l @@~K~r~u@i~i@ b@~ fl M~.a  @om@c@~f-t @b~~/  ~@@@b / tds~o~S~@~~~yo@1~~ @ "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    new-instance v0, Lcom/google/common/collect/e7;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/google/common/collect/e7$b;->domain:Lcom/google/common/collect/c7;

    const/4 v3, 0x5

    invoke-direct {v0, v1}, Lcom/google/common/collect/e7;-><init>(Lcom/google/common/collect/c7;)V

    const/4 v3, 0x1

    const/4 v2, 0x5

    return-object v0
.end method
