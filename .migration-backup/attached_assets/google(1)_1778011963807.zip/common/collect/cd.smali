.class public final synthetic Lcom/google/common/collect/cd;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/function/Consumer;


# instance fields
.field public final synthetic a:Lcom/google/common/collect/uc$d0;

.field public final synthetic b:Ljava/util/function/BiConsumer;


# direct methods
.method public synthetic constructor <init>(Lcom/google/common/collect/uc$d0;Ljava/util/function/BiConsumer;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/google/common/collect/cd;->a:Lcom/google/common/collect/uc$d0;

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput-object p2, p0, Lcom/google/common/collect/cd;->b:Ljava/util/function/BiConsumer;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public final accept(Ljava/lang/Object;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@~s@~@~~ a@f s~v4@i y~b~b.ct  @~@om~@~dol@ ~-ro ~~ @1S  lu   o@@~@~~~o~/i/t @@~ @@@ ~Mi@Kn bo~f@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/google/common/collect/cd;->a:Lcom/google/common/collect/uc$d0;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    iget-object v1, p0, Lcom/google/common/collect/cd;->b:Ljava/util/function/BiConsumer;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-static {v0, v1, p1}, Lcom/google/common/collect/uc$d0;->f(Lcom/google/common/collect/uc$d0;Ljava/util/function/BiConsumer;Ljava/lang/Object;)V

    const/4 v3, 0x7

    const/4 v2, 0x3

    return-void
.end method
