.class final Lcom/google/common/collect/cc;
.super Lcom/google/common/collect/w9;


# annotations
.annotation runtime Lcom/google/common/collect/d7;
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<K:",
        "Ljava/lang/Object;",
        "V:",
        "Ljava/lang/Object;",
        ">",
        "Lcom/google/common/collect/w9<",
        "TK;TV;>;"
    }
.end annotation

.annotation build Lx4/b;
    emulated = true
.end annotation


# instance fields
.field private final transient f:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "TK;TV;>;"
        }
    .end annotation
.end field

.field private final transient g:Lcom/google/common/collect/t9;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/collect/t9<",
            "Ljava/util/Map$Entry<",
            "TK;TV;>;>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Ljava/util/Map;Lcom/google/common/collect/t9;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "delegateMap",
            "entries"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "TK;TV;>;",
            "Lcom/google/common/collect/t9<",
            "Ljava/util/Map$Entry<",
            "TK;TV;>;>;)V"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-direct {p0}, Lcom/google/common/collect/w9;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/google/common/collect/cc;->f:Ljava/util/Map;

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x4

    iput-object p2, p0, Lcom/google/common/collect/cc;->g:Lcom/google/common/collect/t9;

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method

.method public static synthetic N(Ljava/util/function/BiConsumer;Ljava/util/Map$Entry;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~~s/fSb  oyo@a@d ~@f~m~@n@- ~Kt~b@~ 4@o@~ t@ @ @~ 1~c@o @ @i~~@lr@@  bul~s.~i/~~v ~ @~~o~ o i@~@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    invoke-static {p0, p1}, Lcom/google/common/collect/cc;->P(Ljava/util/function/BiConsumer;Ljava/util/Map$Entry;)V

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method

.method static O(I[Ljava/util/Map$Entry;Z)Lcom/google/common/collect/w9;
    .locals 11
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "n",
            "entryArray",
            "throwIfDuplicateKeys"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<K:",
            "Ljava/lang/Object;",
            "V:",
            "Ljava/lang/Object;",
            ">(I[",
            "Ljava/util/Map$Entry<",
            "TK;TV;>;Z)",
            "Lcom/google/common/collect/w9<",
            "TK;TV;>;"
        }
    .end annotation

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x6

    invoke-static {p0}, Lcom/google/common/collect/uc;->a0(I)Ljava/util/HashMap;

    move-result-object v0

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x5

    const/4 v1, 0x0

    const/4 v9, 0x6

    shr-int/2addr v10, v9

    const/4 v2, 0x3

    const/4 v2, 0x0

    move-object v4, v1

    move-object v4, v1

    move-object v4, v1

    move-object v4, v1

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x4

    move v3, v2

    move v3, v2

    const/4 v10, 0x1

    move v3, v2

    const/4 v9, 0x4

    move v10, v9

    move v5, v3

    move v5, v3

    :goto_0
    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x4

    if-ge v3, p0, :cond_3

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x6

    aget-object v6, p1, v3

    const/4 v9, 0x5

    move v10, v9

    invoke-static {v6}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x2

    check-cast v6, Ljava/util/Map$Entry;

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x7

    invoke-static {v6}, Lcom/google/common/collect/bf;->T(Ljava/util/Map$Entry;)Lcom/google/common/collect/x9;

    move-result-object v6

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x6

    aput-object v6, p1, v3

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-interface {v6}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v6

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x1

    aget-object v7, p1, v3

    const/4 v10, 0x7

    const/4 v9, 0x0

    invoke-interface {v7}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v7

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x3

    invoke-interface {v0, v6, v7}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v8

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x5

    if-eqz v8, :cond_2

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x0

    if-nez p2, :cond_1

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x1

    if-nez v4, :cond_0

    const/4 v10, 0x4

    const/4 v9, 0x4

    new-instance v4, Ljava/util/HashMap;

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x5

    invoke-direct {v4}, Ljava/util/HashMap;-><init>()V

    :cond_0
    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x5

    invoke-interface {v4, v6, v7}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x5

    add-int/lit8 v5, v5, 0x1

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x5

    goto :goto_1

    :cond_1
    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x5

    aget-object p0, p1, v3

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x5

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x6

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x2

    aget-object p1, p1, v3

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x3

    invoke-interface {p1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object p1

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x2

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    const/4 v9, 0x6

    const-string p1, "="

    const-string p1, "="

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x4

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x0

    invoke-virtual {p2, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x5

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x7

    const-string/jumbo p2, "yke"

    const-string/jumbo p2, "eyk"

    const/4 v10, 0x2

    const-string/jumbo p2, "key"

    const-string/jumbo p2, "key"

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x3

    invoke-static {p2, p0, p1}, Lcom/google/common/collect/w9;->e(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/IllegalArgumentException;

    move-result-object p0

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x1

    throw p0

    :cond_2
    :goto_1
    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x4

    add-int/lit8 v3, v3, 0x1

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x3

    goto/16 :goto_0

    :cond_3
    const/4 v10, 0x6

    if-eqz v4, :cond_7

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x6

    sub-int p2, p0, v5

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x5

    new-array p2, p2, [Ljava/util/Map$Entry;

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x6

    move v3, v2

    move v3, v2

    const/4 v10, 0x4

    move v3, v2

    move v3, v2

    :goto_2
    const/4 v10, 0x5

    if-ge v2, p0, :cond_6

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x4

    aget-object v5, p1, v2

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x2

    invoke-static {v5}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x2

    check-cast v5, Ljava/util/Map$Entry;

    const/4 v10, 0x4

    const/4 v9, 0x7

    invoke-interface {v5}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v6

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x0

    invoke-interface {v4, v6}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v7

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x2

    if-eqz v7, :cond_5

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x0

    invoke-interface {v4, v6}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x3

    if-nez v5, :cond_4

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x1

    goto :goto_3

    :cond_4
    const/4 v10, 0x1

    new-instance v7, Lcom/google/common/collect/x9;

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x1

    invoke-direct {v7, v6, v5}, Lcom/google/common/collect/x9;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v10, 0x2

    invoke-interface {v4, v6, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-object v5, v7

    move-object v5, v7

    move-object v5, v7

    move-object v5, v7

    :cond_5
    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x3

    add-int/lit8 v6, v3, 0x1

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x1

    aput-object v5, p2, v3

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x3

    move v3, v6

    move v3, v6

    const/4 v10, 0x5

    move v3, v6

    move v3, v6

    :goto_3
    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x1

    add-int/lit8 v2, v2, 0x1

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x5

    goto :goto_2

    :cond_6
    move-object p1, p2

    move-object p1, p2

    move-object p1, p2

    move-object p1, p2

    :cond_7
    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x7

    new-instance p2, Lcom/google/common/collect/cc;

    const/4 v10, 0x7

    invoke-static {p1, p0}, Lcom/google/common/collect/t9;->j([Ljava/lang/Object;I)Lcom/google/common/collect/t9;

    move-result-object p0

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x3

    invoke-direct {p2, v0, p0}, Lcom/google/common/collect/cc;-><init>(Ljava/util/Map;Lcom/google/common/collect/t9;)V

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x4

    return-object p2
.end method

.method private static synthetic P(Ljava/util/function/BiConsumer;Ljava/util/Map$Entry;)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-interface {p1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-interface {p1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-static {p0, v0, p1}, Lcom/google/common/collect/i;->a(Ljava/util/function/BiConsumer;Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-void
.end method


# virtual methods
.method public forEach(Ljava/util/function/BiConsumer;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "action"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/function/BiConsumer<",
            "-TK;-TV;>;)V"
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-static {p1}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/google/common/collect/cc;->g:Lcom/google/common/collect/t9;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    new-instance v1, Lcom/google/common/collect/bc;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-direct {v1, p1}, Lcom/google/common/collect/bc;-><init>(Ljava/util/function/BiConsumer;)V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Lcom/google/common/collect/t9;->forEach(Ljava/util/function/Consumer;)V

    const/4 v3, 0x3

    const/4 v2, 0x0

    return-void
.end method

.method public get(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "key"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            ")TV;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/common/collect/cc;->f:Ljava/util/Map;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-object p1
.end method

.method i()Lcom/google/common/collect/qa;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/collect/qa<",
            "Ljava/util/Map$Entry<",
            "TK;TV;>;>;"
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    new-instance v0, Lcom/google/common/collect/y9$b;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/google/common/collect/cc;->g:Lcom/google/common/collect/t9;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-direct {v0, p0, v1}, Lcom/google/common/collect/y9$b;-><init>(Lcom/google/common/collect/w9;Lcom/google/common/collect/t9;)V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-object v0
.end method

.method k()Lcom/google/common/collect/qa;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/collect/qa<",
            "TK;>;"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    new-instance v0, Lcom/google/common/collect/aa;

    invoke-direct {v0, p0}, Lcom/google/common/collect/aa;-><init>(Lcom/google/common/collect/w9;)V

    const/4 v1, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-object v0
.end method

.method n()Lcom/google/common/collect/n9;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/collect/n9<",
            "TV;>;"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    new-instance v0, Lcom/google/common/collect/da;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-direct {v0, p0}, Lcom/google/common/collect/da;-><init>(Lcom/google/common/collect/w9;)V

    const/4 v2, 0x3

    const/4 v1, 0x1

    return-object v0
.end method

.method s()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    return v0
.end method

.method public size()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/common/collect/cc;->g:Lcom/google/common/collect/t9;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {v0}, Ljava/util/AbstractCollection;->size()I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    return v0
.end method
