.class abstract Lcom/google/common/collect/de$i;
.super Lcom/google/common/collect/uf$k;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/collect/de;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x408
    name = "i"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<E:",
        "Ljava/lang/Object;",
        ">",
        "Lcom/google/common/collect/uf$k<",
        "Lcom/google/common/collect/ae$a<",
        "TE;>;>;"
    }
.end annotation


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/google/common/collect/uf$k;-><init>()V

    const/4 v0, 0x6

    move v1, v0

    return-void
.end method


# virtual methods
.method public clear()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " ts~db@~@f @@@@~fs~~~/.i@~o@~1 t~  M@@@~y@ o~ @ ib@  oa@b4u~~no~i~@@~~S ~Kvr@c o@ ~ ~o-~/l m@~ l"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/common/collect/de$i;->f()Lcom/google/common/collect/ae;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-interface {v0}, Ljava/util/Collection;->clear()V

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-void
.end method

.method public contains(Ljava/lang/Object;)Z
    .locals 5
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "o"
        }
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    instance-of v0, p1, Lcom/google/common/collect/ae$a;

    const/4 v3, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    const/4 v1, 0x0

    const/4 v4, 0x3

    if-eqz v0, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x0

    check-cast p1, Lcom/google/common/collect/ae$a;

    const/4 v4, 0x5

    invoke-interface {p1}, Lcom/google/common/collect/ae$a;->getCount()I

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x0

    if-gtz v0, :cond_0

    const/4 v3, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    return v1

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/google/common/collect/de$i;->f()Lcom/google/common/collect/ae;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-interface {p1}, Lcom/google/common/collect/ae$a;->a()Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-interface {v0, v2}, Lcom/google/common/collect/ae;->I1(Ljava/lang/Object;)I

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-interface {p1}, Lcom/google/common/collect/ae$a;->getCount()I

    move-result p1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    if-ne v0, p1, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x0

    const/4 v1, 0x1

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    return v1
.end method

.method abstract f()Lcom/google/common/collect/ae;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/collect/ae<",
            "TE;>;"
        }
    .end annotation
.end method

.method public remove(Ljava/lang/Object;)Z
    .locals 5
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "object"
        }
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x5

    instance-of v0, p1, Lcom/google/common/collect/ae$a;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    const/4 v1, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    if-eqz v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x4

    check-cast p1, Lcom/google/common/collect/ae$a;

    const/4 v4, 0x6

    invoke-interface {p1}, Lcom/google/common/collect/ae$a;->a()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-interface {p1}, Lcom/google/common/collect/ae$a;->getCount()I

    move-result p1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    if-eqz p1, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {p0}, Lcom/google/common/collect/de$i;->f()Lcom/google/common/collect/ae;

    move-result-object v2

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-interface {v2, v0, p1, v1}, Lcom/google/common/collect/ae;->q1(Ljava/lang/Object;II)Z

    move-result p1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    return p1

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    return v1
.end method
