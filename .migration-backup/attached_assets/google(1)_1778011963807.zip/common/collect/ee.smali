.class public final Lcom/google/common/collect/ee;
.super Lcom/google/common/collect/k8;

# interfaces
.implements Lcom/google/common/collect/v0;
.implements Ljava/io/Serializable;


# annotations
.annotation runtime Lcom/google/common/collect/d7;
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/common/collect/ee$c;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<B:",
        "Ljava/lang/Object;",
        ">",
        "Lcom/google/common/collect/k8<",
        "Ljava/lang/Class<",
        "+TB;>;TB;>;",
        "Lcom/google/common/collect/v0<",
        "TB;>;",
        "Ljava/io/Serializable;"
    }
.end annotation

.annotation build Lx4/c;
.end annotation

.annotation build Lx4/d;
.end annotation


# instance fields
.field private final delegate:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/Class<",
            "+TB;>;TB;>;"
        }
    .end annotation
.end field


# direct methods
.method private constructor <init>(Ljava/util/Map;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "delegate"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/Class<",
            "+TB;>;TB;>;)V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-direct {p0}, Lcom/google/common/collect/k8;-><init>()V

    const/4 v0, 0x2

    or-int/2addr v1, v0

    invoke-static {p1}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x0

    check-cast p1, Ljava/util/Map;

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/common/collect/ee;->delegate:Ljava/util/Map;

    const/4 v0, 0x1

    move v1, v0

    return-void
.end method

.method private static A0(Ljava/util/Map$Entry;)Ljava/util/Map$Entry;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "entry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<B:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/util/Map$Entry<",
            "Ljava/lang/Class<",
            "+TB;>;TB;>;)",
            "Ljava/util/Map$Entry<",
            "Ljava/lang/Class<",
            "+TB;>;TB;>;"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    new-instance v0, Lcom/google/common/collect/ee$a;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-direct {v0, p0}, Lcom/google/common/collect/ee$a;-><init>(Ljava/util/Map$Entry;)V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-object v0
.end method

.method public static B0()Lcom/google/common/collect/ee;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<B:",
            "Ljava/lang/Object;",
            ">()",
            "Lcom/google/common/collect/ee<",
            "TB;>;"
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    new-instance v0, Lcom/google/common/collect/ee;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    new-instance v1, Ljava/util/HashMap;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    const/4 v3, 0x6

    invoke-direct {v0, v1}, Lcom/google/common/collect/ee;-><init>(Ljava/util/Map;)V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-object v0
.end method

.method public static C0(Ljava/util/Map;)Lcom/google/common/collect/ee;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "backingMap"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<B:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/util/Map<",
            "Ljava/lang/Class<",
            "+TB;>;TB;>;)",
            "Lcom/google/common/collect/ee<",
            "TB;>;"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    new-instance v0, Lcom/google/common/collect/ee;

    const/4 v1, 0x2

    move v2, v1

    invoke-direct {v0, p0}, Lcom/google/common/collect/ee;-><init>(Ljava/util/Map;)V

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-object v0
.end method

.method private readObject(Ljava/io/ObjectInputStream;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "stream"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/InvalidObjectException;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    new-instance p1, Ljava/io/InvalidObjectException;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    const-string v0, "dssli UeSmszreeoir"

    const-string v0, " rseedsrmieilSoUaz"

    const/4 v2, 0x6

    const-string v0, "FrmmedlseSorUiz ea"

    const-string v0, "Use SerializedForm"

    const/4 v2, 0x0

    invoke-direct {p1, v0}, Ljava/io/InvalidObjectException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x3

    throw p1
.end method

.method private writeReplace()Ljava/lang/Object;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    new-instance v0, Lcom/google/common/collect/ee$c;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/google/common/collect/ee;->i0()Ljava/util/Map;

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-direct {v0, v1}, Lcom/google/common/collect/ee$c;-><init>(Ljava/util/Map;)V

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    return-object v0
.end method

.method static synthetic x0(Ljava/lang/Class;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x6

    invoke-static {p0, p1}, Lcom/google/common/collect/ee;->z0(Ljava/lang/Class;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-object p0
.end method

.method static synthetic y0(Ljava/util/Map$Entry;)Ljava/util/Map$Entry;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-static {p0}, Lcom/google/common/collect/ee;->A0(Ljava/util/Map$Entry;)Ljava/util/Map$Entry;

    move-result-object p0

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-object p0
.end method

.method private static z0(Ljava/lang/Class;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "type",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/lang/Class<",
            "TT;>;",
            "Ljava/lang/Object;",
            ")TT;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-static {p0}, Lcom/google/common/primitives/l0;->f(Ljava/lang/Class;)Ljava/lang/Class;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-virtual {p0, p1}, Ljava/lang/Class;->cast(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-object p0
.end method


# virtual methods
.method public D0(Ljava/lang/Class;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2
    .param p2    # Ljava/lang/Object;
        .annotation runtime Lcom/google/common/collect/me;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "key",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "+TB;>;TB;)TB;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-static {p1, p2}, Lcom/google/common/collect/ee;->z0(Ljava/lang/Class;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v0, 0x0

    move v1, v0

    invoke-super {p0, p1, p2}, Lcom/google/common/collect/k8;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-object p1
.end method

.method public entrySet()Ljava/util/Set;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "Ljava/util/Map$Entry<",
            "Ljava/lang/Class<",
            "+TB;>;TB;>;>;"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    new-instance v0, Lcom/google/common/collect/ee$b;

    const/4 v1, 0x5

    shr-int/2addr v2, v1

    invoke-direct {v0, p0}, Lcom/google/common/collect/ee$b;-><init>(Lcom/google/common/collect/ee;)V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-object v0
.end method

.method protected bridge synthetic g0()Ljava/lang/Object;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/common/collect/ee;->i0()Ljava/util/Map;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object v0
.end method

.method protected i0()Ljava/util/Map;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/Class<",
            "+TB;>;TB;>;"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/common/collect/ee;->delegate:Ljava/util/Map;

    const/4 v2, 0x7

    return-object v0
.end method

.method public j(Ljava/lang/Class;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2
    .param p2    # Ljava/lang/Object;
        .annotation runtime Lcom/google/common/collect/me;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "type",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:TB;>(",
            "Ljava/lang/Class<",
            "TT;>;TT;)TT;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-virtual {p0, p1, p2}, Lcom/google/common/collect/ee;->D0(Ljava/lang/Class;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-static {p1, p2}, Lcom/google/common/collect/ee;->z0(Ljava/lang/Class;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-object p1
.end method

.method public m(Ljava/lang/Class;)Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "type"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:TB;>(",
            "Ljava/lang/Class<",
            "TT;>;)TT;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {p0, p1}, Lcom/google/common/collect/k8;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-static {p1, v0}, Lcom/google/common/collect/ee;->z0(Ljava/lang/Class;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object p1
.end method

.method public bridge synthetic put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2
    .param p2    # Ljava/lang/Object;
        .annotation runtime Lcom/google/common/collect/me;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "key",
            "value"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v1, 0x0

    check-cast p1, Ljava/lang/Class;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-virtual {p0, p1, p2}, Lcom/google/common/collect/ee;->D0(Ljava/lang/Class;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-object p1
.end method

.method public putAll(Ljava/util/Map;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "map"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "+",
            "Ljava/lang/Class<",
            "+TB;>;+TB;>;)V"
        }
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    new-instance v0, Ljava/util/LinkedHashMap;

    const/4 v4, 0x7

    const/4 v3, 0x7

    invoke-direct {v0, p1}, Ljava/util/LinkedHashMap;-><init>(Ljava/util/Map;)V

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-interface {v0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x4

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    if-eqz v1, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x3

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x3

    check-cast v1, Ljava/util/Map$Entry;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    check-cast v2, Ljava/lang/Class;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-static {v2, v1}, Lcom/google/common/collect/ee;->z0(Ljava/lang/Class;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x6

    goto :goto_0

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-super {p0, v0}, Lcom/google/common/collect/k8;->putAll(Ljava/util/Map;)V

    const/4 v3, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x6

    return-void
.end method
