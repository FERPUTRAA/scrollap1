.class final Lcom/google/common/collect/ac$b;
.super Lcom/google/common/collect/t9;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/collect/ac;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/common/collect/t9<",
        "Ljava/util/Map$Entry<",
        "TV;TK;>;>;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/google/common/collect/ac;


# direct methods
.method private constructor <init>(Lcom/google/common/collect/ac;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            "this$0"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/google/common/collect/ac$b;->this$0:Lcom/google/common/collect/ac;

    const/4 v1, 0x0

    const/4 v0, 0x0

    invoke-direct {p0}, Lcom/google/common/collect/t9;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/common/collect/ac;Lcom/google/common/collect/ac$a;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-direct {p0, p1}, Lcom/google/common/collect/ac$b;-><init>(Lcom/google/common/collect/ac;)V

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public S(I)Ljava/util/Map$Entry;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "index"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Ljava/util/Map$Entry<",
            "TV;TK;>;"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/common/collect/ac$b;->this$0:Lcom/google/common/collect/ac;

    const/4 v2, 0x2

    invoke-static {v0}, Lcom/google/common/collect/ac;->k0(Lcom/google/common/collect/ac;)Lcom/google/common/collect/t9;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    check-cast p1, Ljava/util/Map$Entry;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-interface {p1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-interface {p1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-static {v0, p1}, Lcom/google/common/collect/uc;->O(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Map$Entry;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x1

    return-object p1
.end method

.method g()Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x5

    return v0
.end method

.method public bridge synthetic get(I)Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "index"
        }
    .end annotation

    const/4 v0, 0x2

    move v1, v0

    invoke-virtual {p0, p1}, Lcom/google/common/collect/ac$b;->S(I)Ljava/util/Map$Entry;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-object p1
.end method

.method public size()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/common/collect/ac$b;->this$0:Lcom/google/common/collect/ac;

    const/4 v2, 0x1

    invoke-static {v0}, Lcom/google/common/collect/ac;->k0(Lcom/google/common/collect/ac;)Lcom/google/common/collect/t9;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {v0}, Ljava/util/AbstractCollection;->size()I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    return v0
.end method
