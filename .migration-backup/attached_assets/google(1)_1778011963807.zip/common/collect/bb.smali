.class public final synthetic Lcom/google/common/collect/bb;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/function/BinaryOperator;


# direct methods
.method public synthetic constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public final apply(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~ss~b~.~4id~@@n@/o@~ t~ ~~trbMKv@~l~~1@co@l -ou@ ~@ f~f@@~S y @~ a@~i@@i  ~~ m/~@b@@~  @ o @  o~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    check-cast p1, Lcom/google/common/collect/ae;

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x0

    check-cast p2, Lcom/google/common/collect/ae;

    const/4 v0, 0x7

    const/4 v0, 0x2

    invoke-static {p1, p2}, Lcom/google/common/collect/db;->T(Lcom/google/common/collect/ae;Lcom/google/common/collect/ae;)Lcom/google/common/collect/ae;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-object p1
.end method
