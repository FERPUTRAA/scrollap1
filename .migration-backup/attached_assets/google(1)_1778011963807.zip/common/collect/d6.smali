.class Lcom/google/common/collect/d6;
.super Lcom/google/common/collect/a6;


# annotations
.annotation runtime Lcom/google/common/collect/d7;
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<E:",
        "Ljava/lang/Object;",
        ">",
        "Lcom/google/common/collect/a6<",
        "TE;>;"
    }
.end annotation

.annotation build Lx4/c;
.end annotation


# static fields
.field private static final l:I = -0x2


# instance fields
.field private transient h:[I
    .annotation runtime Lv7/a;
    .end annotation
.end field

.field private transient i:[I
    .annotation runtime Lv7/a;
    .end annotation
.end field

.field private transient j:I

.field private transient k:I


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v0, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-direct {p0}, Lcom/google/common/collect/a6;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method

.method constructor <init>(I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "expectedSize"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-direct {p0, p1}, Lcom/google/common/collect/a6;-><init>(I)V

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-void
.end method

.method public static N()Lcom/google/common/collect/d6;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            ">()",
            "Lcom/google/common/collect/d6<",
            "TE;>;"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "ocsb@~i~yir. ~@ @~~ ~1 o@ @u@mo ~/ot@@~~oMi~K ~ ~lf~~~ ~ sS~@ @/l@b4 n~@o a d~v~@t-b f@ ~@@@@@@~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    new-instance v0, Lcom/google/common/collect/d6;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-direct {v0}, Lcom/google/common/collect/d6;-><init>()V

    const/4 v2, 0x7

    return-object v0
.end method

.method public static O(Ljava/util/Collection;)Lcom/google/common/collect/d6;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "collection"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/util/Collection<",
            "+TE;>;)",
            "Lcom/google/common/collect/d6<",
            "TE;>;"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-interface {p0}, Ljava/util/Collection;->size()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-static {v0}, Lcom/google/common/collect/d6;->Q(I)Lcom/google/common/collect/d6;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {v0, p0}, Ljava/util/AbstractCollection;->addAll(Ljava/util/Collection;)Z

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-object v0
.end method

.method public static varargs P([Ljava/lang/Object;)Lcom/google/common/collect/d6;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "elements"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            ">([TE;)",
            "Lcom/google/common/collect/d6<",
            "TE;>;"
        }
    .end annotation

    .annotation runtime Ljava/lang/SafeVarargs;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    array-length v0, p0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-static {v0}, Lcom/google/common/collect/d6;->Q(I)Lcom/google/common/collect/d6;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-static {v0, p0}, Ljava/util/Collections;->addAll(Ljava/util/Collection;[Ljava/lang/Object;)Z

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-object v0
.end method

.method public static Q(I)Lcom/google/common/collect/d6;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "expectedSize"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            ">(I)",
            "Lcom/google/common/collect/d6<",
            "TE;>;"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    new-instance v0, Lcom/google/common/collect/d6;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-direct {v0, p0}, Lcom/google/common/collect/d6;-><init>(I)V

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object v0
.end method

.method private R(I)I
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "entry"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-direct {p0}, Lcom/google/common/collect/d6;->S()[I

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    aget p1, v0, p1

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    add-int/lit8 p1, p1, -0x1

    const/4 v2, 0x6

    return p1
.end method

.method private S()[I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/common/collect/d6;->h:[I

    const/4 v2, 0x2

    const/4 v1, 0x3

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    check-cast v0, [I

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-object v0
.end method

.method private T()[I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/common/collect/d6;->i:[I

    const/4 v2, 0x4

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    check-cast v0, [I

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-object v0
.end method

.method private U(II)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "entry",
            "pred"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-direct {p0}, Lcom/google/common/collect/d6;->S()[I

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    add-int/lit8 p2, p2, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    aput p2, v0, p1

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void
.end method

.method private V(II)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "pred",
            "succ"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    const/4 v0, -0x2

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    if-ne p1, v0, :cond_0

    const/4 v2, 0x6

    iput p2, p0, Lcom/google/common/collect/d6;->j:I

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-direct {p0, p1, p2}, Lcom/google/common/collect/d6;->W(II)V

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    if-ne p2, v0, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    iput p1, p0, Lcom/google/common/collect/d6;->k:I

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    goto :goto_1

    :cond_1
    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-direct {p0, p2, p1}, Lcom/google/common/collect/d6;->U(II)V

    :goto_1
    const/4 v1, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-void
.end method

.method private W(II)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "entry",
            "succ"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-direct {p0}, Lcom/google/common/collect/d6;->T()[I

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    add-int/lit8 p2, p2, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    aput p2, v0, p1

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-void
.end method


# virtual methods
.method C(I)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "newCapacity"
        }
    .end annotation

    const/4 v2, 0x6

    invoke-super {p0, p1}, Lcom/google/common/collect/a6;->C(I)V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-direct {p0}, Lcom/google/common/collect/d6;->S()[I

    move-result-object v0

    const/4 v1, 0x0

    move v2, v1

    invoke-static {v0, p1}, Ljava/util/Arrays;->copyOf([II)[I

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/google/common/collect/d6;->h:[I

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-direct {p0}, Lcom/google/common/collect/d6;->T()[I

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-static {v0, p1}, Ljava/util/Arrays;->copyOf([II)[I

    move-result-object p1

    const/4 v2, 0x2

    iput-object p1, p0, Lcom/google/common/collect/d6;->i:[I

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-void
.end method

.method public clear()V
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {p0}, Lcom/google/common/collect/a6;->y()Z

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    return-void

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 v0, -0x2

    const/4 v4, 0x1

    const/4 v3, 0x1

    iput v0, p0, Lcom/google/common/collect/d6;->j:I

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    iput v0, p0, Lcom/google/common/collect/d6;->k:I

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/google/common/collect/d6;->h:[I

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x2

    if-eqz v0, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x1

    iget-object v1, p0, Lcom/google/common/collect/d6;->i:[I

    const/4 v3, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x7

    if-eqz v1, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {p0}, Lcom/google/common/collect/a6;->size()I

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x6

    const/4 v2, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-static {v0, v2, v1, v2}, Ljava/util/Arrays;->fill([IIII)V

    const/4 v3, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/google/common/collect/d6;->i:[I

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {p0}, Lcom/google/common/collect/a6;->size()I

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-static {v0, v2, v1, v2}, Ljava/util/Arrays;->fill([IIII)V

    :cond_1
    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-super {p0}, Lcom/google/common/collect/a6;->clear()V

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    return-void
.end method

.method d(II)I
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "indexBeforeRemove",
            "indexRemoved"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/common/collect/a6;->size()I

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    if-lt p1, v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    move p1, p2

    const/4 v2, 0x5

    move p1, p2

    move p1, p2

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    return p1
.end method

.method e()I
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-super {p0}, Lcom/google/common/collect/a6;->e()I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    new-array v1, v0, [I

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    iput-object v1, p0, Lcom/google/common/collect/d6;->h:[I

    const/4 v3, 0x2

    new-array v1, v0, [I

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    iput-object v1, p0, Lcom/google/common/collect/d6;->i:[I

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    return v0
.end method

.method f()Ljava/util/Set;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "TE;>;"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-super {p0}, Lcom/google/common/collect/a6;->f()Ljava/util/Set;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    iput-object v1, p0, Lcom/google/common/collect/d6;->h:[I

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    iput-object v1, p0, Lcom/google/common/collect/d6;->i:[I

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    return-object v0
.end method

.method o()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget v0, p0, Lcom/google/common/collect/d6;->j:I

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    return v0
.end method

.method p(I)I
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "entry"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-direct {p0}, Lcom/google/common/collect/d6;->T()[I

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    aget p1, v0, p1

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    add-int/lit8 p1, p1, -0x1

    const/4 v2, 0x4

    const/4 v1, 0x4

    return p1
.end method

.method public spliterator()Ljava/util/Spliterator;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Spliterator<",
            "TE;>;"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    const/16 v0, 0x11

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-static {p0, v0}, Lcom/google/android/gms/internal/common/a;->a(Ljava/util/Collection;I)Ljava/util/Spliterator;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-object v0
.end method

.method t(I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "expectedSize"
        }
    .end annotation

    const/4 v1, 0x3

    invoke-super {p0, p1}, Lcom/google/common/collect/a6;->t(I)V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x7

    const/4 p1, -0x2

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x0

    iput p1, p0, Lcom/google/common/collect/d6;->j:I

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput p1, p0, Lcom/google/common/collect/d6;->k:I

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-void
.end method

.method public toArray()[Ljava/lang/Object;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-static {p0}, Lcom/google/common/collect/ke;->l(Ljava/util/Collection;)[Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object v0
.end method

.method public toArray([Ljava/lang/Object;)[Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "a"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">([TT;)[TT;"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-static {p0, p1}, Lcom/google/common/collect/ke;->m(Ljava/util/Collection;[Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-object p1
.end method

.method u(ILjava/lang/Object;II)V
    .locals 2
    .param p2    # Ljava/lang/Object;
        .annotation runtime Lcom/google/common/collect/me;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "entryIndex",
            "object",
            "hash",
            "mask"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(ITE;II)V"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-super {p0, p1, p2, p3, p4}, Lcom/google/common/collect/a6;->u(ILjava/lang/Object;II)V

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x3

    iget p2, p0, Lcom/google/common/collect/d6;->k:I

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-direct {p0, p2, p1}, Lcom/google/common/collect/d6;->V(II)V

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x5

    const/4 p2, -0x2

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-direct {p0, p1, p2}, Lcom/google/common/collect/d6;->V(II)V

    const/4 v0, 0x6

    move v1, v0

    return-void
.end method

.method x(II)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "dstIndex",
            "mask"
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/google/common/collect/a6;->size()I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    add-int/lit8 v0, v0, -0x1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-super {p0, p1, p2}, Lcom/google/common/collect/a6;->x(II)V

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-direct {p0, p1}, Lcom/google/common/collect/d6;->R(I)I

    move-result p2

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {p0, p1}, Lcom/google/common/collect/d6;->p(I)I

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-direct {p0, p2, v1}, Lcom/google/common/collect/d6;->V(II)V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    if-ge p1, v0, :cond_0

    const/4 v3, 0x7

    invoke-direct {p0, v0}, Lcom/google/common/collect/d6;->R(I)I

    move-result p2

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-direct {p0, p2, p1}, Lcom/google/common/collect/d6;->V(II)V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {p0, v0}, Lcom/google/common/collect/d6;->p(I)I

    move-result p2

    const/4 v3, 0x0

    const/4 v2, 0x3

    invoke-direct {p0, p1, p2}, Lcom/google/common/collect/d6;->V(II)V

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-direct {p0}, Lcom/google/common/collect/d6;->S()[I

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    const/4 p2, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x0

    aput p2, p1, v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-direct {p0}, Lcom/google/common/collect/d6;->T()[I

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    aput p2, p1, v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-void
.end method
