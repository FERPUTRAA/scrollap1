.class public final synthetic Lcom/google/common/collect/a3;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/function/BiConsumer;


# instance fields
.field public final synthetic a:Ljava/util/function/Function;

.field public final synthetic b:Ljava/util/function/Function;


# direct methods
.method public synthetic constructor <init>(Ljava/util/function/Function;Ljava/util/function/Function;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/common/collect/a3;->a:Ljava/util/function/Function;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x7

    iput-object p2, p0, Lcom/google/common/collect/a3;->b:Ljava/util/function/Function;

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public final accept(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~rs @~f @4~t@@@ o@~@ n~uyM~@o@~ b@b ~c~tl~@i@~@d @ofo ~vK  o1S -~~@ @~ ~@l~~@/a~s@i~~~m @ i o /b"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/common/collect/a3;->a:Ljava/util/function/Function;

    const/4 v3, 0x1

    iget-object v1, p0, Lcom/google/common/collect/a3;->b:Ljava/util/function/Function;

    const/4 v3, 0x3

    check-cast p1, Lcom/google/common/collect/oa$c;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-static {v0, v1, p1, p2}, Lcom/google/common/collect/c4;->j(Ljava/util/function/Function;Ljava/util/function/Function;Lcom/google/common/collect/oa$c;Ljava/lang/Object;)V

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    return-void
.end method
