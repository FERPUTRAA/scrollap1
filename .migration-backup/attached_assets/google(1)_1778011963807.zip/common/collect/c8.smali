.class Lcom/google/common/collect/c8;
.super Ljava/lang/Object;


# annotations
.annotation runtime Lcom/google/common/collect/d7;
.end annotation

.annotation build Lx4/b;
    emulated = true
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x1

    return-void
.end method
