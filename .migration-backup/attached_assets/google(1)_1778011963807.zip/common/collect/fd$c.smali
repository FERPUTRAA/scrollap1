.class Lcom/google/common/collect/fd$c;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/collect/fd;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "c"
.end annotation


# instance fields
.field final a:Lcom/google/common/collect/le;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/collect/le<",
            "TE;>;"
        }
    .end annotation
.end field

.field b:Lcom/google/common/collect/fd$c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/collect/fd<",
            "TE;>.c;"
        }
    .end annotation

    .annotation build Lf6/j;
    .end annotation
.end field

.field final synthetic c:Lcom/google/common/collect/fd;


# direct methods
.method constructor <init>(Lcom/google/common/collect/fd;Lcom/google/common/collect/le;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010,
            0x0
        }
        names = {
            "this$0",
            "ordering"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/collect/le<",
            "TE;>;)V"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/google/common/collect/fd$c;->c:Lcom/google/common/collect/fd;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x5

    iput-object p2, p0, Lcom/google/common/collect/fd$c;->a:Lcom/google/common/collect/le;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method

.method static synthetic a(Lcom/google/common/collect/fd$c;I)Z
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " ~so@-@~~sb~@~~Kdi~lmb@/f  Sr@@ v ~/~ a~@~ @~  @t@@i~~  @oyn@@~f1lot@@~i4~Moo~  b@ou@  @~ ~c.@~~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    invoke-direct {p0, p1}, Lcom/google/common/collect/fd$c;->q(I)Z

    move-result p0

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x6

    return p0
.end method

.method private k(I)I
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "i"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-direct {p0, p1}, Lcom/google/common/collect/fd$c;->m(I)I

    move-result p1

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-direct {p0, p1}, Lcom/google/common/collect/fd$c;->m(I)I

    move-result p1

    const/4 v1, 0x4

    const/4 v0, 0x6

    return p1
.end method

.method private l(I)I
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "i"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x2

    mul-int/lit8 p1, p1, 0x2

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x0

    add-int/lit8 p1, p1, 0x1

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x7

    return p1
.end method

.method private m(I)I
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "i"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x0

    add-int/lit8 p1, p1, -0x1

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x6

    div-int/lit8 p1, p1, 0x2

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x0

    return p1
.end method

.method private n(I)I
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "i"
        }
    .end annotation

    const/4 v1, 0x6

    mul-int/lit8 p1, p1, 0x2

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x0

    add-int/lit8 p1, p1, 0x2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x0

    return p1
.end method

.method private q(I)Z
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "i"
        }
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-direct {p0, p1}, Lcom/google/common/collect/fd$c;->l(I)I

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/google/common/collect/fd$c;->c:Lcom/google/common/collect/fd;

    const/4 v3, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-static {v1}, Lcom/google/common/collect/fd;->b(Lcom/google/common/collect/fd;)I

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    const/4 v2, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-ge v0, v1, :cond_0

    const/4 v4, 0x0

    invoke-direct {p0, p1}, Lcom/google/common/collect/fd$c;->l(I)I

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {p0, p1, v0}, Lcom/google/common/collect/fd$c;->d(II)I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x5

    if-lez v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x5

    return v2

    :cond_0
    invoke-direct {p0, p1}, Lcom/google/common/collect/fd$c;->n(I)I

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x1

    iget-object v1, p0, Lcom/google/common/collect/fd$c;->c:Lcom/google/common/collect/fd;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-static {v1}, Lcom/google/common/collect/fd;->b(Lcom/google/common/collect/fd;)I

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x4

    if-ge v0, v1, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-direct {p0, p1}, Lcom/google/common/collect/fd$c;->n(I)I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {p0, p1, v0}, Lcom/google/common/collect/fd$c;->d(II)I

    move-result v0

    const/4 v3, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    if-lez v0, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    return v2

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-lez p1, :cond_2

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-direct {p0, p1}, Lcom/google/common/collect/fd$c;->m(I)I

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x6

    invoke-virtual {p0, p1, v0}, Lcom/google/common/collect/fd$c;->d(II)I

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    if-lez v0, :cond_2

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    return v2

    :cond_2
    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    const/4 v0, 0x2

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    if-le p1, v0, :cond_3

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-direct {p0, p1}, Lcom/google/common/collect/fd$c;->k(I)I

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {p0, v0, p1}, Lcom/google/common/collect/fd$c;->d(II)I

    move-result p1

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    if-lez p1, :cond_3

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    return v2

    :cond_3
    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x4

    const/4 p1, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    return p1
.end method


# virtual methods
.method b(ILjava/lang/Object;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "index",
            "x"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(ITE;)V"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {p0, p1, p2}, Lcom/google/common/collect/fd$c;->f(ILjava/lang/Object;)I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    if-ne v0, p1, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    move v0, p1

    move v0, p1

    const/4 v2, 0x4

    move v0, p1

    move v0, p1

    move-object p1, p0

    move-object p1, p0

    move-object p1, p0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-object p1, p0, Lcom/google/common/collect/fd$c;->b:Lcom/google/common/collect/fd$c;

    :goto_0
    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {p1, v0, p2}, Lcom/google/common/collect/fd$c;->c(ILjava/lang/Object;)I

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-void
.end method

.method c(ILjava/lang/Object;)I
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "index",
            "x"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(ITE;)I"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    const/4 v0, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    if-le p1, v0, :cond_1

    const/4 v4, 0x2

    invoke-direct {p0, p1}, Lcom/google/common/collect/fd$c;->k(I)I

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    iget-object v1, p0, Lcom/google/common/collect/fd$c;->c:Lcom/google/common/collect/fd;

    const/4 v3, 0x5

    invoke-virtual {v1, v0}, Lcom/google/common/collect/fd;->j(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget-object v2, p0, Lcom/google/common/collect/fd$c;->a:Lcom/google/common/collect/le;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {v2, v1, p2}, Lcom/google/common/collect/le;->compare(Ljava/lang/Object;Ljava/lang/Object;)I

    move-result v2

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x7

    if-gtz v2, :cond_0

    const/4 v3, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x3

    goto :goto_1

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x3

    iget-object v2, p0, Lcom/google/common/collect/fd$c;->c:Lcom/google/common/collect/fd;

    const/4 v4, 0x2

    const/4 v3, 0x3

    invoke-static {v2}, Lcom/google/common/collect/fd;->a(Lcom/google/common/collect/fd;)[Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x2

    aput-object v1, v2, p1

    const/4 v4, 0x1

    const/4 v3, 0x5

    move p1, v0

    move p1, v0

    const/4 v4, 0x2

    move p1, v0

    move p1, v0

    const/4 v4, 0x4

    const/4 v3, 0x6

    goto :goto_0

    :cond_1
    :goto_1
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/google/common/collect/fd$c;->c:Lcom/google/common/collect/fd;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-static {v0}, Lcom/google/common/collect/fd;->a(Lcom/google/common/collect/fd;)[Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    aput-object p2, v0, p1

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x4

    return p1
.end method

.method d(II)I
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "a",
            "b"
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/google/common/collect/fd$c;->a:Lcom/google/common/collect/le;

    const/4 v2, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/google/common/collect/fd$c;->c:Lcom/google/common/collect/fd;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {v1, p1}, Lcom/google/common/collect/fd;->j(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    iget-object v1, p0, Lcom/google/common/collect/fd$c;->c:Lcom/google/common/collect/fd;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {v1, p2}, Lcom/google/common/collect/fd;->j(I)Ljava/lang/Object;

    move-result-object p2

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {v0, p1, p2}, Lcom/google/common/collect/le;->compare(Ljava/lang/Object;Ljava/lang/Object;)I

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    return p1
.end method

.method e(ILjava/lang/Object;)I
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "index",
            "x"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(ITE;)I"
        }
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {p0, p1}, Lcom/google/common/collect/fd$c;->i(I)I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x1

    if-lez v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/google/common/collect/fd$c;->a:Lcom/google/common/collect/le;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    iget-object v2, p0, Lcom/google/common/collect/fd$c;->c:Lcom/google/common/collect/fd;

    const/4 v4, 0x2

    invoke-virtual {v2, v0}, Lcom/google/common/collect/fd;->j(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {v1, v2, p2}, Lcom/google/common/collect/le;->compare(Ljava/lang/Object;Ljava/lang/Object;)I

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-gez v1, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/google/common/collect/fd$c;->c:Lcom/google/common/collect/fd;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-static {v1}, Lcom/google/common/collect/fd;->a(Lcom/google/common/collect/fd;)[Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x0

    iget-object v2, p0, Lcom/google/common/collect/fd$c;->c:Lcom/google/common/collect/fd;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {v2, v0}, Lcom/google/common/collect/fd;->j(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x1

    aput-object v2, v1, p1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget-object p1, p0, Lcom/google/common/collect/fd$c;->c:Lcom/google/common/collect/fd;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-static {p1}, Lcom/google/common/collect/fd;->a(Lcom/google/common/collect/fd;)[Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x2

    aput-object p2, p1, v0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    return v0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {p0, p1, p2}, Lcom/google/common/collect/fd$c;->f(ILjava/lang/Object;)I

    move-result p1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    return p1
.end method

.method f(ILjava/lang/Object;)I
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "index",
            "x"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(ITE;)I"
        }
    .end annotation

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x7

    if-nez p1, :cond_0

    const/4 v5, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x6

    iget-object p1, p0, Lcom/google/common/collect/fd$c;->c:Lcom/google/common/collect/fd;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-static {p1}, Lcom/google/common/collect/fd;->a(Lcom/google/common/collect/fd;)[Ljava/lang/Object;

    move-result-object p1

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x3

    const/4 v0, 0x0

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x5

    aput-object p2, p1, v0

    const/4 v5, 0x4

    const/4 v5, 0x0

    return v0

    :cond_0
    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-direct {p0, p1}, Lcom/google/common/collect/fd$c;->m(I)I

    move-result v0

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x0

    iget-object v1, p0, Lcom/google/common/collect/fd$c;->c:Lcom/google/common/collect/fd;

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-virtual {v1, v0}, Lcom/google/common/collect/fd;->j(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x6

    if-eqz v0, :cond_1

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-direct {p0, v0}, Lcom/google/common/collect/fd$c;->m(I)I

    move-result v2

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-direct {p0, v2}, Lcom/google/common/collect/fd$c;->n(I)I

    move-result v2

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x7

    if-eq v2, v0, :cond_1

    const/4 v6, 0x2

    invoke-direct {p0, v2}, Lcom/google/common/collect/fd$c;->l(I)I

    move-result v3

    const/4 v6, 0x5

    const/4 v5, 0x2

    iget-object v4, p0, Lcom/google/common/collect/fd$c;->c:Lcom/google/common/collect/fd;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-static {v4}, Lcom/google/common/collect/fd;->b(Lcom/google/common/collect/fd;)I

    move-result v4

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x3

    if-lt v3, v4, :cond_1

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x6

    iget-object v3, p0, Lcom/google/common/collect/fd$c;->c:Lcom/google/common/collect/fd;

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-virtual {v3, v2}, Lcom/google/common/collect/fd;->j(I)Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x4

    iget-object v4, p0, Lcom/google/common/collect/fd$c;->a:Lcom/google/common/collect/le;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-virtual {v4, v3, v1}, Lcom/google/common/collect/le;->compare(Ljava/lang/Object;Ljava/lang/Object;)I

    move-result v4

    const/4 v5, 0x2

    shl-int/2addr v6, v5

    if-gez v4, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x3

    move v0, v2

    move v0, v2

    const/4 v6, 0x3

    move v0, v2

    move v0, v2

    move-object v1, v3

    move-object v1, v3

    move-object v1, v3

    move-object v1, v3

    :cond_1
    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x3

    iget-object v2, p0, Lcom/google/common/collect/fd$c;->a:Lcom/google/common/collect/le;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-virtual {v2, v1, p2}, Lcom/google/common/collect/le;->compare(Ljava/lang/Object;Ljava/lang/Object;)I

    move-result v2

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-gez v2, :cond_2

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x1

    iget-object v2, p0, Lcom/google/common/collect/fd$c;->c:Lcom/google/common/collect/fd;

    const/4 v6, 0x6

    invoke-static {v2}, Lcom/google/common/collect/fd;->a(Lcom/google/common/collect/fd;)[Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x3

    aput-object v1, v2, p1

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x7

    iget-object p1, p0, Lcom/google/common/collect/fd$c;->c:Lcom/google/common/collect/fd;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-static {p1}, Lcom/google/common/collect/fd;->a(Lcom/google/common/collect/fd;)[Ljava/lang/Object;

    move-result-object p1

    const/4 v6, 0x0

    const/4 v5, 0x7

    aput-object p2, p1, v0

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x6

    return v0

    :cond_2
    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x3

    iget-object v0, p0, Lcom/google/common/collect/fd$c;->c:Lcom/google/common/collect/fd;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-static {v0}, Lcom/google/common/collect/fd;->a(Lcom/google/common/collect/fd;)[Ljava/lang/Object;

    move-result-object v0

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x3

    aput-object p2, v0, p1

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x4

    return p1
.end method

.method g(I)I
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "index"
        }
    .end annotation

    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {p0, p1}, Lcom/google/common/collect/fd$c;->j(I)I

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-lez v0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/google/common/collect/fd$c;->c:Lcom/google/common/collect/fd;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-static {v1}, Lcom/google/common/collect/fd;->a(Lcom/google/common/collect/fd;)[Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    iget-object v2, p0, Lcom/google/common/collect/fd$c;->c:Lcom/google/common/collect/fd;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {v2, v0}, Lcom/google/common/collect/fd;->j(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    aput-object v2, v1, p1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    move p1, v0

    move p1, v0

    const/4 v4, 0x1

    move p1, v0

    move p1, v0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    goto :goto_0

    :cond_0
    const/4 v4, 0x0

    return p1
.end method

.method h(II)I
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "index",
            "len"
        }
    .end annotation

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/common/collect/fd$c;->c:Lcom/google/common/collect/fd;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-static {v0}, Lcom/google/common/collect/fd;->b(Lcom/google/common/collect/fd;)I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-lt p1, v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    const/4 p1, -0x1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    return p1

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-lez p1, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    const/4 v0, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    goto :goto_0

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x0

    invoke-static {v0}, Lcom/google/common/base/u0;->g0(Z)V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/common/collect/fd$c;->c:Lcom/google/common/collect/fd;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {v0}, Lcom/google/common/collect/fd;->b(Lcom/google/common/collect/fd;)I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    sub-int/2addr v0, p2

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-static {p1, v0}, Ljava/lang/Math;->min(II)I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    add-int/2addr v0, p2

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    add-int/lit8 p2, p1, 0x1

    :goto_1
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-ge p2, v0, :cond_3

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {p0, p2, p1}, Lcom/google/common/collect/fd$c;->d(II)I

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-gez v1, :cond_2

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    move p1, p2

    move p1, p2

    const/4 v3, 0x5

    move p1, p2

    move p1, p2

    :cond_2
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    add-int/lit8 p2, p2, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    goto :goto_1

    :cond_3
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    return p1
.end method

.method i(I)I
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "index"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-direct {p0, p1}, Lcom/google/common/collect/fd$c;->l(I)I

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    const/4 v0, 0x2

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {p0, p1, v0}, Lcom/google/common/collect/fd$c;->h(II)I

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    return p1
.end method

.method j(I)I
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "index"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x5

    invoke-direct {p0, p1}, Lcom/google/common/collect/fd$c;->l(I)I

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-gez p1, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    const/4 p1, -0x1

    const/4 v2, 0x7

    return p1

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-direct {p0, p1}, Lcom/google/common/collect/fd$c;->l(I)I

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    const/4 v0, 0x4

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {p0, p1, v0}, Lcom/google/common/collect/fd$c;->h(II)I

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    return p1
.end method

.method o(Ljava/lang/Object;)I
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "actualLastElement"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TE;)I"
        }
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/google/common/collect/fd$c;->c:Lcom/google/common/collect/fd;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-static {v0}, Lcom/google/common/collect/fd;->b(Lcom/google/common/collect/fd;)I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-direct {p0, v0}, Lcom/google/common/collect/fd$c;->m(I)I

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    if-eqz v0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-direct {p0, v0}, Lcom/google/common/collect/fd$c;->m(I)I

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-direct {p0, v1}, Lcom/google/common/collect/fd$c;->n(I)I

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-eq v1, v0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-direct {p0, v1}, Lcom/google/common/collect/fd$c;->l(I)I

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    iget-object v2, p0, Lcom/google/common/collect/fd$c;->c:Lcom/google/common/collect/fd;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-static {v2}, Lcom/google/common/collect/fd;->b(Lcom/google/common/collect/fd;)I

    move-result v2

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x1

    if-lt v0, v2, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/google/common/collect/fd$c;->c:Lcom/google/common/collect/fd;

    const/4 v3, 0x3

    move v4, v3

    invoke-virtual {v0, v1}, Lcom/google/common/collect/fd;->j(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x4

    iget-object v2, p0, Lcom/google/common/collect/fd$c;->a:Lcom/google/common/collect/le;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {v2, v0, p1}, Lcom/google/common/collect/le;->compare(Ljava/lang/Object;Ljava/lang/Object;)I

    move-result v2

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x1

    if-gez v2, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    iget-object v2, p0, Lcom/google/common/collect/fd$c;->c:Lcom/google/common/collect/fd;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-static {v2}, Lcom/google/common/collect/fd;->a(Lcom/google/common/collect/fd;)[Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    aput-object p1, v2, v1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget-object p1, p0, Lcom/google/common/collect/fd$c;->c:Lcom/google/common/collect/fd;

    const/4 v3, 0x7

    xor-int/2addr v4, v3

    invoke-static {p1}, Lcom/google/common/collect/fd;->a(Lcom/google/common/collect/fd;)[Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget-object v2, p0, Lcom/google/common/collect/fd$c;->c:Lcom/google/common/collect/fd;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-static {v2}, Lcom/google/common/collect/fd;->b(Lcom/google/common/collect/fd;)I

    move-result v2

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    aput-object v0, p1, v2

    const/4 v4, 0x2

    const/4 v3, 0x7

    return v1

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x2

    iget-object p1, p0, Lcom/google/common/collect/fd$c;->c:Lcom/google/common/collect/fd;

    const/4 v4, 0x0

    const/4 v3, 0x5

    invoke-static {p1}, Lcom/google/common/collect/fd;->b(Lcom/google/common/collect/fd;)I

    move-result p1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    return p1
.end method

.method p(IILjava/lang/Object;)Lcom/google/common/collect/fd$d;
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "removeIndex",
            "vacated",
            "toTrickle"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(IITE;)",
            "Lcom/google/common/collect/fd$d<",
            "TE;>;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {p0, p2, p3}, Lcom/google/common/collect/fd$c;->e(ILjava/lang/Object;)I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    const/4 v1, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x6

    if-ne v0, p2, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    return-object v1

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x0

    if-ge v0, p1, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x3

    iget-object p2, p0, Lcom/google/common/collect/fd$c;->c:Lcom/google/common/collect/fd;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {p2, p1}, Lcom/google/common/collect/fd;->j(I)Ljava/lang/Object;

    move-result-object p2

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    goto :goto_0

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x5

    iget-object p2, p0, Lcom/google/common/collect/fd$c;->c:Lcom/google/common/collect/fd;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-direct {p0, p1}, Lcom/google/common/collect/fd$c;->m(I)I

    move-result v2

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {p2, v2}, Lcom/google/common/collect/fd;->j(I)Ljava/lang/Object;

    move-result-object p2

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    iget-object v2, p0, Lcom/google/common/collect/fd$c;->b:Lcom/google/common/collect/fd$c;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v2, v0, p3}, Lcom/google/common/collect/fd$c;->c(ILjava/lang/Object;)I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x3

    if-ge v0, p1, :cond_2

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    new-instance p1, Lcom/google/common/collect/fd$d;

    const/4 v3, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-direct {p1, p3, p2}, Lcom/google/common/collect/fd$d;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v4, 0x7

    const/4 v3, 0x2

    return-object p1

    :cond_2
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    return-object v1
.end method
