.class public final synthetic Lcom/google/common/collect/dd;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/function/BiConsumer;


# instance fields
.field public final synthetic a:Lcom/google/common/collect/uc$i0;

.field public final synthetic b:Ljava/util/function/BiConsumer;


# direct methods
.method public synthetic constructor <init>(Lcom/google/common/collect/uc$i0;Ljava/util/function/BiConsumer;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/google/common/collect/dd;->a:Lcom/google/common/collect/uc$i0;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x2

    iput-object p2, p0, Lcom/google/common/collect/dd;->b:Ljava/util/function/BiConsumer;

    const/4 v1, 0x4

    const/4 v0, 0x4

    return-void
.end method


# virtual methods
.method public final accept(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~ sa~i@@~ o@f@b@@~@t@  ~@Ko@~~ y v4~@ o c~ ~ir.~noM/l /@ S@  f@~~@o~l  @~d tb@~1s@~~bi@~ ~~m-uo@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/common/collect/dd;->a:Lcom/google/common/collect/uc$i0;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/google/common/collect/dd;->b:Ljava/util/function/BiConsumer;

    const/4 v3, 0x0

    invoke-static {v0, v1, p1, p2}, Lcom/google/common/collect/uc$i0;->d(Lcom/google/common/collect/uc$i0;Ljava/util/function/BiConsumer;Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-void
.end method
