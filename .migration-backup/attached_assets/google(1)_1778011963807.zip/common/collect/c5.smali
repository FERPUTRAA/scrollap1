.class public final synthetic Lcom/google/common/collect/c5;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/common/collect/p4$d$a;


# direct methods
.method public synthetic constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public final a(Ljava/util/Spliterator;Ljava/util/Spliterator;Ljava/util/function/Function;IJ)Ljava/util/Spliterator;
    .locals 9

    const-string/jumbo v8, "ovs~ @4 tno @@K@r@~/~ @o ail o o~ @@ ~c~f~ b~b uM~~m  @@~@is@d~@f-@~@~y~l ot~iS /1~~~@@@~~b.  @@"

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    new-instance v7, Lcom/google/common/collect/p4$e;

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    const/4 v8, 0x7

    check-cast v1, Ljava/util/Spliterator$OfDouble;

    move-object v0, v7

    move-object v0, v7

    move-object v0, v7

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v3, p3

    move-object v3, p3

    move-object v3, p3

    move-object v3, p3

    const/4 v8, 0x0

    move v4, p4

    move v4, p4

    move v4, p4

    move v4, p4

    move-wide v5, p5

    const/4 v8, 0x7

    invoke-direct/range {v0 .. v6}, Lcom/google/common/collect/p4$e;-><init>(Ljava/util/Spliterator$OfDouble;Ljava/util/Spliterator;Ljava/util/function/Function;IJ)V

    const/4 v8, 0x5

    return-object v7
.end method
