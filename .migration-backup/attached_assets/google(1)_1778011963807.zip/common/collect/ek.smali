.class public final synthetic Lcom/google/common/collect/ek;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:[Ljava/util/stream/IntStream;


# direct methods
.method public synthetic constructor <init>([Ljava/util/stream/IntStream;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x5

    iput-object p1, p0, Lcom/google/common/collect/ek;->a:[Ljava/util/stream/IntStream;

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~@s~S / ~@i  oa ~ l1b~ @ ~K~@@ s~@yr @mncfo~@@o d @@~~t~@.~io~@ o@~@~o@ 4~~~@u@-M~@bv@ t~fi ~lb/"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/common/collect/ek;->a:[Ljava/util/stream/IntStream;

    const/4 v1, 0x2

    move v2, v1

    invoke-static {v0}, Lcom/google/common/collect/hk;->e([Ljava/util/stream/IntStream;)V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-void
.end method
