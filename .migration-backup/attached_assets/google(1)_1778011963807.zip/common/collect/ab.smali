.class public final synthetic Lcom/google/common/collect/ab;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/function/BiConsumer;


# instance fields
.field public final synthetic a:Ljava/util/function/Function;

.field public final synthetic b:Ljava/util/function/ToIntFunction;


# direct methods
.method public synthetic constructor <init>(Ljava/util/function/Function;Ljava/util/function/ToIntFunction;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x3

    move v1, v0

    iput-object p1, p0, Lcom/google/common/collect/ab;->a:Ljava/util/function/Function;

    const/4 v1, 0x6

    const/4 v0, 0x0

    iput-object p2, p0, Lcom/google/common/collect/ab;->b:Ljava/util/function/ToIntFunction;

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public final accept(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "b s ~@d ~@f@yi@ u/~aoK4 b~~S l~ ~.i~@tc@   ~@@  -~~@@/b@~~@@~or ~Mi~st@l@~ ~ @n o1m@o~ of~@o~@v@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/common/collect/ab;->a:Ljava/util/function/Function;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/google/common/collect/ab;->b:Ljava/util/function/ToIntFunction;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    check-cast p1, Lcom/google/common/collect/ae;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-static {v0, v1, p1, p2}, Lcom/google/common/collect/db;->S(Ljava/util/function/Function;Ljava/util/function/ToIntFunction;Lcom/google/common/collect/ae;Ljava/lang/Object;)V

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-void
.end method
