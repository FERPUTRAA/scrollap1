.class public final synthetic Lcom/google/common/collect/ce;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/function/ObjIntConsumer;


# instance fields
.field public final synthetic a:Lcom/google/common/collect/ae;


# direct methods
.method public synthetic constructor <init>(Lcom/google/common/collect/ae;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/google/common/collect/ce;->a:Lcom/google/common/collect/ae;

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public final accept(Ljava/lang/Object;I)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@~sS/ ~~ im- @li @~io @~@o@~ 4@@o~cu@1~@ot  ~r~@b@@f t~~o~/o@vs bb  ly~~.@~  @Kd~~ ~nf@M ~ ~@a@~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/common/collect/ce;->a:Lcom/google/common/collect/ae;

    const/4 v1, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-interface {v0, p1, p2}, Lcom/google/common/collect/ae;->a1(Ljava/lang/Object;I)I

    const/4 v2, 0x5

    const/4 v1, 0x7

    return-void
.end method
