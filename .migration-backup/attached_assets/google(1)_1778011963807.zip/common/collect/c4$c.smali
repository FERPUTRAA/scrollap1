.class final Lcom/google/common/collect/c4$c;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/collect/c4;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "c"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<E:",
        "Ljava/lang/Enum<",
        "TE;>;>",
        "Ljava/lang/Object;"
    }
.end annotation


# static fields
.field static final b:Ljava/util/stream/Collector;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/stream/Collector<",
            "Ljava/lang/Enum<",
            "*>;*",
            "Lcom/google/common/collect/qa<",
            "+",
            "Ljava/lang/Enum<",
            "*>;>;>;"
        }
    .end annotation
.end field


# instance fields
.field private a:Ljava/util/EnumSet;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/EnumSet<",
            "TE;>;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-static {}, Lcom/google/common/collect/c4;->C()Ljava/util/stream/Collector;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    sput-object v0, Lcom/google/common/collect/c4$c;->b:Ljava/util/stream/Collector;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/common/collect/c4$a;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x2

    invoke-direct {p0}, Lcom/google/common/collect/c4$c;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method a(Ljava/lang/Enum;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "e"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TE;)V"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/common/collect/c4$c;->a:Ljava/util/EnumSet;

    const/4 v1, 0x0

    shr-int/2addr v2, v1

    if-nez v0, :cond_0

    const/4 v2, 0x5

    invoke-static {p1}, Ljava/util/EnumSet;->of(Ljava/lang/Enum;)Ljava/util/EnumSet;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    iput-object p1, p0, Lcom/google/common/collect/c4$c;->a:Ljava/util/EnumSet;

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-void
.end method

.method b(Lcom/google/common/collect/c4$c;)Lcom/google/common/collect/c4$c;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "other"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/collect/c4$c<",
            "TE;>;)",
            "Lcom/google/common/collect/c4$c<",
            "TE;>;"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/common/collect/c4$c;->a:Ljava/util/EnumSet;

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-object p1

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object p1, p1, Lcom/google/common/collect/c4$c;->a:Ljava/util/EnumSet;

    const/4 v2, 0x0

    const/4 v1, 0x2

    if-nez p1, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object p0

    :cond_1
    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Ljava/util/AbstractCollection;->addAll(Ljava/util/Collection;)Z

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object p0
.end method

.method c()Lcom/google/common/collect/qa;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/collect/qa<",
            "TE;>;"
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/google/common/collect/c4$c;->a:Ljava/util/EnumSet;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-nez v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-static {}, Lcom/google/common/collect/qa;->u()Lcom/google/common/collect/qa;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-object v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-static {v0}, Lcom/google/common/collect/r9;->E(Ljava/util/EnumSet;)Lcom/google/common/collect/qa;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v1, 0x0

    shl-int/2addr v3, v1

    const/4 v2, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    iput-object v1, p0, Lcom/google/common/collect/c4$c;->a:Ljava/util/EnumSet;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    return-object v0
.end method
