.class final Lcom/google/common/collect/c7$d;
.super Lcom/google/common/collect/c7;

# interfaces
.implements Ljava/io/Serializable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/collect/c7;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "d"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/common/collect/c7<",
        "Ljava/lang/Long;",
        ">;",
        "Ljava/io/Serializable;"
    }
.end annotation


# static fields
.field private static final a:Lcom/google/common/collect/c7$d;

.field private static final serialVersionUID:J


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    new-instance v0, Lcom/google/common/collect/c7$d;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-direct {v0}, Lcom/google/common/collect/c7$d;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    sput-object v0, Lcom/google/common/collect/c7$d;->a:Lcom/google/common/collect/c7$d;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-void
.end method

.method constructor <init>()V
    .locals 4

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-direct {p0, v0, v1}, Lcom/google/common/collect/c7;-><init>(ZLcom/google/common/collect/c7$a;)V

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    return-void
.end method

.method static synthetic j()Lcom/google/common/collect/c7$d;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "o@s~ .c~~ou~1@K @nb@  ~~@@~Sa   bv/io@ M@@@/iy-  r~~~o@ ~@b~~tl~@~i~ftf@@@~o~~ dm~@4  l@@~ s o@ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    sget-object v0, Lcom/google/common/collect/c7$d;->a:Lcom/google/common/collect/c7$d;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-object v0
.end method

.method private readResolve()Ljava/lang/Object;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    sget-object v0, Lcom/google/common/collect/c7$d;->a:Lcom/google/common/collect/c7$d;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object v0
.end method


# virtual methods
.method public bridge synthetic b(Ljava/lang/Comparable;Ljava/lang/Comparable;)J
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "start",
            "end"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x0

    check-cast p1, Ljava/lang/Long;

    const/4 v0, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x6

    check-cast p2, Ljava/lang/Long;

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-virtual {p0, p1, p2}, Lcom/google/common/collect/c7$d;->k(Ljava/lang/Long;Ljava/lang/Long;)J

    move-result-wide p1

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-wide p1
.end method

.method public bridge synthetic e()Ljava/lang/Comparable;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/common/collect/c7$d;->l()Ljava/lang/Long;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-object v0
.end method

.method public bridge synthetic f()Ljava/lang/Comparable;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/common/collect/c7$d;->m()Ljava/lang/Long;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-object v0
.end method

.method public bridge synthetic g(Ljava/lang/Comparable;)Ljava/lang/Comparable;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "value"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x2

    check-cast p1, Ljava/lang/Long;

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-virtual {p0, p1}, Lcom/google/common/collect/c7$d;->n(Ljava/lang/Long;)Ljava/lang/Long;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x3

    return-object p1
.end method

.method bridge synthetic h(Ljava/lang/Comparable;J)Ljava/lang/Comparable;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "origin",
            "distance"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x5

    check-cast p1, Ljava/lang/Long;

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-virtual {p0, p1, p2, p3}, Lcom/google/common/collect/c7$d;->o(Ljava/lang/Long;J)Ljava/lang/Long;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-object p1
.end method

.method public bridge synthetic i(Ljava/lang/Comparable;)Ljava/lang/Comparable;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "value"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x7

    check-cast p1, Ljava/lang/Long;

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-virtual {p0, p1}, Lcom/google/common/collect/c7$d;->p(Ljava/lang/Long;)Ljava/lang/Long;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-object p1
.end method

.method public k(Ljava/lang/Long;Ljava/lang/Long;)J
    .locals 9
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "start",
            "end"
        }
    .end annotation

    const/4 v7, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-virtual {p2}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide v2

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x2

    sub-long/2addr v0, v2

    const/4 v8, 0x4

    invoke-virtual {p2}, Ljava/lang/Long;->longValue()J

    move-result-wide v2

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide v4

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x4

    cmp-long v2, v2, v4

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x7

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x3

    if-lez v2, :cond_0

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x5

    cmp-long v2, v0, v3

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x1

    if-gez v2, :cond_0

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x1

    const-wide p1, 0x7fffffffffffffffL

    const-wide p1, 0x7fffffffffffffffL

    const/4 v8, 0x7

    const-wide p1, 0x7fffffffffffffffL

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x2

    return-wide p1

    :cond_0
    const/4 v7, 0x2

    move v8, v7

    invoke-virtual {p2}, Ljava/lang/Long;->longValue()J

    move-result-wide v5

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide p1

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x4

    cmp-long p1, v5, p1

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x2

    if-gez p1, :cond_1

    const/4 v8, 0x4

    cmp-long p1, v0, v3

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x1

    if-lez p1, :cond_1

    const/4 v7, 0x2

    move v8, v7

    const-wide/high16 p1, -0x8000000000000000L

    const-wide/high16 p1, -0x8000000000000000L

    const/4 v8, 0x3

    const-wide/high16 p1, -0x8000000000000000L

    const-wide/high16 p1, -0x8000000000000000L

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x6

    return-wide p1

    :cond_1
    const/4 v8, 0x3

    return-wide v0
.end method

.method public l()Ljava/lang/Long;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v3, 0x6

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v2, 0x2

    xor-int/2addr v3, v2

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x2

    return-object v0
.end method

.method public m()Ljava/lang/Long;
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    const-wide/high16 v0, -0x8000000000000000L

    const-wide/high16 v0, -0x8000000000000000L

    const/4 v3, 0x7

    const-wide/high16 v0, -0x8000000000000000L

    const-wide/high16 v0, -0x8000000000000000L

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-object v0
.end method

.method public n(Ljava/lang/Long;)Ljava/lang/Long;
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x1

    const-wide v2, 0x7fffffffffffffffL

    const-wide v2, 0x7fffffffffffffffL

    const/4 v5, 0x4

    const-wide v2, 0x7fffffffffffffffL

    const-wide v2, 0x7fffffffffffffffL

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x1

    cmp-long p1, v0, v2

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x6

    if-nez p1, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x7

    const/4 p1, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x4

    goto :goto_0

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x1

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v5, 0x0

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    add-long/2addr v0, v2

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    return-object p1
.end method

.method o(Ljava/lang/Long;J)Ljava/lang/Long;
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "origin",
            "distance"
        }
    .end annotation

    const/4 v5, 0x6

    const/4 v4, 0x1

    const-string/jumbo v0, "tnimcdse"

    const-string v0, "ctsdesin"

    const-string v0, "ctieonds"

    const-string v0, "distance"

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-static {p2, p3, v0}, Lcom/google/common/collect/e4;->c(JLjava/lang/String;)J

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    const/4 v5, 0x6

    add-long/2addr v0, p2

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x6

    const-wide/16 p2, 0x0

    const/4 v5, 0x4

    const-wide/16 p2, 0x0

    const-wide/16 p2, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x0

    cmp-long v2, v0, p2

    const/4 v5, 0x7

    const/4 v4, 0x0

    if-gez v2, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide v2

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x3

    cmp-long p1, v2, p2

    if-gez p1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x2

    const/4 p1, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x0

    goto :goto_0

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    const/4 p1, 0x0

    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x0

    const-string/jumbo p2, "overwbfo"

    const-string/jumbo p2, "overflow"

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-static {p1, p2}, Lcom/google/common/base/u0;->e(ZLjava/lang/Object;)V

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    return-object p1
.end method

.method public p(Ljava/lang/Long;)Ljava/lang/Long;
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x5

    const-wide/high16 v2, -0x8000000000000000L

    const-wide/high16 v2, -0x8000000000000000L

    const/4 v5, 0x1

    const-wide/high16 v2, -0x8000000000000000L

    const-wide/high16 v2, -0x8000000000000000L

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x0

    cmp-long p1, v0, v2

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x1

    if-nez p1, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x2

    const/4 p1, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x5

    goto :goto_0

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x7

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v5, 0x1

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x7

    sub-long/2addr v0, v2

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x7

    return-object p1
.end method

.method public toString()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    const-string/jumbo v0, "iin)(cugesmn.rtoeDDmlo"

    const-string v0, "DasmooDe)mnlie.irc(gnt"

    const/4 v2, 0x4

    const-string v0, "DDc.g)ipoetms(eaironns"

    const-string v0, "DiscreteDomain.longs()"

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-object v0
.end method
