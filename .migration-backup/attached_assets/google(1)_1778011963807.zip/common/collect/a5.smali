.class public final synthetic Lcom/google/common/collect/a5;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/function/Consumer;


# instance fields
.field public final synthetic a:Lcom/google/common/collect/p4$d;


# direct methods
.method public synthetic constructor <init>(Lcom/google/common/collect/p4$d;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/google/common/collect/a5;->a:Lcom/google/common/collect/p4$d;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public final accept(Ljava/lang/Object;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~@sif@ t@Kr i@~o bmc@ ~y~@f@os~@ i@ t@~~@ ~o~o/@@~~ @. b~ 1a@M~S~v l~  ~~@@~~-4unb ~lo @~d~o/@@ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/common/collect/a5;->a:Lcom/google/common/collect/p4$d;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-static {v0, p1}, Lcom/google/common/collect/p4$d;->b(Lcom/google/common/collect/p4$d;Ljava/lang/Object;)V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-void
.end method
