.class public final synthetic Lcom/google/common/collect/ch;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Ljava/util/Optional;)Ljava/lang/Object;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@~s a@f@~di~@@@sr ~b-~ mn~ ~@@ t~b~~ 1@~Sift~~/ oi~~ yocK@@@/ olo~@@@.o v  @~4@bo~ ~M@~lu@@  ~  "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    invoke-virtual {p0}, Ljava/util/Optional;->get()Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-object p0
.end method
