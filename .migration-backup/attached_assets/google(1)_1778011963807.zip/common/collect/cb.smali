.class public final synthetic Lcom/google/common/collect/cb;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/function/Function;


# instance fields
.field public final synthetic a:Ljava/util/Comparator;


# direct methods
.method public synthetic constructor <init>(Ljava/util/Comparator;)V
    .locals 2

    const/4 v0, 0x7

    move v1, v0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x2

    iput-object p1, p0, Lcom/google/common/collect/cb;->a:Ljava/util/Comparator;

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public final apply(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/common/collect/cb;->a:Ljava/util/Comparator;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    check-cast p1, Lcom/google/common/collect/ae;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-static {v0, p1}, Lcom/google/common/collect/db;->U(Ljava/util/Comparator;Lcom/google/common/collect/ae;)Lcom/google/common/collect/db;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-object p1
.end method
