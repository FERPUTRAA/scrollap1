.class public final synthetic Lcom/google/common/collect/ad;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Ljava/util/NavigableSet;Ljava/util/function/Consumer;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@rs @s~K~ @~a~@~i@m@~ot~b ~@~b@ ti @-o@o @/fu@v.1/~~f @~~o 4~ ~ ~@@o ~@@c l   Md~ ~@n~yi~Sl@b~o@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    invoke-interface {p0, p1}, Ljava/util/NavigableSet;->forEach(Ljava/util/function/Consumer;)V

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-void
.end method
