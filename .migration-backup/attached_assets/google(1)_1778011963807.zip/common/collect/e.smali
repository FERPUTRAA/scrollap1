.class public abstract Lcom/google/common/collect/e;
.super Lcom/google/common/collect/am;


# annotations
.annotation runtime Lcom/google/common/collect/d7;
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/common/collect/e$b;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lcom/google/common/collect/am<",
        "TT;>;"
    }
.end annotation

.annotation build Lx4/b;
.end annotation


# instance fields
.field private a:Lcom/google/common/collect/e$b;

.field private b:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TT;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation
.end field


# direct methods
.method protected constructor <init>()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-direct {p0}, Lcom/google/common/collect/am;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x5

    sget-object v0, Lcom/google/common/collect/e$b;->b:Lcom/google/common/collect/e$b;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/google/common/collect/e;->a:Lcom/google/common/collect/e$b;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-void
.end method

.method private c()Z
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~ls Ki/   co~o~~S- M@.~@~~oy@@@~d~~~f@ibsv t~@  @n/t@1 @~ lu@@~@~@fa@ @o  i@o~@r@~o ~@  m~~b~b4~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    sget-object v0, Lcom/google/common/collect/e$b;->d:Lcom/google/common/collect/e$b;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/google/common/collect/e;->a:Lcom/google/common/collect/e$b;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/google/common/collect/e;->a()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/google/common/collect/e;->b:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/common/collect/e;->a:Lcom/google/common/collect/e$b;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    sget-object v1, Lcom/google/common/collect/e$b;->c:Lcom/google/common/collect/e$b;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    if-eq v0, v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    sget-object v0, Lcom/google/common/collect/e$b;->a:Lcom/google/common/collect/e$b;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/google/common/collect/e;->a:Lcom/google/common/collect/e$b;

    const/4 v3, 0x2

    const/4 v0, 0x1

    const/4 v3, 0x7

    shl-int/2addr v2, v0

    const/4 v3, 0x3

    return v0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    const/4 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    return v0
.end method


# virtual methods
.method protected abstract a()Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation
.end method

.method protected final b()Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    sget-object v0, Lcom/google/common/collect/e$b;->c:Lcom/google/common/collect/e$b;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/google/common/collect/e;->a:Lcom/google/common/collect/e$b;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object v0
.end method

.method public final hasNext()Z
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/google/common/collect/e;->a:Lcom/google/common/collect/e$b;

    const/4 v4, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    sget-object v1, Lcom/google/common/collect/e$b;->d:Lcom/google/common/collect/e$b;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x3

    const/4 v2, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x3

    const/4 v3, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x2

    if-eq v0, v1, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x1

    move v0, v3

    move v0, v3

    move v0, v3

    move v0, v3

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x6

    goto :goto_0

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x7

    move v0, v2

    move v0, v2

    const/4 v5, 0x3

    move v0, v2

    move v0, v2

    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-static {v0}, Lcom/google/common/base/u0;->g0(Z)V

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    sget-object v0, Lcom/google/common/collect/e$a;->a:[I

    const/4 v5, 0x4

    iget-object v1, p0, Lcom/google/common/collect/e;->a:Lcom/google/common/collect/e$b;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x1

    aget v0, v0, v1

    const/4 v4, 0x2

    shl-int/2addr v5, v4

    if-eq v0, v3, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    const/4 v1, 0x2

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    if-eq v0, v1, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-direct {p0}, Lcom/google/common/collect/e;->c()Z

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    return v0

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x0

    return v3

    :cond_2
    const/4 v5, 0x3

    const/4 v4, 0x0

    return v2
.end method

.method public final next()Ljava/lang/Object;
    .locals 4
    .annotation runtime Lcom/google/common/collect/me;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/google/common/collect/e;->hasNext()Z

    move-result v0

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    sget-object v0, Lcom/google/common/collect/e$b;->b:Lcom/google/common/collect/e$b;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/google/common/collect/e;->a:Lcom/google/common/collect/e$b;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/common/collect/e;->b:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-static {v0}, Lcom/google/common/collect/he;->a(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    iput-object v1, p0, Lcom/google/common/collect/e;->b:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-object v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    new-instance v0, Ljava/util/NoSuchElementException;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-direct {v0}, Ljava/util/NoSuchElementException;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    throw v0
.end method

.method public final peek()Ljava/lang/Object;
    .locals 3
    .annotation runtime Lcom/google/common/collect/me;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/common/collect/e;->hasNext()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/common/collect/e;->b:Ljava/lang/Object;

    const/4 v1, 0x2

    move v2, v1

    invoke-static {v0}, Lcom/google/common/collect/he;->a(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x2

    return-object v0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x6

    new-instance v0, Ljava/util/NoSuchElementException;

    const/4 v1, 0x2

    xor-int/2addr v2, v1

    invoke-direct {v0}, Ljava/util/NoSuchElementException;-><init>()V

    throw v0
.end method
