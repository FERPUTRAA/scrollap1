.class public final synthetic Lcom/google/common/collect/gf;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/Comparator;


# instance fields
.field public final synthetic a:Ljava/util/Comparator;

.field public final synthetic b:Ljava/util/Comparator;


# direct methods
.method public synthetic constructor <init>(Ljava/util/Comparator;Ljava/util/Comparator;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/google/common/collect/gf;->a:Ljava/util/Comparator;

    const/4 v1, 0x1

    const/4 v0, 0x6

    iput-object p2, p0, Lcom/google/common/collect/gf;->b:Ljava/util/Comparator;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public final compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "bvs @ 4@~ s~fta@S~@i@@@bo@~~c / /@~ ~~@t~~Kn~i.  @oo~@l~@~  fiM @~ y ouom@l dr~@o~ b~~@@ ~@~ 1~@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/common/collect/gf;->a:Ljava/util/Comparator;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    iget-object v1, p0, Lcom/google/common/collect/gf;->b:Ljava/util/Comparator;

    const/4 v3, 0x4

    check-cast p1, Lcom/google/common/collect/bl$a;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    check-cast p2, Lcom/google/common/collect/bl$a;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-static {v0, v1, p1, p2}, Lcom/google/common/collect/hf;->M(Ljava/util/Comparator;Ljava/util/Comparator;Lcom/google/common/collect/bl$a;Lcom/google/common/collect/bl$a;)I

    move-result p1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    return p1
.end method
