.class public final synthetic Lcom/google/common/collect/g;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Ljava/util/Map;Ljava/util/function/BiConsumer;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "o sld1@@tM @i~.~@ -o~@ @~~b r@/~@~~@@~~ o c ~~v ~~@K @~iy~~sf mSi n@@f  l~~b @o~b4@~@u@ooa  t@~/"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    invoke-interface {p0, p1}, Ljava/util/Map;->forEach(Ljava/util/function/BiConsumer;)V

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-void
.end method
