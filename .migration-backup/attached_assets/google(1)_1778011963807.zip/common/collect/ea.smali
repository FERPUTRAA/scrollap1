.class public final synthetic Lcom/google/common/collect/ea;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/function/BiConsumer;


# instance fields
.field public final synthetic a:Ljava/util/function/BiConsumer;


# direct methods
.method public synthetic constructor <init>(Ljava/util/function/BiConsumer;)V
    .locals 2

    const/4 v0, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/google/common/collect/ea;->a:Ljava/util/function/BiConsumer;

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public final accept(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/common/collect/ea;->a:Ljava/util/function/BiConsumer;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    check-cast p2, Ljava/util/Collection;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-static {v0, p1, p2}, Lcom/google/common/collect/ia;->p(Ljava/util/function/BiConsumer;Ljava/lang/Object;Ljava/util/Collection;)V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-void
.end method
