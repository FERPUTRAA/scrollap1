.class public abstract Lcom/google/common/collect/c7;
.super Ljava/lang/Object;


# annotations
.annotation runtime Lcom/google/common/collect/d7;
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/common/collect/c7$b;,
        Lcom/google/common/collect/c7$d;,
        Lcom/google/common/collect/c7$c;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<C::",
        "Ljava/lang/Comparable;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation

.annotation build Lx4/b;
.end annotation


# instance fields
.field final supportsFastOffset:Z


# direct methods
.method protected constructor <init>()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-direct {p0, v0}, Lcom/google/common/collect/c7;-><init>(Z)V

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-void
.end method

.method private constructor <init>(Z)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "supportsFastOffset"
        }
    .end annotation

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput-boolean p1, p0, Lcom/google/common/collect/c7;->supportsFastOffset:Z

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-void
.end method

.method synthetic constructor <init>(ZLcom/google/common/collect/c7$a;)V
    .locals 2

    const/4 v1, 0x7

    invoke-direct {p0, p1}, Lcom/google/common/collect/c7;-><init>(Z)V

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method

.method public static a()Lcom/google/common/collect/c7;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/collect/c7<",
            "Ljava/math/BigInteger;",
            ">;"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " Ks ib~mduf1@~ bc~~i@l@. - ~ @~rM~~i/~@o~@~oo@  s~~~t~~o/ f@ @@Sy@ @@@o on@~v~ l~@ ~@ t~@4ba~  @"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    invoke-static {}, Lcom/google/common/collect/c7$b;->j()Lcom/google/common/collect/c7$b;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-object v0
.end method

.method public static c()Lcom/google/common/collect/c7;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/collect/c7<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-static {}, Lcom/google/common/collect/c7$c;->j()Lcom/google/common/collect/c7$c;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-object v0
.end method

.method public static d()Lcom/google/common/collect/c7;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/collect/c7<",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-static {}, Lcom/google/common/collect/c7$d;->j()Lcom/google/common/collect/c7$d;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-object v0
.end method


# virtual methods
.method public abstract b(Ljava/lang/Comparable;Ljava/lang/Comparable;)J
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "start",
            "end"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TC;TC;)J"
        }
    .end annotation
.end method

.method public e()Ljava/lang/Comparable;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TC;"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    new-instance v0, Ljava/util/NoSuchElementException;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-direct {v0}, Ljava/util/NoSuchElementException;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    throw v0
.end method

.method public f()Ljava/lang/Comparable;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TC;"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    new-instance v0, Ljava/util/NoSuchElementException;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-direct {v0}, Ljava/util/NoSuchElementException;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    throw v0
.end method

.method public abstract g(Ljava/lang/Comparable;)Ljava/lang/Comparable;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TC;)TC;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation
.end method

.method h(Ljava/lang/Comparable;J)Ljava/lang/Comparable;
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "origin",
            "distance"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TC;J)TC;"
        }
    .end annotation

    const/4 v6, 0x4

    const/4 v5, 0x4

    const-string/jumbo v0, "senmcaid"

    const-string v0, "cisanetd"

    const/4 v6, 0x7

    const-string/jumbo v0, "tcenoadi"

    const-string v0, "distance"

    const/4 v5, 0x6

    move v6, v5

    invoke-static {p2, p3, v0}, Lcom/google/common/collect/e4;->c(JLjava/lang/String;)J

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x4

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v6, 0x6

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    :goto_0
    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x1

    cmp-long v3, v0, p2

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x3

    if-gez v3, :cond_1

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-virtual {p0, v2}, Lcom/google/common/collect/c7;->g(Ljava/lang/Comparable;)Ljava/lang/Comparable;

    move-result-object v2

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x1

    if-eqz v2, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x3

    const-wide/16 v3, 0x1

    const-wide/16 v3, 0x1

    const/4 v6, 0x3

    const-wide/16 v3, 0x1

    const-wide/16 v3, 0x1

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x0

    add-long/2addr v0, v3

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x4

    goto :goto_0

    :cond_0
    const/4 v6, 0x4

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x4

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x5

    const/4 v5, 0x3

    const-string/jumbo v2, "ffeiob(drtleovwogne tms pfmu"

    const-string/jumbo v2, "tl(mvoigfeow pemonsfufoerdt "

    const/4 v6, 0x0

    const-string/jumbo v2, "overflowed computing offset("

    const/4 v6, 0x2

    const/4 v5, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x4

    const-string p1, ", "

    const-string p1, ", "

    const/4 v6, 0x6

    const-string p1, ", "

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-virtual {v1, p2, p3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const-string p1, ")"

    const-string p1, ")"

    const-string p1, ")"

    const-string p1, ")"

    const/4 v5, 0x3

    move v6, v5

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x5

    throw v0

    :cond_1
    const/4 v5, 0x6

    move v6, v5

    return-object v2
.end method

.method public abstract i(Ljava/lang/Comparable;)Ljava/lang/Comparable;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TC;)TC;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation
.end method
