.class Lcom/google/common/collect/c$b;
.super Lcom/google/common/collect/l8;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/collect/c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/common/collect/l8<",
        "TK;TV;>;"
    }
.end annotation


# instance fields
.field private final a:Ljava/util/Map$Entry;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map$Entry<",
            "TK;TV;>;"
        }
    .end annotation
.end field

.field final synthetic b:Lcom/google/common/collect/c;


# direct methods
.method constructor <init>(Lcom/google/common/collect/c;Ljava/util/Map$Entry;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x0
        }
        names = {
            "this$0",
            "delegate"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map$Entry<",
            "TK;TV;>;)V"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x6

    iput-object p1, p0, Lcom/google/common/collect/c$b;->b:Lcom/google/common/collect/c;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/google/common/collect/l8;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput-object p2, p0, Lcom/google/common/collect/c$b;->a:Ljava/util/Map$Entry;

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method protected bridge synthetic g0()Ljava/lang/Object;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "S~s~@1t@~@i  u~f~@b~@ @~r@  @ v~m 4~dlM@ ~@~@o~~~K /fb c @~o y~/oio@ba~n@ ~ ~ ~o@ o ~@.@@@@ilst~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/common/collect/c$b;->i0()Ljava/util/Map$Entry;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object v0
.end method

.method protected i0()Ljava/util/Map$Entry;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map$Entry<",
            "TK;TV;>;"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/common/collect/c$b;->a:Ljava/util/Map$Entry;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object v0
.end method

.method public setValue(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TV;)TV;"
        }
    .end annotation

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x2

    iget-object v0, p0, Lcom/google/common/collect/c$b;->b:Lcom/google/common/collect/c;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-virtual {v0, p1}, Lcom/google/common/collect/c;->C0(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x5

    iget-object v0, p0, Lcom/google/common/collect/c$b;->b:Lcom/google/common/collect/c;

    const/4 v6, 0x1

    const/4 v5, 0x4

    invoke-virtual {v0}, Lcom/google/common/collect/c;->entrySet()Ljava/util/Set;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-interface {v0, p0}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v0

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x0

    const-string/jumbo v1, "tpnmynn ma r enorils g"

    const-string v1, " isgnr enayon mnelpr t"

    const/4 v6, 0x5

    const-string/jumbo v1, "n rionnprlaogeo  ymen "

    const-string v1, "entry no longer in map"

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-static {v0, v1}, Lcom/google/common/base/u0;->h0(ZLjava/lang/Object;)V

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {p0}, Lcom/google/common/collect/l8;->getValue()Ljava/lang/Object;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-static {p1, v0}, Lcom/google/common/base/m0;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x4

    if-eqz v0, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x0

    return-object p1

    :cond_0
    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x2

    iget-object v0, p0, Lcom/google/common/collect/c$b;->b:Lcom/google/common/collect/c;

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {v0, p1}, Lcom/google/common/collect/c;->containsValue(Ljava/lang/Object;)Z

    move-result v0

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x0

    const/4 v2, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x4

    xor-int/2addr v0, v2

    const/4 v5, 0x7

    move v6, v5

    const-string v3, "elv:abydreersp nl %ueatms"

    const-string v3, "aelm :yalr %dnevsutaprees"

    const/4 v6, 0x5

    const-string v3, "%laps ueavdaeelyn  :tesru"

    const-string/jumbo v3, "value already present: %s"

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-static {v0, v3, p1}, Lcom/google/common/base/u0;->u(ZLjava/lang/String;Ljava/lang/Object;)V

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x5

    iget-object v0, p0, Lcom/google/common/collect/c$b;->a:Ljava/util/Map$Entry;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-interface {v0, p1}, Ljava/util/Map$Entry;->setValue(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x6

    iget-object v3, p0, Lcom/google/common/collect/c$b;->b:Lcom/google/common/collect/c;

    const/4 v6, 0x7

    const/4 v5, 0x1

    invoke-virtual {p0}, Lcom/google/common/collect/l8;->getKey()Ljava/lang/Object;

    move-result-object v4

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {v3, v4}, Lcom/google/common/collect/k8;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-static {p1, v3}, Lcom/google/common/base/m0;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-static {v3, v1}, Lcom/google/common/base/u0;->h0(ZLjava/lang/Object;)V

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x4

    iget-object v1, p0, Lcom/google/common/collect/c$b;->b:Lcom/google/common/collect/c;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {p0}, Lcom/google/common/collect/l8;->getKey()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x3

    const/4 v5, 0x7

    invoke-static {v1, v3, v2, v0, p1}, Lcom/google/common/collect/c;->z0(Lcom/google/common/collect/c;Ljava/lang/Object;ZLjava/lang/Object;Ljava/lang/Object;)V

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x7

    return-object v0
.end method
