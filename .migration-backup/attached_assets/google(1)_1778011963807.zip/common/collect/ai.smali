.class public final synthetic Lcom/google/common/collect/ai;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Ljava/util/Spliterator$OfDouble;)I
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    invoke-interface {p0}, Ljava/util/Spliterator$OfDouble;->characteristics()I

    move-result p0

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x1

    return p0
.end method
