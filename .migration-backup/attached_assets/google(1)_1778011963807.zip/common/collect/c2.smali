.class public final synthetic Lcom/google/common/collect/c2;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/function/BinaryOperator;


# direct methods
.method public synthetic constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public final apply(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " @sb S~~@-4@ l a@ @@1K@ .ofr~@c@mu/@ t@~o~~ ~~ M@v@~@~~bdt~s~    f@~ @o/@io i@~y~ o~~lno~i~~~ @@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    check-cast p1, Lcom/google/common/collect/k9$a;

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x4

    check-cast p2, Lcom/google/common/collect/k9$a;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-virtual {p1, p2}, Lcom/google/common/collect/k9$a;->r(Lcom/google/common/collect/w9$b;)Lcom/google/common/collect/k9$a;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-object p1
.end method
