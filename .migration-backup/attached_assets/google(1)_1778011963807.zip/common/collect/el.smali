.class public final synthetic Lcom/google/common/collect/el;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/function/Function;


# direct methods
.method public synthetic constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x0

    return-void
.end method


# virtual methods
.method public final apply(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "v@s o1@ /.~ @ b~f ~@ ~@~ ~M~@@i fn~@ d cr~~~o@@buab- @K~@o~~ol@~Si @@4~  ~@t@~o  @ @iytm/@~~~~lo"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    check-cast p1, Lcom/google/common/collect/ol$b;

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-static {p1}, Lcom/google/common/collect/ol;->e(Lcom/google/common/collect/ol$b;)Lcom/google/common/collect/hb;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-object p1
.end method
