.class public final synthetic Lcom/google/common/collect/fi;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Ljava/util/Spliterator;)Ljava/util/Iterator;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~@sK  ~@ ~ o@@d /~trv@~ao@@@ @1uo~@~ @b~c~~4 ~@@~y.oM bl   o fmi~@l@n- @ t@i~ S~~s~ ~of@@i~~~/~b"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    invoke-static {p0}, Ljava/util/Spliterators;->iterator(Ljava/util/Spliterator;)Ljava/util/Iterator;

    move-result-object p0

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-object p0
.end method
