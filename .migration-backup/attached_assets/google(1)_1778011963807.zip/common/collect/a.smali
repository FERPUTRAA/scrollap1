.class public final synthetic Lcom/google/common/collect/a;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Ljava/util/Map;Ljava/util/function/BiFunction;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~ s~M K~@t i@  /@f~bu@~@~@4~mv @a~l@1/@@~@@@c~S   d~o b~tn~@o~o~~o- @o @fiy~ @i ~@@l~@~~ ~bs o r"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x3

    invoke-interface {p0, p1}, Ljava/util/Map;->replaceAll(Ljava/util/function/BiFunction;)V

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method
