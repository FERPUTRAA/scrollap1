.class public final synthetic Lcom/google/common/collect/d2;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/function/Function;


# direct methods
.method public synthetic constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public final apply(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~ s~b.i@@~cl@/oo@@~@@S~~f ~ ~M~@4~@lb1@~f @d  @@obo @s~@ m@~-   u~~~~i @~ toinoK~v~@/@at  r~@y~ "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    check-cast p1, Lcom/google/common/collect/k9$a;

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-virtual {p1}, Lcom/google/common/collect/k9$a;->n()Lcom/google/common/collect/k9;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x3

    return-object p1
.end method
