.class public final synthetic Lcom/google/common/collect/fj;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Ljava/util/Optional;Ljava/util/function/Function;)Ljava/util/Optional;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "dvs~/ ~@o   rtbil@~@ ~o K~~M ~f~/b@~ S~@fo@ ~@ o@  l~ba~~~~@i~~@~@~n@i@4 ~@@ .yuc m -~t@ o1os@@@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x3

    invoke-virtual {p0, p1}, Ljava/util/Optional;->map(Ljava/util/function/Function;)Ljava/util/Optional;

    move-result-object p0

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-object p0
.end method
