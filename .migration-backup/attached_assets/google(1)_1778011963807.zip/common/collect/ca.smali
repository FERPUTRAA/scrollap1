.class public final synthetic Lcom/google/common/collect/ca;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/function/BiConsumer;


# instance fields
.field public final synthetic a:Ljava/util/function/Consumer;


# direct methods
.method public synthetic constructor <init>(Ljava/util/function/Consumer;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/google/common/collect/ca;->a:Ljava/util/function/Consumer;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public final accept(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@os i@t a@@ tl~ -@oysfbS~u@~  f~@@ln@~ r~~~//  bKb~o.o~~v @@@~~ ~ @doc@@ @~~~@~m~ 1 @4o@~i Mi ~@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/common/collect/ca;->a:Ljava/util/function/Consumer;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-static {v0, p1, p2}, Lcom/google/common/collect/da;->i(Ljava/util/function/Consumer;Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-void
.end method
