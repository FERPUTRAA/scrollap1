.class final Lcom/google/common/collect/db$b;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/io/Serializable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/collect/db;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<E:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Ljava/io/Serializable;"
    }
.end annotation

.annotation build Lx4/d;
.end annotation


# instance fields
.field final comparator:Ljava/util/Comparator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Comparator<",
            "-TE;>;"
        }
    .end annotation
.end field

.field final counts:[I

.field final elements:[Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[TE;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lcom/google/common/collect/lg;)V
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "multiset"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/collect/lg<",
            "TE;>;)V"
        }
    .end annotation

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-interface {p1}, Lcom/google/common/collect/lg;->comparator()Ljava/util/Comparator;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x0

    iput-object v0, p0, Lcom/google/common/collect/db$b;->comparator:Ljava/util/Comparator;

    const/4 v4, 0x5

    shr-int/2addr v5, v4

    invoke-interface {p1}, Lcom/google/common/collect/lg;->entrySet()Ljava/util/Set;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x5

    invoke-interface {v0}, Ljava/util/Set;->size()I

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x4

    new-array v1, v0, [Ljava/lang/Object;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    iput-object v1, p0, Lcom/google/common/collect/db$b;->elements:[Ljava/lang/Object;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x0

    new-array v0, v0, [I

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x4

    iput-object v0, p0, Lcom/google/common/collect/db$b;->counts:[I

    const/4 v4, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-interface {p1}, Lcom/google/common/collect/lg;->entrySet()Ljava/util/Set;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x6

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x6

    if-eqz v1, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    check-cast v1, Lcom/google/common/collect/ae$a;

    const/4 v5, 0x5

    const/4 v4, 0x2

    iget-object v2, p0, Lcom/google/common/collect/db$b;->elements:[Ljava/lang/Object;

    const/4 v4, 0x6

    or-int/2addr v5, v4

    invoke-interface {v1}, Lcom/google/common/collect/ae$a;->a()Ljava/lang/Object;

    move-result-object v3

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x6

    aput-object v3, v2, v0

    const/4 v4, 0x1

    const/4 v5, 0x3

    iget-object v2, p0, Lcom/google/common/collect/db$b;->counts:[I

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-interface {v1}, Lcom/google/common/collect/ae$a;->getCount()I

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x6

    aput v1, v2, v0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x6

    add-int/lit8 v0, v0, 0x1

    const/4 v4, 0x0

    const/4 v4, 0x3

    goto :goto_0

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x1

    return-void
.end method


# virtual methods
.method readResolve()Ljava/lang/Object;
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v5, "n.sl@f~ d~ @@/ tK@b4~  fa o@@~1~ to ~ ~@u S~o~@lo@~@  mM @ro@~@~vb@@s-~~@yo~i@b~ c~~~@~@@ i  ~~/"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x6

    iget-object v0, p0, Lcom/google/common/collect/db$b;->elements:[Ljava/lang/Object;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x1

    array-length v0, v0

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x4

    new-instance v1, Lcom/google/common/collect/db$a;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x6

    iget-object v2, p0, Lcom/google/common/collect/db$b;->comparator:Ljava/util/Comparator;

    const/4 v6, 0x4

    const/4 v5, 0x6

    invoke-direct {v1, v2}, Lcom/google/common/collect/db$a;-><init>(Ljava/util/Comparator;)V

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x4

    const/4 v2, 0x0

    :goto_0
    const/4 v5, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x1

    if-ge v2, v0, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x6

    iget-object v3, p0, Lcom/google/common/collect/db$b;->elements:[Ljava/lang/Object;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x4

    aget-object v3, v3, v2

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x1

    iget-object v4, p0, Lcom/google/common/collect/db$b;->counts:[I

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x3

    aget v4, v4, v2

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {v1, v3, v4}, Lcom/google/common/collect/db$a;->u(Ljava/lang/Object;I)Lcom/google/common/collect/db$a;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x1

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x6

    goto :goto_0

    :cond_0
    const/4 v5, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-virtual {v1}, Lcom/google/common/collect/db$a;->v()Lcom/google/common/collect/db;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x6

    return-object v0
.end method
