.class public final synthetic Lcom/google/common/collect/f4;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(II)Ljava/util/stream/IntStream;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, ".~s4@rm~@ ~o~i~@lS @~b@o~~f1 b aoc@ @ ~t ~@o@-@i~~@@~v~   ~@~M@u~@@ols~@ f   b//@o~d  @ @~i~yK~n"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    invoke-static {p0, p1}, Ljava/util/stream/IntStream;->range(II)Ljava/util/stream/IntStream;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-object p0
.end method
