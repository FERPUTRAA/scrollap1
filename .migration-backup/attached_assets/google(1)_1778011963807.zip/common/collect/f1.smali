.class public final synthetic Lcom/google/common/collect/f1;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/function/BinaryOperator;


# direct methods
.method public synthetic constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public final apply(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@@so~ ~b~~/~~~r1 K~@o~~@~liy@f ~ @~~~s f~t~@  @  ~il~o/t @ n@~@ b.o@Sba @m~@@vo@i~o4u d@M-c @ @@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    check-cast p1, Lcom/google/common/collect/ae;

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x4

    check-cast p2, Lcom/google/common/collect/ae;

    const/4 v1, 0x0

    invoke-static {p1, p2}, Lcom/google/common/collect/c4;->s(Lcom/google/common/collect/ae;Lcom/google/common/collect/ae;)Lcom/google/common/collect/ae;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-object p1
.end method
