.class public final synthetic Lcom/google/common/collect/cj;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a()Ljava/util/stream/LongStream;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " ~s t@t-K n@ ~ oSm. fbu~ @b@~ 4 sr~@@@ @ol~~/oa~@~@i~@yl~boof  @~~/ @~ @~~ic~M@o@@~@~d @i  1~v~@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    invoke-static {}, Ljava/util/stream/LongStream;->empty()Ljava/util/stream/LongStream;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-object v0
.end method
