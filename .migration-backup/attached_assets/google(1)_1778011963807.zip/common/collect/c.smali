.class abstract Lcom/google/common/collect/c;
.super Lcom/google/common/collect/k8;

# interfaces
.implements Lcom/google/common/collect/r0;
.implements Ljava/io/Serializable;


# annotations
.annotation runtime Lcom/google/common/collect/d7;
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/common/collect/c$d;,
        Lcom/google/common/collect/c$c;,
        Lcom/google/common/collect/c$b;,
        Lcom/google/common/collect/c$f;,
        Lcom/google/common/collect/c$e;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<K:",
        "Ljava/lang/Object;",
        "V:",
        "Ljava/lang/Object;",
        ">",
        "Lcom/google/common/collect/k8<",
        "TK;TV;>;",
        "Lcom/google/common/collect/r0<",
        "TK;TV;>;",
        "Ljava/io/Serializable;"
    }
.end annotation

.annotation build Lx4/b;
    emulated = true
.end annotation


# static fields
.field private static final serialVersionUID:J
    .annotation build Lx4/c;
    .end annotation

    .annotation build Lx4/d;
    .end annotation
.end field


# instance fields
.field private transient a:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "TK;TV;>;"
        }
    .end annotation
.end field

.field transient b:Lcom/google/common/collect/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/collect/c<",
            "TV;TK;>;"
        }
    .end annotation

    .annotation build Lf6/i;
    .end annotation
.end field

.field private transient c:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "TK;>;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation
.end field

.field private transient d:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "TV;>;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation
.end field

.field private transient e:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/util/Map$Entry<",
            "TK;TV;>;>;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation
.end field


# direct methods
.method private constructor <init>(Ljava/util/Map;Lcom/google/common/collect/c;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "backward",
            "forward"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "TK;TV;>;",
            "Lcom/google/common/collect/c<",
            "TV;TK;>;)V"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-direct {p0}, Lcom/google/common/collect/k8;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x6

    iput-object p1, p0, Lcom/google/common/collect/c;->a:Ljava/util/Map;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput-object p2, p0, Lcom/google/common/collect/c;->b:Lcom/google/common/collect/c;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method

.method synthetic constructor <init>(Ljava/util/Map;Lcom/google/common/collect/c;Lcom/google/common/collect/c$a;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    invoke-direct {p0, p1, p2}, Lcom/google/common/collect/c;-><init>(Ljava/util/Map;Lcom/google/common/collect/c;)V

    const/4 v0, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method

.method constructor <init>(Ljava/util/Map;Ljava/util/Map;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "forward",
            "backward"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "TK;TV;>;",
            "Ljava/util/Map<",
            "TV;TK;>;)V"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-direct {p0}, Lcom/google/common/collect/k8;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-virtual {p0, p1, p2}, Lcom/google/common/collect/c;->I0(Ljava/util/Map;Ljava/util/Map;)V

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void
.end method

.method static synthetic A0(Lcom/google/common/collect/c;Ljava/lang/Object;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "blsb~ @m@~f~~ @@t~@i @y~@vt  ~o~a~u~d~ ~@ ~~@@i@ -l@~n /c~@o~ @rf@4  @ ~i@M@ / Ko~~~@ooso1@~.  b"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    invoke-direct {p0, p1}, Lcom/google/common/collect/c;->H0(Ljava/lang/Object;)V

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method

.method private F0(Ljava/lang/Object;Ljava/lang/Object;Z)Ljava/lang/Object;
    .locals 4
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lcom/google/common/collect/me;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Object;
        .annotation runtime Lcom/google/common/collect/me;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "key",
            "value",
            "force"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TK;TV;Z)TV;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {p0, p1}, Lcom/google/common/collect/c;->B0(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {p0, p2}, Lcom/google/common/collect/c;->C0(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {p0, p1}, Lcom/google/common/collect/k8;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {p0, p1}, Lcom/google/common/collect/k8;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-static {p2, v1}, Lcom/google/common/base/m0;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-eqz v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x6

    return-object p2

    :cond_0
    const/4 v3, 0x1

    if-eqz p3, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/google/common/collect/c;->u0()Lcom/google/common/collect/r0;

    move-result-object p3

    const/4 v3, 0x4

    const/4 v2, 0x2

    invoke-interface {p3, p2}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x2

    goto :goto_0

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {p0, p2}, Lcom/google/common/collect/c;->containsValue(Ljava/lang/Object;)Z

    move-result p3

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    xor-int/lit8 p3, p3, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    const-string/jumbo v1, "p%saversdn l:steeeuy aa r"

    const/4 v3, 0x6

    const-string v1, "e %mlla:erye adetpsvn ras"

    const-string/jumbo v1, "value already present: %s"

    const/4 v2, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-static {p3, v1, p2}, Lcom/google/common/base/u0;->u(ZLjava/lang/String;Ljava/lang/Object;)V

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x6

    iget-object p3, p0, Lcom/google/common/collect/c;->a:Ljava/util/Map;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-interface {p3, p1, p2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p3

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-direct {p0, p1, v0, p3, p2}, Lcom/google/common/collect/c;->K0(Ljava/lang/Object;ZLjava/lang/Object;Ljava/lang/Object;)V

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-object p3
.end method

.method private G0(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation runtime Lcom/google/common/collect/me;
    .end annotation

    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "key"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            ")TV;"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/common/collect/c;->a:Ljava/util/Map;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-interface {v0, p1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-static {p1}, Lcom/google/common/collect/he;->a(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x3

    invoke-direct {p0, p1}, Lcom/google/common/collect/c;->H0(Ljava/lang/Object;)V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-object p1
.end method

.method private H0(Ljava/lang/Object;)V
    .locals 3
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lcom/google/common/collect/me;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "oldValue"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TV;)V"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x2

    iget-object v0, p0, Lcom/google/common/collect/c;->b:Lcom/google/common/collect/c;

    const/4 v2, 0x0

    iget-object v0, v0, Lcom/google/common/collect/c;->a:Ljava/util/Map;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-interface {v0, p1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-void
.end method

.method private K0(Ljava/lang/Object;ZLjava/lang/Object;Ljava/lang/Object;)V
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lcom/google/common/collect/me;
        .end annotation
    .end param
    .param p3    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .param p4    # Ljava/lang/Object;
        .annotation runtime Lcom/google/common/collect/me;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "key",
            "containedKey",
            "oldValue",
            "newValue"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TK;ZTV;TV;)V"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x3

    if-eqz p2, :cond_0

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-static {p3}, Lcom/google/common/collect/he;->a(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-direct {p0, p2}, Lcom/google/common/collect/c;->H0(Ljava/lang/Object;)V

    :cond_0
    iget-object p2, p0, Lcom/google/common/collect/c;->b:Lcom/google/common/collect/c;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x4

    iget-object p2, p2, Lcom/google/common/collect/c;->a:Ljava/util/Map;

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-interface {p2, p4, p1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-void
.end method

.method static synthetic x0(Lcom/google/common/collect/c;)Ljava/util/Map;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x4

    iget-object p0, p0, Lcom/google/common/collect/c;->a:Ljava/util/Map;

    const/4 v1, 0x7

    return-object p0
.end method

.method static synthetic y0(Lcom/google/common/collect/c;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x5

    invoke-direct {p0, p1}, Lcom/google/common/collect/c;->G0(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-object p0
.end method

.method static synthetic z0(Lcom/google/common/collect/c;Ljava/lang/Object;ZLjava/lang/Object;Ljava/lang/Object;)V
    .locals 2

    const/4 v0, 0x1

    move v1, v0

    invoke-direct {p0, p1, p2, p3, p4}, Lcom/google/common/collect/c;->K0(Ljava/lang/Object;ZLjava/lang/Object;Ljava/lang/Object;)V

    const/4 v0, 0x5

    and-int/2addr v1, v0

    return-void
.end method


# virtual methods
.method B0(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lcom/google/common/collect/me;
        .end annotation
    .end param
    .annotation runtime Lcom/google/common/collect/me;
    .end annotation

    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "key"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TK;)TK;"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-object p1
.end method

.method C0(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lcom/google/common/collect/me;
        .end annotation
    .end param
    .annotation runtime Lcom/google/common/collect/me;
    .end annotation

    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TV;)TV;"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-object p1
.end method

.method D0()Ljava/util/Iterator;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Iterator<",
            "Ljava/util/Map$Entry<",
            "TK;TV;>;>;"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/google/common/collect/c;->a:Ljava/util/Map;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-interface {v0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    new-instance v1, Lcom/google/common/collect/c$a;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-direct {v1, p0, v0}, Lcom/google/common/collect/c$a;-><init>(Lcom/google/common/collect/c;Ljava/util/Iterator;)V

    const/4 v3, 0x5

    const/4 v2, 0x6

    return-object v1
.end method

.method E0(Ljava/util/Map;)Lcom/google/common/collect/c;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "backward"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "TV;TK;>;)",
            "Lcom/google/common/collect/c<",
            "TV;TK;>;"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    new-instance v0, Lcom/google/common/collect/c$d;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-direct {v0, p1, p0}, Lcom/google/common/collect/c$d;-><init>(Ljava/util/Map;Lcom/google/common/collect/c;)V

    const/4 v1, 0x1

    and-int/2addr v2, v1

    return-object v0
.end method

.method I0(Ljava/util/Map;Ljava/util/Map;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "forward",
            "backward"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "TK;TV;>;",
            "Ljava/util/Map<",
            "TV;TK;>;)V"
        }
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/google/common/collect/c;->a:Ljava/util/Map;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    const/4 v1, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x5

    const/4 v2, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    if-nez v0, :cond_0

    const/4 v3, 0x5

    and-int/2addr v4, v3

    move v0, v1

    move v0, v1

    const/4 v4, 0x1

    move v0, v1

    move v0, v1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    goto :goto_0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x5

    move v0, v2

    move v0, v2

    const/4 v4, 0x1

    move v0, v2

    move v0, v2

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-static {v0}, Lcom/google/common/base/u0;->g0(Z)V

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/google/common/collect/c;->b:Lcom/google/common/collect/c;

    const/4 v3, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x6

    if-nez v0, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x7

    move v0, v1

    move v0, v1

    const/4 v4, 0x1

    move v0, v1

    move v0, v1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x7

    goto :goto_1

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    move v0, v2

    const/4 v4, 0x3

    move v0, v2

    move v0, v2

    :goto_1
    const/4 v3, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-static {v0}, Lcom/google/common/base/u0;->g0(Z)V

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-interface {p1}, Ljava/util/Map;->isEmpty()Z

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-static {v0}, Lcom/google/common/base/u0;->d(Z)V

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-interface {p2}, Ljava/util/Map;->isEmpty()Z

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-static {v0}, Lcom/google/common/base/u0;->d(Z)V

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    if-eq p1, p2, :cond_2

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    goto :goto_2

    :cond_2
    const/4 v3, 0x6

    move v4, v3

    move v1, v2

    move v1, v2

    const/4 v4, 0x7

    move v1, v2

    move v1, v2

    :goto_2
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-static {v1}, Lcom/google/common/base/u0;->d(Z)V

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x5

    iput-object p1, p0, Lcom/google/common/collect/c;->a:Ljava/util/Map;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {p0, p2}, Lcom/google/common/collect/c;->E0(Ljava/util/Map;)Lcom/google/common/collect/c;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    iput-object p1, p0, Lcom/google/common/collect/c;->b:Lcom/google/common/collect/c;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x4

    return-void
.end method

.method J0(Lcom/google/common/collect/c;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "inverse"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/collect/c<",
            "TV;TK;>;)V"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x5

    iput-object p1, p0, Lcom/google/common/collect/c;->b:Lcom/google/common/collect/c;

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-void
.end method

.method public clear()V
    .locals 3

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/common/collect/c;->a:Ljava/util/Map;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-interface {v0}, Ljava/util/Map;->clear()V

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/common/collect/c;->b:Lcom/google/common/collect/c;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget-object v0, v0, Lcom/google/common/collect/c;->a:Ljava/util/Map;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-interface {v0}, Ljava/util/Map;->clear()V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void
.end method

.method public containsValue(Ljava/lang/Object;)Z
    .locals 3
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/common/collect/c;->b:Lcom/google/common/collect/c;

    const/4 v2, 0x6

    const/4 v1, 0x7

    invoke-virtual {v0, p1}, Lcom/google/common/collect/k8;->containsKey(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    return p1
.end method

.method public entrySet()Ljava/util/Set;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "Ljava/util/Map$Entry<",
            "TK;TV;>;>;"
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/common/collect/c;->e:Ljava/util/Set;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-nez v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x5

    new-instance v0, Lcom/google/common/collect/c$c;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-direct {v0, p0, v1}, Lcom/google/common/collect/c$c;-><init>(Lcom/google/common/collect/c;Lcom/google/common/collect/c$a;)V

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/google/common/collect/c;->e:Ljava/util/Set;

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    return-object v0
.end method

.method protected bridge synthetic g0()Ljava/lang/Object;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/common/collect/c;->i0()Ljava/util/Map;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-object v0
.end method

.method protected i0()Ljava/util/Map;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "TK;TV;>;"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/common/collect/c;->a:Ljava/util/Map;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-object v0
.end method

.method public keySet()Ljava/util/Set;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "TK;>;"
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/common/collect/c;->c:Ljava/util/Set;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    if-nez v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    new-instance v0, Lcom/google/common/collect/c$e;

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x1

    or-int/2addr v2, v1

    const/4 v3, 0x2

    invoke-direct {v0, p0, v1}, Lcom/google/common/collect/c$e;-><init>(Lcom/google/common/collect/c;Lcom/google/common/collect/c$a;)V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/google/common/collect/c;->c:Ljava/util/Set;

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-object v0
.end method

.method public p0(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lcom/google/common/collect/me;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Object;
        .annotation runtime Lcom/google/common/collect/me;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "key",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TK;TV;)TV;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-direct {p0, p1, p2, v0}, Lcom/google/common/collect/c;->F0(Ljava/lang/Object;Ljava/lang/Object;Z)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object p1
.end method

.method public put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lcom/google/common/collect/me;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Object;
        .annotation runtime Lcom/google/common/collect/me;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "key",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TK;TV;)TV;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x3

    invoke-direct {p0, p1, p2, v0}, Lcom/google/common/collect/c;->F0(Ljava/lang/Object;Ljava/lang/Object;Z)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-object p1
.end method

.method public putAll(Ljava/util/Map;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "map"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "+TK;+TV;>;)V"
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-interface {p1}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    check-cast v0, Ljava/util/Map$Entry;

    const/4 v3, 0x1

    invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {p0, v1, v0}, Lcom/google/common/collect/c;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-void
.end method

.method public remove(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "key"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            ")TV;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {p0, p1}, Lcom/google/common/collect/k8;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v1, 0x6

    and-int/2addr v2, v1

    invoke-direct {p0, p1}, Lcom/google/common/collect/c;->G0(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    const/4 p1, 0x0

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object p1
.end method

.method public replaceAll(Ljava/util/function/BiFunction;)V
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "function"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/function/BiFunction<",
            "-TK;-TV;+TV;>;)V"
        }
    .end annotation

    const/4 v6, 0x0

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/google/common/collect/c;->a:Ljava/util/Map;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-static {v0, p1}, Lcom/google/common/collect/a;->a(Ljava/util/Map;Ljava/util/function/BiFunction;)V

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x5

    iget-object p1, p0, Lcom/google/common/collect/c;->b:Lcom/google/common/collect/c;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x6

    iget-object p1, p1, Lcom/google/common/collect/c;->a:Ljava/util/Map;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-interface {p1}, Ljava/util/Map;->clear()V

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x3

    iget-object p1, p0, Lcom/google/common/collect/c;->a:Ljava/util/Map;

    const/4 v6, 0x6

    invoke-interface {p1}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object p1

    const/4 v6, 0x0

    const/4 v5, 0x6

    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p1

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x0

    const/4 v0, 0x0

    :cond_0
    :goto_0
    const/4 v6, 0x2

    const/4 v5, 0x5

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v6, 0x0

    const/4 v5, 0x5

    if-eqz v1, :cond_1

    const/4 v5, 0x3

    move v6, v5

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x6

    check-cast v1, Ljava/util/Map$Entry;

    const/4 v5, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x0

    iget-object v4, p0, Lcom/google/common/collect/c;->b:Lcom/google/common/collect/c;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x0

    iget-object v4, v4, Lcom/google/common/collect/c;->a:Ljava/util/Map;

    const/4 v6, 0x6

    const/4 v5, 0x4

    invoke-static {v4, v3, v2}, Lcom/google/common/collect/b;->a(Ljava/util/Map;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x2

    if-eqz v2, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-interface {p1}, Ljava/util/Iterator;->remove()V

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x2

    goto :goto_0

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-nez v0, :cond_2

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x0

    return-void

    :cond_2
    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x0

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x7

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x3

    const-string/jumbo v2, "ve: oad rautmerlsnp yae"

    const-string v2, ":stmydur eavenlaarpee  "

    const/4 v6, 0x7

    const-string v2, "e:pevbe ala nusay drltr"

    const-string/jumbo v2, "value already present: "

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x6

    throw p1
.end method

.method public u0()Lcom/google/common/collect/r0;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/collect/r0<",
            "TV;TK;>;"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/common/collect/c;->b:Lcom/google/common/collect/c;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-object v0
.end method

.method public bridge synthetic values()Ljava/util/Collection;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/common/collect/c;->values()Ljava/util/Set;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-object v0
.end method

.method public values()Ljava/util/Set;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "TV;>;"
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/common/collect/c;->d:Ljava/util/Set;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-nez v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    new-instance v0, Lcom/google/common/collect/c$f;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-direct {v0, p0, v1}, Lcom/google/common/collect/c$f;-><init>(Lcom/google/common/collect/c;Lcom/google/common/collect/c$a;)V

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/google/common/collect/c;->d:Ljava/util/Set;

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x1

    return-object v0
.end method
