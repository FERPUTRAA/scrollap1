.class public final synthetic Lcom/google/common/collect/fl;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/function/BiConsumer;


# instance fields
.field public final synthetic a:Ljava/util/function/Function;

.field public final synthetic b:Ljava/util/function/Function;

.field public final synthetic c:Ljava/util/function/Function;

.field public final synthetic d:Ljava/util/function/BinaryOperator;


# direct methods
.method public synthetic constructor <init>(Ljava/util/function/Function;Ljava/util/function/Function;Ljava/util/function/Function;Ljava/util/function/BinaryOperator;)V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/google/common/collect/fl;->a:Ljava/util/function/Function;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput-object p2, p0, Lcom/google/common/collect/fl;->b:Ljava/util/function/Function;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x6

    iput-object p3, p0, Lcom/google/common/collect/fl;->c:Ljava/util/function/Function;

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput-object p4, p0, Lcom/google/common/collect/fl;->d:Ljava/util/function/BinaryOperator;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public final accept(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 8

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v6, "b s ~ ~~~~i ~@b@o 4i ru~ @@y-t f~~~nv 1~i~~@@~@s ~~Sa@~fo~Mm Kot@ @ @.@o@/~c@/ ~o@ @lbd~  @@~lo@"

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x6

    iget-object v0, p0, Lcom/google/common/collect/fl;->a:Ljava/util/function/Function;

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x7

    iget-object v1, p0, Lcom/google/common/collect/fl;->b:Ljava/util/function/Function;

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x4

    iget-object v2, p0, Lcom/google/common/collect/fl;->c:Ljava/util/function/Function;

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x5

    iget-object v3, p0, Lcom/google/common/collect/fl;->d:Ljava/util/function/BinaryOperator;

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    const/4 v7, 0x7

    const/4 v6, 0x2

    check-cast v4, Lcom/google/common/collect/bl;

    move-object v5, p2

    move-object v5, p2

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-static/range {v0 .. v5}, Lcom/google/common/collect/ol;->b(Ljava/util/function/Function;Ljava/util/function/Function;Ljava/util/function/Function;Ljava/util/function/BinaryOperator;Lcom/google/common/collect/bl;Ljava/lang/Object;)V

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x7

    return-void
.end method
