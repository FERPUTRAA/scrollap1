.class public final synthetic Lcom/google/common/collect/ci;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(D)Ljava/util/stream/DoubleStream;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@~s~K@ @ol   @v~bM @foo~t~/~~@l~o@@4@ t@@ro/a@i  f @n@S~ ~~s-~m@@~ d@b~@~ c@y~~ ~b 1@u. o~~~ ~i "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x0

    invoke-static {p0, p1}, Ljava/util/stream/DoubleStream;->of(D)Ljava/util/stream/DoubleStream;

    move-result-object p0

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-object p0
.end method
