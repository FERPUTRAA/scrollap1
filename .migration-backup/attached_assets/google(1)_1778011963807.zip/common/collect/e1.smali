.class public final synthetic Lcom/google/common/collect/e1;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Ljava/util/function/ToIntFunction;Ljava/lang/Object;)I
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~@s~  ~b o - Mi@@ ~n/~.oia~ 4 oyr@~@  o~fK@divo~~@  @~~l @/@c~@@so~@t~~~ ~mu @b~l@@ @S~@b@t~@1 f"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x0

    invoke-interface {p0, p1}, Ljava/util/function/ToIntFunction;->applyAsInt(Ljava/lang/Object;)I

    move-result p0

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x7

    return p0
.end method
