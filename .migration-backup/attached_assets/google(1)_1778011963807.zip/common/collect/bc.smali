.class public final synthetic Lcom/google/common/collect/bc;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/function/Consumer;


# instance fields
.field public final synthetic a:Ljava/util/function/BiConsumer;


# direct methods
.method public synthetic constructor <init>(Ljava/util/function/BiConsumer;)V
    .locals 2

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/google/common/collect/bc;->a:Ljava/util/function/BiConsumer;

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public final accept(Ljava/lang/Object;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~ so dm@Sv@@s f ~ncf  y@ ~ M~o4~@@.ai tr~ -@li@ o  /@~  ~i~~o@@~@@@ @/o~u~@~b1~@@~~@lto@~~~ bbK~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/common/collect/bc;->a:Ljava/util/function/BiConsumer;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    check-cast p1, Ljava/util/Map$Entry;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-static {v0, p1}, Lcom/google/common/collect/cc;->N(Ljava/util/function/BiConsumer;Ljava/util/Map$Entry;)V

    const/4 v1, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-void
.end method
