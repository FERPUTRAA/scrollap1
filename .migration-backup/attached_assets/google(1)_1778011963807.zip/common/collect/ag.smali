.class public final synthetic Lcom/google/common/collect/ag;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Ljava/util/NavigableSet;)Ljava/util/stream/Stream;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~.s@@~a@~@i@  ~~ ~bv~4/@~ ~~o~b~o@~oi@@rs-/Sto1 M ~  fy@ol@u @ ~@~m@~cbt~K l @~ ~@i ~o@  ~@d@@f "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    invoke-interface {p0}, Ljava/util/NavigableSet;->stream()Ljava/util/stream/Stream;

    move-result-object p0

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-object p0
.end method
