.class Lcom/google/common/collect/d9$a$a;
.super Lcom/google/common/collect/v;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/collect/d9$a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/common/collect/v<",
        "TK;TV;>;"
    }
.end annotation


# instance fields
.field a:Lcom/google/common/collect/d9$b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/collect/d9$b<",
            "TK;TV;>;"
        }
    .end annotation
.end field

.field final synthetic b:Lcom/google/common/collect/d9$a;


# direct methods
.method constructor <init>(Lcom/google/common/collect/d9$a;Lcom/google/common/collect/d9$b;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x0
        }
        names = {
            "this$1",
            "entry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/collect/d9$b<",
            "TK;TV;>;)V"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/google/common/collect/d9$a$a;->b:Lcom/google/common/collect/d9$a;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/google/common/collect/v;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput-object p2, p0, Lcom/google/common/collect/d9$a$a;->a:Lcom/google/common/collect/d9$b;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public getKey()Ljava/lang/Object;
    .locals 3
    .annotation runtime Lcom/google/common/collect/me;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TK;"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x1

    iget-object v0, p0, Lcom/google/common/collect/d9$a$a;->a:Lcom/google/common/collect/d9$b;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget-object v0, v0, Lcom/google/common/collect/o9;->key:Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-object v0
.end method

.method public getValue()Ljava/lang/Object;
    .locals 3
    .annotation runtime Lcom/google/common/collect/me;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TV;"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/common/collect/d9$a$a;->a:Lcom/google/common/collect/d9$b;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, v0, Lcom/google/common/collect/o9;->value:Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-object v0
.end method

.method public setValue(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lcom/google/common/collect/me;
        .end annotation
    .end param
    .annotation runtime Lcom/google/common/collect/me;
    .end annotation

    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TV;)TV;"
        }
    .end annotation

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x3

    iget-object v0, p0, Lcom/google/common/collect/d9$a$a;->a:Lcom/google/common/collect/d9$b;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x6

    iget-object v0, v0, Lcom/google/common/collect/o9;->value:Ljava/lang/Object;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-static {p1}, Lcom/google/common/collect/i9;->d(Ljava/lang/Object;)I

    move-result v1

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x2

    iget-object v2, p0, Lcom/google/common/collect/d9$a$a;->a:Lcom/google/common/collect/d9$b;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x2

    iget v2, v2, Lcom/google/common/collect/d9$b;->valueHash:I

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x7

    if-ne v1, v2, :cond_0

    const/4 v5, 0x1

    move v6, v5

    invoke-static {p1, v0}, Lcom/google/common/base/m0;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x7

    if-eqz v2, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x1

    return-object p1

    :cond_0
    const/4 v6, 0x4

    const/4 v5, 0x0

    iget-object v2, p0, Lcom/google/common/collect/d9$a$a;->b:Lcom/google/common/collect/d9$a;

    const/4 v6, 0x0

    iget-object v2, v2, Lcom/google/common/collect/d9$a;->f:Lcom/google/common/collect/d9;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-static {v2, p1, v1}, Lcom/google/common/collect/d9;->h(Lcom/google/common/collect/d9;Ljava/lang/Object;I)Lcom/google/common/collect/d9$b;

    move-result-object v2

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x1

    if-nez v2, :cond_1

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x2

    const/4 v2, 0x1

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x2

    goto :goto_0

    :cond_1
    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x2

    const/4 v2, 0x0

    :goto_0
    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x2

    const-string/jumbo v3, "pssvsldtaaerr ens eleayu%"

    const-string v3, " dssu:elerytpvre%anaesa l"

    const/4 v6, 0x0

    const-string/jumbo v3, "lelmes as yearvdaue:n trp"

    const-string/jumbo v3, "value already present: %s"

    const/4 v6, 0x5

    invoke-static {v2, v3, p1}, Lcom/google/common/base/u0;->u(ZLjava/lang/String;Ljava/lang/Object;)V

    const/4 v6, 0x2

    iget-object v2, p0, Lcom/google/common/collect/d9$a$a;->b:Lcom/google/common/collect/d9$a;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x0

    iget-object v2, v2, Lcom/google/common/collect/d9$a;->f:Lcom/google/common/collect/d9;

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x0

    iget-object v3, p0, Lcom/google/common/collect/d9$a$a;->a:Lcom/google/common/collect/d9$b;

    const/4 v6, 0x1

    const/4 v5, 0x3

    invoke-static {v2, v3}, Lcom/google/common/collect/d9;->f(Lcom/google/common/collect/d9;Lcom/google/common/collect/d9$b;)V

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x7

    new-instance v2, Lcom/google/common/collect/d9$b;

    const/4 v6, 0x7

    const/4 v5, 0x1

    iget-object v3, p0, Lcom/google/common/collect/d9$a$a;->a:Lcom/google/common/collect/d9$b;

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x2

    iget-object v4, v3, Lcom/google/common/collect/o9;->key:Ljava/lang/Object;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x5

    iget v3, v3, Lcom/google/common/collect/d9$b;->keyHash:I

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-direct {v2, v4, v3, p1, v1}, Lcom/google/common/collect/d9$b;-><init>(Ljava/lang/Object;ILjava/lang/Object;I)V

    const/4 v5, 0x3

    move v6, v5

    iget-object p1, p0, Lcom/google/common/collect/d9$a$a;->b:Lcom/google/common/collect/d9$a;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x6

    iget-object p1, p1, Lcom/google/common/collect/d9$a;->f:Lcom/google/common/collect/d9;

    iget-object v1, p0, Lcom/google/common/collect/d9$a$a;->a:Lcom/google/common/collect/d9$b;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-static {p1, v2, v1}, Lcom/google/common/collect/d9;->i(Lcom/google/common/collect/d9;Lcom/google/common/collect/d9$b;Lcom/google/common/collect/d9$b;)V

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x2

    iget-object p1, p0, Lcom/google/common/collect/d9$a$a;->a:Lcom/google/common/collect/d9$b;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x6

    const/4 v1, 0x0

    const/4 v6, 0x6

    const/4 v5, 0x7

    iput-object v1, p1, Lcom/google/common/collect/d9$b;->prevInKeyInsertionOrder:Lcom/google/common/collect/d9$b;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x2

    iput-object v1, p1, Lcom/google/common/collect/d9$b;->nextInKeyInsertionOrder:Lcom/google/common/collect/d9$b;

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x5

    iget-object p1, p0, Lcom/google/common/collect/d9$a$a;->b:Lcom/google/common/collect/d9$a;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x4

    iget-object v1, p1, Lcom/google/common/collect/d9$a;->f:Lcom/google/common/collect/d9;

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-static {v1}, Lcom/google/common/collect/d9;->e(Lcom/google/common/collect/d9;)I

    move-result v1

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x5

    iput v1, p1, Lcom/google/common/collect/d9$e;->c:I

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x1

    iget-object p1, p0, Lcom/google/common/collect/d9$a$a;->b:Lcom/google/common/collect/d9$a;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x1

    iget-object v1, p1, Lcom/google/common/collect/d9$e;->b:Lcom/google/common/collect/d9$b;

    const/4 v6, 0x1

    iget-object v3, p0, Lcom/google/common/collect/d9$a$a;->a:Lcom/google/common/collect/d9$b;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x1

    if-ne v1, v3, :cond_2

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x7

    iput-object v2, p1, Lcom/google/common/collect/d9$e;->b:Lcom/google/common/collect/d9$b;

    :cond_2
    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x4

    iput-object v2, p0, Lcom/google/common/collect/d9$a$a;->a:Lcom/google/common/collect/d9$b;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x0

    return-object v0
.end method
