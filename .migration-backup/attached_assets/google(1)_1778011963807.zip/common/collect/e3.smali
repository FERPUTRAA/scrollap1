.class public final synthetic Lcom/google/common/collect/e3;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/function/BiConsumer;


# direct methods
.method public synthetic constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public final accept(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, ".ss~14bff~@~@o -@@~~ @v~oy~  /~ulm ~ i~   ~~S ~ ~~@K@rdc~t @@o  ~bon@i@ot i@M ~bol~@@~/a@@@@~@@ "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    check-cast p1, Lcom/google/common/collect/c4$c;

    const/4 v1, 0x1

    const/4 v0, 0x2

    check-cast p2, Ljava/lang/Enum;

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-virtual {p1, p2}, Lcom/google/common/collect/c4$c;->a(Ljava/lang/Enum;)V

    const/4 v1, 0x6

    return-void
.end method
