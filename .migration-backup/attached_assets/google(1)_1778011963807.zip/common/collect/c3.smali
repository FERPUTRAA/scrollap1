.class public final synthetic Lcom/google/common/collect/c3;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/function/Function;


# direct methods
.method public synthetic constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public final apply(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~cs@ lo@din~ooK @ ~l @ S~-@/@~i~oa/ r@4  b@@~@~i@~~~  @sb~~ y @ v~~u@b@@1M @t~of@~~fm~ ~ @t@~.o "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    check-cast p1, Lcom/google/common/collect/oa$c;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-virtual {p1}, Lcom/google/common/collect/oa$c;->a()Lcom/google/common/collect/oa;

    move-result-object p1

    const/4 v1, 0x1

    return-object p1
.end method
