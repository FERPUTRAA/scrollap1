.class public final synthetic Lcom/google/common/collect/eh;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a()Ljava/util/stream/Stream;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " ~sb@4 l~  i ~/~~~ ~ @@@~@@@u1 MvbolS/t~ o@oo~n@b o~i@r~c@~f ~m@s~~f~@K@~  -iy@t@ o@d @~a@~@.~ ~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    invoke-static {}, Ljava/util/stream/Stream;->empty()Ljava/util/stream/Stream;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-object v0
.end method
