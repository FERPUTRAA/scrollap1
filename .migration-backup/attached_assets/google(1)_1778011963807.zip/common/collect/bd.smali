.class public final synthetic Lcom/google/common/collect/bd;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/function/Function;


# instance fields
.field public final synthetic a:Lcom/google/common/collect/uc$d0;


# direct methods
.method public synthetic constructor <init>(Lcom/google/common/collect/uc$d0;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x7

    iput-object p1, p0, Lcom/google/common/collect/bd;->a:Lcom/google/common/collect/uc$d0;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public final apply(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "o~s~~@~1@o@c@@~ i m~ ~ ai~td Mv@ @@iy f @ b~4~@@@~ ~ ~n~s Kr~ /bo/@~-l~o.S t ~@@@~~boo~ u@@@f @~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/common/collect/bd;->a:Lcom/google/common/collect/uc$d0;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-static {v0, p1}, Lcom/google/common/collect/uc$d0;->e(Lcom/google/common/collect/uc$d0;Ljava/lang/Object;)Ljava/util/Map$Entry;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-object p1
.end method
