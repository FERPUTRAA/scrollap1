.class public final synthetic Lcom/google/common/collect/f3;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/function/BinaryOperator;


# direct methods
.method public synthetic constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public final apply(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@~s~i@~~f@~~@ / @~d /~@~~ t@@  @lv~bs@f~@b~c ~@@yb~uKa -trn o@i@@~o~i  ~~@So@~~4o@m1o l o~@ .   "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x1

    check-cast p1, Lcom/google/common/collect/c4$c;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x3

    check-cast p2, Lcom/google/common/collect/c4$c;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-virtual {p1, p2}, Lcom/google/common/collect/c4$c;->b(Lcom/google/common/collect/c4$c;)Lcom/google/common/collect/c4$c;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-object p1
.end method
