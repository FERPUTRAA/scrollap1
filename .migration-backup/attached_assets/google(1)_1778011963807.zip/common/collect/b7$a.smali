.class Lcom/google/common/collect/b7$a;
.super Lcom/google/common/collect/de$i;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/common/collect/b7;->I0()Ljava/util/Set;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/common/collect/de$i<",
        "TE;>;"
    }
.end annotation


# instance fields
.field final synthetic a:Lcom/google/common/collect/b7;


# direct methods
.method constructor <init>(Lcom/google/common/collect/b7;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            "this$0"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x4

    iput-object p1, p0, Lcom/google/common/collect/b7$a;->a:Lcom/google/common/collect/b7;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/google/common/collect/de$i;-><init>()V

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method f()Lcom/google/common/collect/ae;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/collect/ae<",
            "TE;>;"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@@s~~~y@ ~b @ m@~o@ @@~ s@Sr@otM~~~ K-i  ~/i~b@o1~~.@t~if @~fo o @  ~@d/cvl~u~~ o lb~n4@@~@@ @~ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/common/collect/b7$a;->a:Lcom/google/common/collect/b7;

    const/4 v2, 0x4

    const/4 v1, 0x4

    return-object v0
.end method

.method public iterator()Ljava/util/Iterator;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Iterator<",
            "Lcom/google/common/collect/ae$a<",
            "TE;>;>;"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/common/collect/b7$a;->a:Lcom/google/common/collect/b7;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/google/common/collect/b7;->J0()Ljava/util/Iterator;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-object v0
.end method

.method public size()I
    .locals 3

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/common/collect/b7$a;->a:Lcom/google/common/collect/b7;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {v0}, Lcom/google/common/collect/b7;->K0()Lcom/google/common/collect/lg;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-interface {v0}, Lcom/google/common/collect/lg;->entrySet()Ljava/util/Set;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-interface {v0}, Ljava/util/Set;->size()I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    return v0
.end method
