.class public final synthetic Lcom/google/common/collect/gi;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(I)Ljava/util/OptionalInt;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " .s~~~ o M@@t@1fi~  vs@~~~@ ~S@@@c@ ll ~m~i @ud  @bry~~~@~o  ~ @@/oto~ f~4@b@~o -a/@~~@in@@b~K ~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x1

    invoke-static {p0}, Ljava/util/OptionalInt;->of(I)Ljava/util/OptionalInt;

    move-result-object p0

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-object p0
.end method
