.class public final synthetic Lcom/google/common/collect/h;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Ljava/util/Collection;Ljava/util/function/Consumer;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@~sM~ru~@@@1@K@o  @-it~@   l~~ @a~~ly~~ ~ Si ~b @v@ n~m ib~ ~f~f@o/~@@db4s ~@ooc~.o~@~ t~ /@@@o "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    invoke-interface {p0, p1}, Ljava/util/Collection;->forEach(Ljava/util/function/Consumer;)V

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method
