.class abstract Lcom/google/common/collect/d;
.super Lcom/google/common/collect/bm;


# annotations
.annotation runtime Lcom/google/common/collect/d7;
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<E:",
        "Ljava/lang/Object;",
        ">",
        "Lcom/google/common/collect/bm<",
        "TE;>;"
    }
.end annotation

.annotation build Lx4/b;
.end annotation


# instance fields
.field private final a:I

.field private b:I


# direct methods
.method protected constructor <init>(I)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "size"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v0, 0x0

    or-int/2addr v2, v0

    const/4 v1, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-direct {p0, p1, v0}, Lcom/google/common/collect/d;-><init>(II)V

    const/4 v1, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-void
.end method

.method protected constructor <init>(II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "size",
            "position"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-direct {p0}, Lcom/google/common/collect/bm;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-static {p2, p1}, Lcom/google/common/base/u0;->d0(II)I

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x3

    iput p1, p0, Lcom/google/common/collect/d;->a:I

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x4

    iput p2, p0, Lcom/google/common/collect/d;->b:I

    const/4 v1, 0x2

    const/4 v0, 0x6

    return-void
.end method


# virtual methods
.method protected abstract a(I)Ljava/lang/Object;
    .annotation runtime Lcom/google/common/collect/me;
    .end annotation

    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "index"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)TE;"
        }
    .end annotation
.end method

.method public final hasNext()Z
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " ~s@@ @@~4~ f ~~~~dK~ -soaior@t~o 1obSl ~ v@@@i@t/~@l~y cm~ @~n o /@@~~ @fu~@ ib~@. @~~M ~@~@ bo"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    iget v0, p0, Lcom/google/common/collect/d;->b:I

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget v1, p0, Lcom/google/common/collect/d;->a:I

    const/4 v2, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-ge v0, v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    const/4 v0, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v0, 0x0

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    return v0
.end method

.method public final hasPrevious()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget v0, p0, Lcom/google/common/collect/d;->b:I

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    if-lez v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x7

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v2, 0x3

    return v0
.end method

.method public final next()Ljava/lang/Object;
    .locals 4
    .annotation runtime Lcom/google/common/collect/me;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TE;"
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/google/common/collect/d;->hasNext()Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    iget v0, p0, Lcom/google/common/collect/d;->b:I

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    add-int/lit8 v1, v0, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    iput v1, p0, Lcom/google/common/collect/d;->b:I

    const/4 v3, 0x7

    const/4 v2, 0x2

    invoke-virtual {p0, v0}, Lcom/google/common/collect/d;->a(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    return-object v0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    new-instance v0, Ljava/util/NoSuchElementException;

    const/4 v3, 0x0

    invoke-direct {v0}, Ljava/util/NoSuchElementException;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    throw v0
.end method

.method public final nextIndex()I
    .locals 3

    const/4 v2, 0x6

    iget v0, p0, Lcom/google/common/collect/d;->b:I

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    return v0
.end method

.method public final previous()Ljava/lang/Object;
    .locals 3
    .annotation runtime Lcom/google/common/collect/me;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TE;"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/common/collect/d;->hasPrevious()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget v0, p0, Lcom/google/common/collect/d;->b:I

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    add-int/lit8 v0, v0, -0x1

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    iput v0, p0, Lcom/google/common/collect/d;->b:I

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {p0, v0}, Lcom/google/common/collect/d;->a(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-object v0

    :cond_0
    const/4 v2, 0x1

    new-instance v0, Ljava/util/NoSuchElementException;

    const/4 v2, 0x2

    invoke-direct {v0}, Ljava/util/NoSuchElementException;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x7

    throw v0
.end method

.method public final previousIndex()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    iget v0, p0, Lcom/google/common/collect/d;->b:I

    const/4 v1, 0x2

    xor-int/2addr v2, v1

    add-int/lit8 v0, v0, -0x1

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    return v0
.end method
