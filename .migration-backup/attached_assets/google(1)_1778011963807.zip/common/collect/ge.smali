.class final Lcom/google/common/collect/ge;
.super Lcom/google/common/collect/le;

# interfaces
.implements Ljava/io/Serializable;


# annotations
.annotation runtime Lcom/google/common/collect/d7;
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/common/collect/le<",
        "Ljava/lang/Comparable<",
        "*>;>;",
        "Ljava/io/Serializable;"
    }
.end annotation

.annotation build Lx4/b;
    serializable = true
.end annotation


# static fields
.field static final e:Lcom/google/common/collect/ge;

.field private static final serialVersionUID:J


# instance fields
.field private transient c:Lcom/google/common/collect/le;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/collect/le<",
            "Ljava/lang/Comparable<",
            "*>;>;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation
.end field

.field private transient d:Lcom/google/common/collect/le;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/collect/le<",
            "Ljava/lang/Comparable<",
            "*>;>;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    new-instance v0, Lcom/google/common/collect/ge;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-direct {v0}, Lcom/google/common/collect/ge;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    sput-object v0, Lcom/google/common/collect/ge;->e:Lcom/google/common/collect/ge;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-direct {p0}, Lcom/google/common/collect/le;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method

.method private readResolve()Ljava/lang/Object;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "o s~.b~ o~@~o~@~ @~i~u~~@vd1~f~@i@~4M ~@@@rbso  t@ @y @~@K-/mo~ tn@ia~@~@@l~l~  @ oS/b    f@@c ~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    sget-object v0, Lcom/google/common/collect/ge;->e:Lcom/google/common/collect/ge;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-object v0
.end method


# virtual methods
.method public B()Lcom/google/common/collect/le;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<S::",
            "Ljava/lang/Comparable<",
            "*>;>()",
            "Lcom/google/common/collect/le<",
            "TS;>;"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/common/collect/ge;->c:Lcom/google/common/collect/le;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-super {p0}, Lcom/google/common/collect/le;->B()Lcom/google/common/collect/le;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    iput-object v0, p0, Lcom/google/common/collect/ge;->c:Lcom/google/common/collect/le;

    :cond_0
    const/4 v2, 0x3

    return-object v0
.end method

.method public C()Lcom/google/common/collect/le;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<S::",
            "Ljava/lang/Comparable<",
            "*>;>()",
            "Lcom/google/common/collect/le<",
            "TS;>;"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/common/collect/ge;->d:Lcom/google/common/collect/le;

    const/4 v2, 0x7

    if-nez v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-super {p0}, Lcom/google/common/collect/le;->C()Lcom/google/common/collect/le;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/google/common/collect/ge;->d:Lcom/google/common/collect/le;

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-object v0
.end method

.method public G()Lcom/google/common/collect/le;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<S::",
            "Ljava/lang/Comparable<",
            "*>;>()",
            "Lcom/google/common/collect/le<",
            "TS;>;"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x1

    sget-object v0, Lcom/google/common/collect/if;->c:Lcom/google/common/collect/if;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-object v0
.end method

.method public K(Ljava/lang/Comparable;Ljava/lang/Comparable;)I
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "left",
            "right"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Comparable<",
            "*>;",
            "Ljava/lang/Comparable<",
            "*>;)I"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-static {p1}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-static {p2}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v1, 0x4

    invoke-interface {p1, p2}, Ljava/lang/Comparable;->compareTo(Ljava/lang/Object;)I

    move-result p1

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x7

    return p1
.end method

.method public bridge synthetic compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "left",
            "right"
        }
    .end annotation

    const/4 v1, 0x4

    check-cast p1, Ljava/lang/Comparable;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x6

    check-cast p2, Ljava/lang/Comparable;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-virtual {p0, p1, p2}, Lcom/google/common/collect/ge;->K(Ljava/lang/Comparable;Ljava/lang/Comparable;)I

    move-result p1

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x3

    return p1
.end method

.method public toString()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    const-string v0, "dnumiaasrOe.)ng(tl"

    const-string/jumbo v0, "ndslO.ra(nu)irteag"

    const/4 v2, 0x6

    const-string v0, "andlonrtrrOueg)(i."

    const-string v0, "Ordering.natural()"

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object v0
.end method
