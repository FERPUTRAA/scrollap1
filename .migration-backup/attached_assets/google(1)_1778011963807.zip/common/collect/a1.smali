.class public final synthetic Lcom/google/common/collect/a1;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a()Ljava/util/stream/Collector$Characteristics;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@ sr~~ aM~t nu~@o m@/Sfb4t~~l@~ ~K~@bob~sc  ~~vi~  @o.~@ @@~~o1~o f@di@@~~i~@@ /@ @o-@l@  ~ @ @y"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    sget-object v0, Ljava/util/stream/Collector$Characteristics;->UNORDERED:Ljava/util/stream/Collector$Characteristics;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object v0
.end method
