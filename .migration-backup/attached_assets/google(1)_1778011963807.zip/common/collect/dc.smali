.class public final synthetic Lcom/google/common/collect/dc;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Ljava/util/Map;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " cs~ ~@Ml~~@ o aS~t@ ovo~ /~@@f~@@mstK@-o ~y  i~l1~ ~~@ ~ui@od/@~b~~@b@  @ @o  ~.~b@rf~ @~n@4~i@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    invoke-interface {p0, p1, p2}, Ljava/util/Map;->getOrDefault(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-object p0
.end method
