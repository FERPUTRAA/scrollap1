.class public final synthetic Lcom/google/common/collect/aj;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Ljava/util/Spliterator$OfLong;)Ljava/util/PrimitiveIterator$OfLong;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@osS@@~l~o ~~o ~@/@da l~@ b@t @o@/vf~@@~c  b~@oM~m~~~@ @@~@  ~~b@f ~s ~o.@Ki-~~ii1n~u r @~  yt @"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    invoke-static {p0}, Ljava/util/Spliterators;->iterator(Ljava/util/Spliterator$OfLong;)Ljava/util/PrimitiveIterator$OfLong;

    move-result-object p0

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-object p0
.end method
