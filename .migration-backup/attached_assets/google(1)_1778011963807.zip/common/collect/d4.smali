.class public final synthetic Lcom/google/common/collect/d4;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/function/BiConsumer;


# instance fields
.field public final synthetic a:Lcom/google/common/collect/c4$b;


# direct methods
.method public synthetic constructor <init>(Lcom/google/common/collect/c4$b;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/google/common/collect/d4;->a:Lcom/google/common/collect/c4$b;

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public final accept(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@~s@@@@@~M@ ~o  ~.~~ 1@@ba~~~ ~@ @ooyllv@/ fn~@K@ui ~f b~ci it~/S~@ @m ro@~~ o~o~@~bt 4ds@~~   -"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/common/collect/d4;->a:Lcom/google/common/collect/c4$b;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    check-cast p1, Ljava/lang/Enum;

    const/4 v1, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {v0, p1, p2}, Lcom/google/common/collect/c4$b;->b(Ljava/lang/Enum;Ljava/lang/Object;)V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-void
.end method
