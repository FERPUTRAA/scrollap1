.class Lcom/google/common/collect/de$d$b;
.super Lcom/google/common/collect/e;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/common/collect/de$d;->f()Ljava/util/Iterator;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/common/collect/e<",
        "Lcom/google/common/collect/ae$a<",
        "TE;>;>;"
    }
.end annotation


# instance fields
.field final synthetic c:Ljava/util/Iterator;

.field final synthetic d:Lcom/google/common/collect/de$d;


# direct methods
.method constructor <init>(Lcom/google/common/collect/de$d;Ljava/util/Iterator;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010
        }
        names = {
            "this$0",
            "val$iterator1"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x2

    iput-object p1, p0, Lcom/google/common/collect/de$d$b;->d:Lcom/google/common/collect/de$d;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x3

    iput-object p2, p0, Lcom/google/common/collect/de$d$b;->c:Ljava/util/Iterator;

    invoke-direct {p0}, Lcom/google/common/collect/e;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method protected bridge synthetic a()Ljava/lang/Object;
    .locals 3
    .annotation runtime Lv7/a;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "- s~@ bsc@~ t ob1~~l~i@@nu~.~~  fyo~ioa~4/o@  ~M/m ~@o ~ @@@ @@l~@t@o~@~~~r  @@~@v~@Si@ f@ d~~Kb"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/common/collect/de$d$b;->d()Lcom/google/common/collect/ae$a;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-object v0
.end method

.method protected d()Lcom/google/common/collect/ae$a;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/collect/ae$a<",
            "TE;>;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/google/common/collect/de$d$b;->c:Ljava/util/Iterator;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    if-eqz v0, :cond_1

    const/4 v3, 0x6

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/common/collect/de$d$b;->c:Ljava/util/Iterator;

    const/4 v4, 0x2

    const/4 v3, 0x2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    check-cast v0, Lcom/google/common/collect/ae$a;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-interface {v0}, Lcom/google/common/collect/ae$a;->a()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-interface {v0}, Lcom/google/common/collect/ae$a;->getCount()I

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget-object v2, p0, Lcom/google/common/collect/de$d$b;->d:Lcom/google/common/collect/de$d;

    const/4 v4, 0x0

    const/4 v3, 0x6

    iget-object v2, v2, Lcom/google/common/collect/de$d;->d:Lcom/google/common/collect/ae;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-interface {v2, v1}, Lcom/google/common/collect/ae;->I1(Ljava/lang/Object;)I

    move-result v2

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    sub-int/2addr v0, v2

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    if-lez v0, :cond_0

    const/4 v3, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-static {v1, v0}, Lcom/google/common/collect/de;->k(Ljava/lang/Object;I)Lcom/google/common/collect/ae$a;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x7

    return-object v0

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {p0}, Lcom/google/common/collect/e;->b()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x3

    check-cast v0, Lcom/google/common/collect/ae$a;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    return-object v0
.end method
