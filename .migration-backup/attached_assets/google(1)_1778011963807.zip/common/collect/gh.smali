.class public final synthetic Lcom/google/common/collect/gh;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Ljava/util/stream/Stream;Ljava/util/function/Consumer;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "dys~o  @@@14~l@sn~ ot@~ ~/m~@@ ~~ ~-ioif~/@~@v~ ~S@@o~r~~@u @ btic@~@@@ ~M~o fao@ ~b K ~~.@@ l b"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    invoke-interface {p0, p1}, Ljava/util/stream/Stream;->forEach(Ljava/util/function/Consumer;)V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method
