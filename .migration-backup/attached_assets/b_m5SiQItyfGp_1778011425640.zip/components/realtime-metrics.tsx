'use client'

interface RealtimeMetricsProps {
  label: string
  value: string
  trend: string
  icon: string
}

export function RealtimeMetrics({ label, value, trend, icon }: RealtimeMetricsProps) {
  return (
    <div className="rounded-lg bg-card border border-border p-4 hover:border-primary/50 transition-colors">
      <div className="flex items-start justify-between mb-3">
        <p className="text-sm text-muted-foreground font-medium">{label}</p>
        <span className="text-2xl">{icon}</span>
      </div>
      <div className="flex items-baseline gap-2">
        <p className="text-2xl font-bold text-foreground">{value}</p>
        <span className="text-xs text-accent font-medium">{trend}</span>
      </div>
      <div className="mt-3 h-1 bg-muted rounded-full overflow-hidden">
        <div className="h-full bg-primary w-3/4 rounded-full" />
      </div>
    </div>
  )
}
