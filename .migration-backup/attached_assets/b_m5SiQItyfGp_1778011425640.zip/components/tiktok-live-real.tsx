'use client'

import { useState, useEffect, useRef } from 'react'
import Image from 'next/image'

interface LiveRoom {
  id: string
  roomId: string
  liveId: string
  roomName: string
  nickName: string
  anchorName: string
  avatar: string
  thumb: string
  onlineCount: number
  streamUrl: string
  pullAddr: string
  description: string
  gameType: number
  isLive: boolean
}

export function TikTokLiveReal() {
  const [rooms, setRooms] = useState<LiveRoom[]>([])
  const [selectedRoom, setSelectedRoom] = useState<LiveRoom | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const videoContainerRef = useRef<HTMLDivElement>(null)
  const videoRef = useRef<HTMLVideoElement>(null)

  // Fetch live rooms saat component mount
  useEffect(() => {
    fetchLiveRooms()
    const interval = setInterval(fetchLiveRooms, 30000) // Refresh setiap 30 detik
    return () => clearInterval(interval)
  }, [])

  // Update player ketika room berubah
  useEffect(() => {
    if (selectedRoom && videoRef.current) {
      updatePlayer()
    }
  }, [selectedRoom])

  const fetchLiveRooms = async () => {
    try {
      setLoading(true)
      console.log('[v0] Fetching live rooms...')
      
      // Try hybrid API that attempts real data with fallback
      const response = await fetch('/api/live-rooms-hybrid', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          area: 'ID',
          limit: 50,
          offset: 0,
        }),
      })

      const data = await response.json()
      console.log('[v0] Live rooms response:', {
        success: data.success,
        roomCount: data.data?.records?.length,
        total: data.data?.total,
        source: data.data?.source,
      })

      if (data.success && data.data?.records && data.data.records.length > 0) {
        setRooms(data.data.records)
        setSelectedRoom(data.data.records[0])
        setError(null)
        console.log('[v0] Loaded', data.data.records.length, 'rooms from', data.data.source)
      } else {
        setError(data.message || 'No rooms available')
      }
    } catch (err: any) {
      console.error('[v0] Error fetching rooms:', err)
      setError(err.message || 'Failed to fetch live rooms')
    } finally {
      setLoading(false)
    }
  }

  const updatePlayer = () => {
    if (!selectedRoom || !videoRef.current) return

    const streamUrl = selectedRoom.streamUrl

    if (!streamUrl) {
      console.log('[v0] No stream URL available')
      return
    }

    console.log('[v0] Loading stream:', streamUrl)

    // Check if FLV.js is available
    if (typeof (window as any).flvjs !== 'undefined' && (window as any).flvjs.isSupported()) {
      console.log('[v0] Using FLV.js for playback')

      // Destroy previous player if exists
      if ((videoRef.current as any).__flvPlayer) {
        try {
          (videoRef.current as any).__flvPlayer.destroy()
        } catch (e) {
          console.log('[v0] Error destroying previous player:', e)
        }
      }

      // Create new FLV.js player
      const flvPlayer = (window as any).flvjs.createPlayer(
        {
          type: 'flv',
          url: streamUrl,
          cors: true,
          withCredentials: false,
          hasAudio: true,
          hasVideo: true,
        },
        {
          lazyLoad: true,
          lazyLoadMaxDuration: 3,
          autoCleanupSourceBuffer: true,
        }
      )

      // Store player reference
      ;(videoRef.current as any).__flvPlayer = flvPlayer
      flvPlayer.attachMediaElement(videoRef.current)

      flvPlayer.on((window as any).flvjs.Events.ERROR, (type: any, detail: any, msg: any) => {
        console.error('[v0] FLV.js Error:', { type, detail, msg })
      })

      flvPlayer.on((window as any).flvjs.Events.STATISTICS_INFO, (stats: any) => {
        console.log('[v0] FLV Stats:', stats)
      })

      flvPlayer.load()
      flvPlayer.play().catch(e => {
        console.log('[v0] Playback prevented:', e.message)
      })
    } else {
      console.log('[v0] FLV.js not available, using native video player')
      // Fallback to native HTML5 video
      videoRef.current.src = streamUrl
      videoRef.current.crossOrigin = 'anonymous'
      videoRef.current.play().catch(e => {
        console.log('[v0] Auto-play prevented:', e.message)
      })
    }
  }

  const handleRoomSelect = (room: LiveRoom) => {
    setSelectedRoom(room)
  }

  const handleNextRoom = () => {
    if (selectedRoom && rooms.length > 0) {
      const currentIndex = rooms.findIndex(r => r.id === selectedRoom.id)
      const nextIndex = (currentIndex + 1) % rooms.length
      setSelectedRoom(rooms[nextIndex])
    }
  }

  const handlePreviousRoom = () => {
    if (selectedRoom && rooms.length > 0) {
      const currentIndex = rooms.findIndex(r => r.id === selectedRoom.id)
      const prevIndex = (currentIndex - 1 + rooms.length) % rooms.length
      setSelectedRoom(rooms[prevIndex])
    }
  }

  return (
    <div className="w-full h-screen bg-background flex overflow-hidden">
      {/* Main Video Area */}
      <div className="flex-1 flex flex-col relative">
        {/* Header */}
        <div className="bg-gradient-to-b from-black/50 to-transparent p-4 absolute top-0 left-0 right-0 z-10">
          <h1 className="text-2xl font-bold text-primary">Deanur Live</h1>
          <p className="text-sm text-foreground/80">TikTok-Style Live Streaming</p>
        </div>

        {/* Video Player */}
        <div
          ref={videoContainerRef}
          className="flex-1 bg-black relative flex items-center justify-center overflow-hidden"
        >
          {selectedRoom ? (
            <>
              <video
                ref={videoRef}
                className="w-full h-full object-cover"
                controls
                autoPlay
                muted
                crossOrigin="anonymous"
              />
              
              {/* Room Info Overlay */}
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black via-black/50 to-transparent p-6">
                <div className="flex items-end gap-4">
                  {/* Avatar */}
                  {selectedRoom.avatar && (
                    <div className="relative w-14 h-14 rounded-full overflow-hidden border-2 border-primary flex-shrink-0">
                      <Image
                        src={selectedRoom.avatar}
                        alt={selectedRoom.nickName}
                        fill
                        className="object-cover"
                        unoptimized
                      />
                    </div>
                  )}

                  {/* Room Info */}
                  <div className="flex-1 min-w-0">
                    <h2 className="text-lg font-bold text-foreground truncate">
                      {selectedRoom.roomName}
                    </h2>
                    <p className="text-sm text-foreground/80 truncate">
                      {selectedRoom.nickName}
                    </p>
                    <div className="flex items-center gap-2 mt-2">
                      <span className="inline-block w-2 h-2 rounded-full bg-accent animate-pulse" />
                      <span className="text-xs font-semibold text-accent">LIVE</span>
                      <span className="text-xs text-foreground/70">
                        {selectedRoom.onlineCount?.toLocaleString() || 0} watching
                      </span>
                    </div>
                  </div>

                  {/* Follow Button */}
                  <button className="px-4 py-2 bg-primary text-primary-foreground font-bold rounded-full flex-shrink-0 hover:bg-primary/90 transition-colors">
                    Follow
                  </button>
                </div>
              </div>

              {/* Navigation Buttons */}
              <button
                onClick={handlePreviousRoom}
                className="absolute left-4 top-1/2 -translate-y-1/2 z-20 w-12 h-12 bg-black/50 hover:bg-black/80 text-foreground rounded-full flex items-center justify-center transition-all"
              >
                ←
              </button>
              <button
                onClick={handleNextRoom}
                className="absolute right-4 top-1/2 -translate-y-1/2 z-20 w-12 h-12 bg-black/50 hover:bg-black/80 text-foreground rounded-full flex items-center justify-center transition-all"
              >
                →
              </button>

              {/* Room Counter */}
              <div className="absolute top-4 right-4 bg-black/70 px-3 py-1 rounded-full">
                <p className="text-sm font-semibold text-foreground">
                  {rooms.findIndex(r => r.id === selectedRoom.id) + 1} / {rooms.length}
                </p>
              </div>
            </>
          ) : (
            <div className="flex flex-col items-center justify-center gap-4">
              <div className="text-6xl">📺</div>
              <p className="text-lg text-foreground">
                {loading ? 'Loading live streams...' : error || 'No rooms available'}
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Right Sidebar - Room List */}
      <div className="w-20 md:w-24 lg:w-28 bg-card border-l border-border overflow-y-auto">
        <div className="p-2 space-y-2">
          {rooms.map((room) => (
            <button
              key={room.id}
              onClick={() => handleRoomSelect(room)}
              className={`w-full aspect-square rounded-lg overflow-hidden relative group transition-all border-2 ${
                selectedRoom?.id === room.id
                  ? 'border-primary scale-95'
                  : 'border-transparent hover:border-foreground/30'
              }`}
            >
              {/* Room Thumbnail */}
              {room.thumb && (
                <Image
                  src={room.thumb}
                  alt={room.roomName}
                  fill
                  className="object-cover group-hover:scale-110 transition-transform"
                  unoptimized
                />
              )}

              {/* Overlay with stats */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex flex-col justify-end p-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <div className="text-xs font-bold text-foreground truncate">
                  {room.roomName.slice(0, 10)}
                </div>
                <div className="text-xs text-foreground/80 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-accent" />
                  {(room.onlineCount / 1000).toFixed(1)}k
                </div>
              </div>

              {/* Live Badge */}
              {room.isLive && (
                <div className="absolute top-1 left-1 bg-accent text-accent-foreground text-xs font-bold px-1.5 py-0.5 rounded">
                  LIVE
                </div>
              )}
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}
