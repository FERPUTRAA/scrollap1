'use client'

interface LiveIndicatorProps {
  isConnected: boolean
}

export function LiveIndicator({ isConnected }: LiveIndicatorProps) {
  return (
    <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-card border border-border">
      <div className={`w-2.5 h-2.5 rounded-full live-dot ${isConnected ? 'bg-accent' : 'bg-muted'}`} />
      <span className="text-sm font-medium text-foreground">
        {isConnected ? 'LIVE' : 'OFFLINE'}
      </span>
    </div>
  )
}
