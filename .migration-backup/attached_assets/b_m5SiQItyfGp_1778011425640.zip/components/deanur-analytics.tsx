'use client'

import { useState, useEffect } from 'react'
import { LineChart, Line, AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts'

interface DeanurMetrics {
  timestamp: number
  activePlayers: number
  totalGames: number
  peakCCU: number
  avgLatency: number
  serverHealth: number
  regions: Array<{
    name: string
    status: 'online' | 'offline' | 'degraded'
    latency: number
    health: number
  }>
  recentActivity: Array<{
    id: string
    type: 'join' | 'leave' | 'complete' | 'error' | 'update'
    playerId: string
    gameId: string
    timestamp: number
    message: string
  }>
  playerStats: {
    newPlayers: number
    avgSessionDuration: number
    retentionRate: number
    dailyActiveUsers: number
  }
}

export function DeanurAnalytics() {
  const [metrics, setMetrics] = useState<DeanurMetrics | null>(null)
  const [loading, setLoading] = useState(true)
  const [chartData, setChartData] = useState<any[]>([])

  useEffect(() => {
    const fetchMetrics = async () => {
      try {
        const res = await fetch('/api/deanur-analytics', { cache: 'no-store' })
        const result = await res.json()
        
        if (result.success) {
          setMetrics(result.data)
          
          // Update chart data
          setChartData(prev => {
            const newData = [
              ...prev.slice(-23),
              {
                time: new Date(result.data.timestamp).toLocaleTimeString('en-US', { 
                  hour: '2-digit', 
                  minute: '2-digit' 
                }),
                players: result.data.activePlayers,
                games: result.data.totalGames,
                health: Math.round(result.data.serverHealth),
              }
            ]
            return newData.length === 0 ? [{
              time: new Date(result.data.timestamp).toLocaleTimeString('en-US', { 
                hour: '2-digit', 
                minute: '2-digit' 
              }),
              players: result.data.activePlayers,
              games: result.data.totalGames,
              health: Math.round(result.data.serverHealth),
            }] : newData
          })
        }
      } catch (err) {
        console.error('[v0] Failed to fetch metrics:', err)
      } finally {
        setLoading(false)
      }
    }

    fetchMetrics()
    const interval = setInterval(fetchMetrics, 5000)
    return () => clearInterval(interval)
  }, [])

  if (loading || !metrics) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-muted-foreground">Loading analytics...</div>
      </div>
    )
  }

  return (
    <div className="w-full h-full overflow-auto">
      <div className="p-6 space-y-8">
        {/* Header with Live Indicator */}
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold">Deanur Gaming Analytics</h2>
            <p className="text-muted-foreground text-sm">Real-time metrics from game infrastructure</p>
          </div>
          <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-primary/20 border border-primary/30">
            <div className="h-2 w-2 rounded-full bg-accent animate-pulse" />
            <span className="text-sm font-medium text-accent">Live</span>
          </div>
        </div>

        {/* Key Metrics Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <MetricCard 
            label="Active Players" 
            value={metrics.activePlayers.toLocaleString()} 
            change="+12%"
            icon="👥"
          />
          <MetricCard 
            label="Live Games" 
            value={metrics.totalGames.toLocaleString()} 
            change="+8%"
            icon="🎮"
          />
          <MetricCard 
            label="Peak CCU" 
            value={metrics.peakCCU.toLocaleString()} 
            change="Max"
            icon="📈"
          />
          <MetricCard 
            label="Server Health" 
            value={`${metrics.serverHealth.toFixed(1)}%`} 
            change="Stable"
            icon="❤️"
          />
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Players Chart */}
          <div className="bg-card border border-border rounded-lg p-6">
            <h3 className="font-semibold mb-4">Active Players Over Time</h3>
            <ResponsiveContainer width="100%" height={250}>
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorPlayers" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="var(--primary)" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="var(--primary)" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="time" stroke="var(--muted-foreground)" />
                <YAxis stroke="var(--muted-foreground)" />
                <Tooltip 
                  contentStyle={{
                    backgroundColor: 'var(--card)',
                    border: '1px solid var(--border)',
                    borderRadius: '6px'
                  }}
                />
                <Area 
                  type="monotone" 
                  dataKey="players" 
                  stroke="var(--primary)" 
                  fillOpacity={1} 
                  fill="url(#colorPlayers)" 
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          {/* Server Health Chart */}
          <div className="bg-card border border-border rounded-lg p-6">
            <h3 className="font-semibold mb-4">Server Health & Games</h3>
            <ResponsiveContainer width="100%" height={250}>
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="time" stroke="var(--muted-foreground)" />
                <YAxis stroke="var(--muted-foreground)" />
                <Tooltip 
                  contentStyle={{
                    backgroundColor: 'var(--card)',
                    border: '1px solid var(--border)',
                    borderRadius: '6px'
                  }}
                />
                <Legend />
                <Line type="monotone" dataKey="health" stroke="var(--accent)" strokeWidth={2} name="Health %" />
                <Line type="monotone" dataKey="games" stroke="var(--primary)" strokeWidth={2} name="Games" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Regions Status */}
        <div className="bg-card border border-border rounded-lg p-6">
          <h3 className="font-semibold mb-4">Regional Server Status</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {metrics.regions.map(region => (
              <div key={region.name} className="p-4 rounded-lg bg-secondary/30 border border-border">
                <div className="flex items-center justify-between mb-3">
                  <span className="font-medium text-sm">{region.name}</span>
                  <div className={`h-2 w-2 rounded-full ${
                    region.status === 'online' ? 'bg-accent' : 
                    region.status === 'degraded' ? 'bg-yellow-500' : 
                    'bg-destructive'
                  }`} />
                </div>
                <div className="space-y-2 text-xs text-muted-foreground">
                  <div className="flex justify-between">
                    <span>Latency:</span>
                    <span className="text-foreground font-medium">{region.latency.toFixed(0)}ms</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Health:</span>
                    <span className="text-foreground font-medium">{region.health.toFixed(1)}%</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Player Statistics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-card border border-border rounded-lg p-6">
            <p className="text-sm text-muted-foreground mb-1">New Players</p>
            <p className="text-3xl font-bold">{metrics.playerStats.newPlayers}</p>
            <p className="text-xs text-accent mt-2">+24h</p>
          </div>
          <div className="bg-card border border-border rounded-lg p-6">
            <p className="text-sm text-muted-foreground mb-1">Avg Session Duration</p>
            <p className="text-3xl font-bold">{metrics.playerStats.avgSessionDuration.toFixed(1)}m</p>
            <p className="text-xs text-accent mt-2">+2.3%</p>
          </div>
          <div className="bg-card border border-border rounded-lg p-6">
            <p className="text-sm text-muted-foreground mb-1">Retention Rate</p>
            <p className="text-3xl font-bold">{metrics.playerStats.retentionRate.toFixed(0)}%</p>
            <p className="text-xs text-accent mt-2">Stable</p>
          </div>
          <div className="bg-card border border-border rounded-lg p-6">
            <p className="text-sm text-muted-foreground mb-1">Daily Active Users</p>
            <p className="text-3xl font-bold">{(metrics.playerStats.dailyActiveUsers / 1000).toFixed(1)}k</p>
            <p className="text-xs text-accent mt-2">+8%</p>
          </div>
        </div>

        {/* Recent Activity */}
        <div className="bg-card border border-border rounded-lg p-6">
          <h3 className="font-semibold mb-4">Recent Activity</h3>
          <div className="space-y-3 max-h-64 overflow-y-auto">
            {metrics.recentActivity.slice(0, 8).map(activity => (
              <div key={activity.id} className="flex items-start gap-3 text-sm">
                <div className={`h-2 w-2 rounded-full mt-1.5 ${
                  activity.type === 'join' ? 'bg-accent' :
                  activity.type === 'complete' ? 'bg-green-500' :
                  activity.type === 'error' ? 'bg-destructive' :
                  'bg-primary'
                }`} />
                <div className="flex-1">
                  <p className="text-foreground">{activity.message}</p>
                  <p className="text-xs text-muted-foreground">
                    {new Date(activity.timestamp).toLocaleTimeString()}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

function MetricCard({ label, value, change, icon }: { 
  label: string
  value: string
  change: string
  icon: string
}) {
  return (
    <div className="bg-card border border-border rounded-lg p-6">
      <div className="flex items-center justify-between mb-2">
        <p className="text-sm text-muted-foreground">{label}</p>
        <span className="text-2xl">{icon}</span>
      </div>
      <p className="text-3xl font-bold">{value}</p>
      <p className="text-xs text-accent mt-2">{change}</p>
    </div>
  )
}
