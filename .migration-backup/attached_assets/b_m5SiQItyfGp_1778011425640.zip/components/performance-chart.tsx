'use client'

import { useEffect, useState } from 'react'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'

export function PerformanceChart() {
  const [data, setData] = useState<Array<{
    time: string
    players: number
    games: number
    latency: number
  }>>([])

  useEffect(() => {
    const initialData = Array.from({ length: 12 }, (_, i) => ({
      time: `${i}:00`,
      players: 2000 + Math.random() * 3000,
      games: 300 + Math.random() * 200,
      latency: 25 + Math.random() * 30,
    }))
    setData(initialData)

    const interval = setInterval(() => {
      setData((prev) => {
        const newData = [...prev.slice(1)]
        newData.push({
          time: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
          players: 2000 + Math.random() * 3000,
          games: 300 + Math.random() * 200,
          latency: 25 + Math.random() * 30,
        })
        return newData
      })
    }, 5000)

    return () => clearInterval(interval)
  }, [])

  return (
    <div className="rounded-lg bg-card border border-border p-6">
      <h2 className="text-lg font-semibold mb-6 text-foreground">Performance Metrics</h2>
      <ResponsiveContainer width="100%" height={300}>
        <LineChart data={data}>
          <CartesianGrid strokeDasharray="3 3" stroke="#2a3f5f" />
          <XAxis dataKey="time" stroke="#7a8a9e" style={{ fontSize: '12px' }} />
          <YAxis stroke="#7a8a9e" style={{ fontSize: '12px' }} />
          <Tooltip
            contentStyle={{
              backgroundColor: '#151f3a',
              border: '1px solid #2a3f5f',
              borderRadius: '8px',
            }}
            labelStyle={{ color: '#f0f4f8' }}
          />
          <Legend wrapperStyle={{ paddingTop: '20px' }} />
          <Line
            type="monotone"
            dataKey="players"
            stroke="#00d4ff"
            dot={false}
            strokeWidth={2}
            name="Active Players"
          />
          <Line
            type="monotone"
            dataKey="games"
            stroke="#00ffaa"
            dot={false}
            strokeWidth={2}
            name="Live Games"
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  )
}
