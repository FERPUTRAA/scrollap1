'use client'

interface PlayerStatsProps {
  activeCount: number
}

export function PlayerStats({ activeCount }: PlayerStatsProps) {
  const stats = [
    { label: 'New Players', value: '342', change: '+12%' },
    { label: 'Avg Session', value: '24m', change: '+3%' },
    { label: 'Retention', value: '68%', change: '+5%' },
    { label: 'Daily Active', value: '5.2K', change: '+8%' },
  ]

  return (
    <div className="rounded-lg bg-card border border-border p-6">
      <h2 className="text-lg font-semibold mb-6 text-foreground">Player Analytics</h2>
      <div className="space-y-4">
        {stats.map((stat, idx) => (
          <div key={idx} className="flex items-center justify-between pb-4 border-b border-border last:border-b-0">
            <div>
              <p className="text-sm text-muted-foreground">{stat.label}</p>
              <p className="text-lg font-semibold text-foreground mt-1">{stat.value}</p>
            </div>
            <span className="text-sm text-accent font-medium">{stat.change}</span>
          </div>
        ))}
      </div>
    </div>
  )
}
