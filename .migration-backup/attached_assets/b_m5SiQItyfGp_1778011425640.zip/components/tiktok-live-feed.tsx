'use client'

import { useState, useEffect, useRef } from 'react'
import { Card } from '@/components/ui/card'

interface LiveRoom {
  id: string
  roomName: string
  nickName: string
  onlineCount: number
  anchorImg?: string
  anchorLevel?: number
  roomImg?: string
  gameType?: number
  streamUrl?: string
  streamProxyUrl?: string
  pullAddr?: string
  pullUrl?: string
  flvUrl?: string
}

export function TikTokLiveFeed() {
  const [rooms, setRooms] = useState<LiveRoom[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedRoom, setSelectedRoom] = useState<LiveRoom | null>(null)
  const [currentIndex, setCurrentIndex] = useState(0)
  const scrollContainerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    fetchLiveRooms()
  }, [])

  const fetchLiveRooms = async () => {
    try {
      setLoading(true)
      const response = await fetch('/api/hot51-proxy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          area: 'ID',
          gameType: 0,
          offset: 0,
          limit: 50,
          sortBy: 'onlineCount',
          sortOrder: 'desc',
        }),
      })

      const data = await response.json()
      console.log('[v0] Hot51 API Response:', {
        success: data.success,
        total: data.total,
        roomCount: data.rooms?.length || 0,
        proxyUsed: data.proxyUsed,
      })
      
      if (data.success && data.rooms && data.rooms.length > 0) {
        // Transform API response to component format
        const transformedRooms: LiveRoom[] = data.rooms.map((room: any) => ({
          id: room.id || room.roomId || String(room.liveId),
          roomName: room.roomName || room.topic || 'Live Room',
          nickName: room.nickName || room.anchorName || room.userName || 'Streamer',
          onlineCount: room.onlineCount || room.viewCount || 0,
          anchorImg: room.avatar || room.anchorImg || room.thumb,
          roomImg: room.thumb || room.roomImg || room.pic,
          gameType: room.gameType,
          streamUrl: room.streamUrl,
          streamProxyUrl: room.streamProxyUrl || `/api/stream?roomId=${room.id || room.roomId}`,
          pullAddr: room.pullAddr,
          pullUrl: room.pullUrl,
          flvUrl: room.flvUrl,
        }))
        
        setRooms(transformedRooms)
        setSelectedRoom(transformedRooms[0])
        console.log('[v0] Loaded', transformedRooms.length, 'live rooms')
      } else if (!data.success) {
        console.error('[v0] API Error:', data.error)
      } else {
        console.log('[v0] No rooms returned from API')
      }
    } catch (error) {
      console.error('[v0] Error fetching rooms:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleSelectRoom = (room: LiveRoom, index: number) => {
    setSelectedRoom(room)
    setCurrentIndex(index)
  }

  const handleNext = () => {
    if (currentIndex < rooms.length - 1) {
      const nextIndex = currentIndex + 1
      handleSelectRoom(rooms[nextIndex], nextIndex)
      scrollContainerRef.current?.children[nextIndex]?.scrollIntoView({
        behavior: 'smooth',
        block: 'nearest',
        inline: 'center',
      })
    }
  }

  const handlePrev = () => {
    if (currentIndex > 0) {
      const prevIndex = currentIndex - 1
      handleSelectRoom(rooms[prevIndex], prevIndex)
      scrollContainerRef.current?.children[prevIndex]?.scrollIntoView({
        behavior: 'smooth',
        block: 'nearest',
        inline: 'center',
      })
    }
  }

  if (loading) {
    return (
      <div className="h-screen w-full flex items-center justify-center bg-background">
        <div className="text-center">
          <div className="h-12 w-12 rounded-full border-4 border-muted border-t-primary animate-spin mx-auto mb-4" />
          <p className="text-muted-foreground">Memuat Live Streams...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="h-screen w-full bg-background overflow-hidden flex">
      {/* Main Stream View */}
      <div className="flex-1 relative overflow-hidden">
        {selectedRoom && (
          <div className="w-full h-full bg-black relative">
            {/* Video Player */}
            <div className="w-full h-full flex items-center justify-center bg-gradient-to-b from-black/50 to-black/80">
              {selectedRoom.streamUrl || selectedRoom.streamProxyUrl || selectedRoom.pullAddr || selectedRoom.pullUrl || selectedRoom.flvUrl ? (
                <div className="w-full h-full relative">
                  {/* FLV.js Video Player */}
                  <video
                    key={selectedRoom.id}
                    id={`video-${selectedRoom.id}`}
                    className="w-full h-full object-cover"
                    controls
                    autoPlay
                    muted
                  />
                  <script
                    dangerouslySetInnerHTML={{
                      __html: `
                        if (typeof flvjs !== 'undefined' && flvjs.isSupported()) {
                          const videoElement = document.getElementById('video-${selectedRoom.id}');
                          const flvPlayer = flvjs.createPlayer({
                            type: 'flv',
                            url: '${selectedRoom.streamUrl || selectedRoom.streamProxyUrl || selectedRoom.pullAddr || selectedRoom.pullUrl || selectedRoom.flvUrl}'
                          });
                          flvPlayer.attachMediaElement(videoElement);
                          flvPlayer.load();
                          flvPlayer.play();
                        } else {
                          // Fallback to standard video player
                          const videoElement = document.getElementById('video-${selectedRoom.id}');
                          if (videoElement) {
                            videoElement.src = '${selectedRoom.streamUrl || selectedRoom.streamProxyUrl || selectedRoom.pullAddr || selectedRoom.pullUrl || selectedRoom.flvUrl}';
                          }
                        }
                      `
                    }}
                  />
                </div>
              ) : (
                <div className="text-center">
                  <div className="text-6xl mb-4">📺</div>
                  <p className="text-foreground text-lg">Mengambil Stream...</p>
                  <p className="text-muted-foreground text-sm mt-2">Room: {selectedRoom.roomName}</p>
                  <p className="text-muted-foreground text-xs mt-4">
                    {selectedRoom.streamProxyUrl ? 'Stream proxy endpoint tersedia' : 'Menunggu stream URL...'}
                  </p>
                </div>
              )}
            </div>

            {/* Room Info Overlay */}
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black to-transparent p-6 text-foreground">
              <div className="flex items-end gap-4">
                {selectedRoom.anchorImg && (
                  <img
                    src={selectedRoom.anchorImg}
                    alt={selectedRoom.nickName}
                    className="h-16 w-16 rounded-full object-cover border-2 border-primary"
                  />
                )}
                <div className="flex-1">
                  <h2 className="text-xl font-bold">{selectedRoom.roomName}</h2>
                  <p className="text-sm text-muted-foreground">Oleh: {selectedRoom.nickName}</p>
                  <div className="flex items-center gap-2 mt-2">
                    <div className="h-2 w-2 rounded-full bg-destructive animate-pulse" />
                    <span className="text-sm font-semibold">{selectedRoom.onlineCount?.toLocaleString() || 0} Penonton</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Navigation Buttons */}
            <button
              onClick={handlePrev}
              disabled={currentIndex === 0}
              className="absolute left-4 top-1/2 -translate-y-1/2 h-12 w-12 rounded-full bg-black/50 hover:bg-black/70 disabled:opacity-30 text-white flex items-center justify-center transition-all"
            >
              <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
              </svg>
            </button>

            <button
              onClick={handleNext}
              disabled={currentIndex === rooms.length - 1}
              className="absolute right-4 top-1/2 -translate-y-1/2 h-12 w-12 rounded-full bg-black/50 hover:bg-black/70 disabled:opacity-30 text-white flex items-center justify-center transition-all"
            >
              <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </button>

            {/* Room Counter */}
            <div className="absolute top-4 right-4 bg-black/60 px-3 py-1 rounded-full text-sm text-foreground">
              {currentIndex + 1} / {rooms.length}
            </div>
          </div>
        )}
      </div>

      {/* Sidebar - Room List */}
      <div className="w-20 bg-card border-l border-border overflow-y-auto flex flex-col gap-2 p-2">
        <div
          ref={scrollContainerRef}
          className="flex-1 flex flex-col gap-2 overflow-y-auto"
        >
          {rooms.map((room, index) => (
            <button
              key={room.id}
              onClick={() => handleSelectRoom(room, index)}
              className={`h-16 rounded-lg overflow-hidden border-2 transition-all ${
                selectedRoom?.id === room.id
                  ? 'border-primary ring-2 ring-primary/50'
                  : 'border-transparent hover:border-border'
              }`}
            >
              {room.roomImg ? (
                <img
                  src={room.roomImg}
                  alt={room.roomName}
                  className="w-full h-full object-cover"
                />
              ) : room.anchorImg ? (
                <img
                  src={room.anchorImg}
                  alt={room.nickName}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full bg-gradient-to-br from-primary/50 to-accent/50 flex items-center justify-center">
                  <span className="text-xs font-bold text-center px-1 line-clamp-2">
                    {room.roomName}
                  </span>
                </div>
              )}
              {/* Live Badge */}
              <div className="absolute top-1 right-1 bg-destructive text-white text-xs px-1.5 py-0.5 rounded">
                Live
              </div>
            </button>
          ))}
        </div>

        {/* Refresh Button */}
        <button
          onClick={fetchLiveRooms}
          className="h-10 rounded-lg bg-primary text-primary-foreground hover:bg-primary/90 transition-all flex items-center justify-center"
          title="Refresh"
        >
          <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"
            />
          </svg>
        </button>
      </div>
    </div>
  )
}
