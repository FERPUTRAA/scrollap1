'use client';

import { useState } from 'react';
import { LogIn } from 'lucide-react';

interface LoginFormProps {
  onLoginSuccess: (credentials: any) => void;
}

export function LoginForm({ onLoginSuccess }: LoginFormProps) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    merchantId: '501',
    username: 'feyy',
    ac: '245689',
    authorization: 'Basic YXBwLXBsYXNlcjphcHB0bGF5ZXIyMDIxKjk2My4=',
    device: '08b55ddbd0debc1fa8cdc7127240d402',
    sign: '6952b8eeac35657a68664dd9a5674757',
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      // Test the credentials by making a request
      const response = await fetch('/api/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Login failed');
      }

      // Save to session/local storage
      localStorage.setItem('fsc_credentials', JSON.stringify(formData));
      onLoginSuccess(formData);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
      console.error('[v0] Login error:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="h-screen w-full bg-gradient-to-br from-gray-900 via-black to-gray-900 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-2 mb-4">
            <div className="w-12 h-12 bg-red-500 rounded-full flex items-center justify-center">
              <LogIn className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-white">Live Stream</h1>
          </div>
          <p className="text-gray-400">Sign in to watch live streams</p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Username */}
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Username
            </label>
            <input
              type="text"
              name="username"
              value={formData.username}
              onChange={handleChange}
              placeholder="Enter username"
              className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-red-500 focus:ring-1 focus:ring-red-500 transition"
              required
            />
          </div>

          {/* Merchant ID */}
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Merchant ID
            </label>
            <input
              type="text"
              name="merchantId"
              value={formData.merchantId}
              onChange={handleChange}
              placeholder="Merchant ID"
              className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-red-500 focus:ring-1 focus:ring-red-500 transition"
              required
            />
          </div>

          {/* AC */}
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              AC (Account ID)
            </label>
            <input
              type="text"
              name="ac"
              value={formData.ac}
              onChange={handleChange}
              placeholder="Account ID"
              className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-red-500 focus:ring-1 focus:ring-red-500 transition"
              required
            />
          </div>

          {/* Authorization */}
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Authorization Token
            </label>
            <input
              type="password"
              name="authorization"
              value={formData.authorization}
              onChange={handleChange}
              placeholder="Basic auth token"
              className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-red-500 focus:ring-1 focus:ring-red-500 transition"
              required
            />
          </div>

          {/* Device ID */}
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Device ID
            </label>
            <input
              type="text"
              name="device"
              value={formData.device}
              onChange={handleChange}
              placeholder="Device ID"
              className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-red-500 focus:ring-1 focus:ring-red-500 transition"
              required
            />
          </div>

          {/* Sign */}
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Sign (Signature)
            </label>
            <input
              type="text"
              name="sign"
              value={formData.sign}
              onChange={handleChange}
              placeholder="API signature"
              className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-red-500 focus:ring-1 focus:ring-red-500 transition"
              required
            />
          </div>

          {/* Error Message */}
          {error && (
            <div className="p-3 bg-red-500/20 border border-red-500/50 rounded-lg text-red-400 text-sm">
              {error}
            </div>
          )}

          {/* Submit Button */}
          <button
            type="submit"
            disabled={loading}
            className="w-full bg-red-500 hover:bg-red-600 disabled:bg-gray-600 text-white font-bold py-3 rounded-lg transition duration-200 flex items-center justify-center gap-2"
          >
            {loading ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                Logging in...
              </>
            ) : (
              <>
                <LogIn className="w-5 h-5" />
                Sign In
              </>
            )}
          </button>
        </form>

        {/* Footer */}
        <p className="text-center text-gray-500 text-xs mt-6">
          Your credentials are stored securely for this session
        </p>
      </div>
    </div>
  );
}
