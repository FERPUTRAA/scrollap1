'use client'

interface ServerStatusProps {
  health: number
  latency: number
}

export function ServerStatus({ health, latency }: ServerStatusProps) {
  const regions = [
    { name: 'US-East', status: 'online', latency: 15 },
    { name: 'EU-West', status: 'online', latency: 28 },
    { name: 'Asia-Pacific', status: 'online', latency: 45 },
    { name: 'SA-Brazil', status: 'online', latency: 52 },
  ]

  const getHealthColor = (value: number) => {
    if (value >= 95) return 'bg-accent'
    if (value >= 85) return 'bg-primary'
    return 'bg-destructive'
  }

  return (
    <div className="rounded-lg bg-card border border-border p-6">
      <h2 className="text-lg font-semibold mb-6 text-foreground">Server Status</h2>

      <div className="mb-6">
        <div className="flex items-center justify-between mb-2">
          <p className="text-sm text-muted-foreground">Overall Health</p>
          <span className="text-lg font-bold text-foreground">{health.toFixed(1)}%</span>
        </div>
        <div className="h-2 bg-muted rounded-full overflow-hidden">
          <div
            className={`h-full ${getHealthColor(health)} transition-all`}
            style={{ width: `${health}%` }}
          />
        </div>
      </div>

      <div className="space-y-3">
        <p className="text-xs text-muted-foreground uppercase tracking-wider font-medium">Regions</p>
        {regions.map((region, idx) => (
          <div key={idx} className="flex items-center justify-between py-2 px-3 rounded bg-secondary/30 border border-border/50">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-accent" />
              <span className="text-sm text-foreground">{region.name}</span>
            </div>
            <span className="text-xs text-muted-foreground">{region.latency}ms</span>
          </div>
        ))}
      </div>
    </div>
  )
}
