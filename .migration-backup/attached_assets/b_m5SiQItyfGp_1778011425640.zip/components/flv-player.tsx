'use client';

import { useEffect, useRef, useState } from 'react';

interface FlvPlayerProps {
  url: string;
  poster?: string;
  autoPlay?: boolean;
  /** Show native browser controls (default: false for TikTok full-screen mode) */
  controls?: boolean;
  className?: string;
  onError?: (msg: string) => void;
}

// flv.js has no published @types — use loose typing for runtime interop
/* eslint-disable @typescript-eslint/no-explicit-any */
export function FlvPlayer({
  url,
  poster,
  autoPlay = true,
  controls = false,
  className,
  onError,
}: FlvPlayerProps) {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [status, setStatus] = useState<'idle' | 'loading' | 'playing' | 'error'>(
    'loading',
  );
  const [errMsg, setErrMsg] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    let player: any = null;
    const video = videoRef.current;
    if (!video || !url) return;

    setStatus('loading');
    setErrMsg(null);

    // Route external FLV/M3U8 through our same-origin proxy so flv.js can
    // read the bytes (no CORS, no mixed-content). Local URLs pass through.
    const proxied =
      url.startsWith('/') || url.startsWith(window.location.origin)
        ? url
        : `/api/flv-proxy?url=${encodeURIComponent(url)}`;

    (async () => {
      try {
        const mod: any = await import('flv.js');
        const flvjs: any = mod.default ?? mod;
        if (cancelled) return;

        if (!flvjs.isSupported()) {
          video.src = proxied;
          video.play().catch(() => {
            setStatus('error');
            setErrMsg('Browser tidak mendukung FLV streaming');
            onError?.('FLV not supported');
          });
          return;
        }

        player = flvjs.createPlayer(
          {
            type: 'flv',
            url: proxied,
            isLive: true,
            cors: true,
            hasAudio: true,
            hasVideo: true,
          },
          {
            enableWorker: true,
            enableStashBuffer: false,
            stashInitialSize: 128,
            autoCleanupSourceBuffer: true,
          },
        );

        player.attachMediaElement(video);
        player.load();

        player.on(flvjs.Events.ERROR, (errType: string, errDetail: string) => {
          if (cancelled) return;
          const msg = `${errType}: ${errDetail}`;
          setStatus('error');
          setErrMsg(msg);
          onError?.(msg);
        });

        player.on(flvjs.Events.LOADING_COMPLETE, () => {
          if (!cancelled) setStatus('playing');
        });

        if (autoPlay) {
          try {
            await video.play();
            if (!cancelled) setStatus('playing');
          } catch {
            // Autoplay may be blocked — user click required
            if (!cancelled) setStatus('playing');
          }
        }
      } catch (e) {
        if (cancelled) return;
        const msg = e instanceof Error ? e.message : 'Unknown error';
        setStatus('error');
        setErrMsg(msg);
        onError?.(msg);
      }
    })();

    return () => {
      cancelled = true;
      try {
        player?.pause();
        player?.unload();
        player?.detachMediaElement();
        player?.destroy();
      } catch {
        // noop
      }
    };
  }, [url, autoPlay, onError]);

  return (
    <div className={`relative w-full h-full bg-black ${className ?? ''}`}>
      <video
        ref={videoRef}
        poster={poster}
        controls={controls}
        playsInline
        muted
        className="absolute inset-0 w-full h-full object-cover bg-black"
      />
      {status === 'loading' && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div className="w-10 h-10 border-4 border-red-500 border-t-transparent rounded-full animate-spin" />
        </div>
      )}
      {status === 'error' && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/80 text-white text-center p-4 text-sm">
          <div>
            <div className="font-bold text-red-400 mb-1">Stream gagal dimuat</div>
            <div className="text-xs text-gray-300 break-all">{errMsg}</div>
            <div className="text-xs text-gray-400 mt-2">
              Token mungkin sudah kedaluwarsa. Capture URL baru dari PCAPdroid.
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
