'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import Image from 'next/image'
import {
  Heart,
  MessageCircle,
  Share2,
  Eye,
  Play,
  X,
  RotateCw,
  Users,
  Radio,
  Search,
  ChevronUp,
  ShieldAlert,
  ExternalLink,
  FlaskConical,
} from 'lucide-react'
import { FlvPlayer } from './flv-player'

interface LiveRoom {
  id: string
  name: string
  viewers: number
  game: string
  cover: string
  avatar: string
  liveName: string
  streamPattern: string
  bauble: boolean
}

const PAGE_SIZE = 50
const AUTO_REFRESH_INTERVAL = 30_000

export function LiveStreamViewer() {
  const [rooms, setRooms] = useState<LiveRoom[]>([])
  const [totalRooms, setTotalRooms] = useState(0)
  const [loading, setLoading] = useState(true)
  const [loadingMore, setLoadingMore] = useState(false)
  const [listError, setListError] = useState<string | null>(null)
  const [apiErrorCode, setApiErrorCode] = useState<string | null>(null)
  const [activeRoom, setActiveRoom] = useState<LiveRoom | null>(null)
  const [searchQuery, setSearchQuery] = useState('')
  const [offset, setOffset] = useState(0)
  const [hasMore, setHasMore] = useState(true)
  const sentinelRef = useRef<HTMLDivElement | null>(null)
  const refreshTimerRef = useRef<ReturnType<typeof setInterval> | null>(null)

  const loadRooms = useCallback(
    async (currentOffset: number, append: boolean) => {
      try {
        if (append) setLoadingMore(true)
        else setLoading(true)

        // Try unified all-rooms endpoint first, fallback to paginated live
        let res = await fetch(
          `/api/all-rooms?limit=${PAGE_SIZE}&offset=${currentOffset}`,
        )
        let data = await res.json()

        if (!res.ok || !data.success) {
          // Surface IP_LIMIT error immediately — no point falling back
          if (data?.errorCode === 'IP_LIMIT' || data?.error?.startsWith?.('IP_LIMIT')) {
            setApiErrorCode('IP_LIMIT')
            setListError(data?.hint || 'Hot51 API memblokir IP server (IP_LIMIT). Set HOT51_PROXY_URL ke residential proxy Indonesia.')
            setHasMore(false)
            return
          }

          // Fallback to /api/live pagination
          const page = Math.floor(currentOffset / PAGE_SIZE) + 1
          res = await fetch(`/api/live?page=${page}&pageSize=${PAGE_SIZE}`)
          data = await res.json()

          if (!res.ok) {
            setApiErrorCode(data?.errorCode ?? null)
            setListError(data?.hint || data?.message || 'Gagal memuat live')
            setHasMore(false)
            return
          }

          const records = data?.data?.records ?? []
          const total = data?.data?.total ?? records.length

          const mapped: LiveRoom[] = records.map((r: any) => ({
            id: r.id,
            name: r.anchorNickname || 'Unknown',
            viewers: r.onlineCount ?? 0,
            game: r.gameName || '',
            cover: r.coverUrl || '',
            avatar: r.anchorAvatarUrl || r.coverUrl || '',
            liveName: r.liveName || '',
            streamPattern: `https://bcdn5.livcdn.com/live/501_${r.id}_auto.flv`,
            bauble: r.bauble ?? false,
          }))

          setRooms((prev) => {
            const merged = append ? [...prev, ...mapped] : mapped
            const seen = new Set<string>()
            return merged.filter((r) => {
              if (seen.has(r.id)) return false
              seen.add(r.id)
              return true
            })
          })
          setTotalRooms(total)
          setHasMore(records.length >= PAGE_SIZE && page * PAGE_SIZE < total)
          setListError(null)
          return
        }

        // Success from /api/all-rooms
        const roomList: LiveRoom[] = data.rooms ?? []
        setRooms((prev) => {
          const merged = append ? [...prev, ...roomList] : roomList
          const seen = new Set<string>()
          return merged.filter((r) => {
            if (seen.has(r.id)) return false
            seen.add(r.id)
            return true
          })
        })
        setTotalRooms(data.total ?? roomList.length)
        setHasMore(roomList.length >= PAGE_SIZE)
        setListError(null)
      } catch (err) {
        setListError(err instanceof Error ? err.message : 'Network error')
        setHasMore(false)
      } finally {
        setLoading(false)
        setLoadingMore(false)
      }
    },
    [],
  )

  // Initial load
  useEffect(() => {
    loadRooms(0, false)
  }, [loadRooms])

  // Auto-refresh every 30s
  useEffect(() => {
    refreshTimerRef.current = setInterval(() => {
      loadRooms(0, false)
      setOffset(0)
    }, AUTO_REFRESH_INTERVAL)
    return () => {
      if (refreshTimerRef.current) clearInterval(refreshTimerRef.current)
    }
  }, [loadRooms])

  // Infinite scroll
  useEffect(() => {
    if (!hasMore || loadingMore || loading) return
    const node = sentinelRef.current
    if (!node) return

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0]?.isIntersecting) {
          const nextOffset = offset + PAGE_SIZE
          setOffset(nextOffset)
          loadRooms(nextOffset, true)
        }
      },
      { rootMargin: '600px' },
    )
    observer.observe(node)
    return () => observer.disconnect()
  }, [hasMore, loadingMore, loading, offset, loadRooms])

  // Keyboard shortcuts
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement) return
      if (e.key === 'r' || e.key === 'R') {
        setOffset(0)
        loadRooms(0, false)
      }
      if (e.key === 'Escape' && activeRoom) {
        setActiveRoom(null)
      }
    }
    document.addEventListener('keydown', handler)
    return () => document.removeEventListener('keydown', handler)
  }, [loadRooms, activeRoom])

  const totalViewers = rooms.reduce((sum, r) => sum + r.viewers, 0)

  const filteredRooms = searchQuery
    ? rooms.filter(
        (r) =>
          r.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          r.id.includes(searchQuery) ||
          r.game.toLowerCase().includes(searchQuery.toLowerCase()),
      )
    : rooms

  if (loading && rooms.length === 0) {
    return (
      <div className="min-h-screen w-full bg-black flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-red-500 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <div className="text-white text-xl font-bold mb-2">
            Loading Live Streams
          </div>
          <div className="text-gray-500 text-sm">
            Fetching rooms from Hot51 API...
          </div>
        </div>
      </div>
    )
  }

  if (listError && rooms.length === 0) {
    const isCloudflare =
      apiErrorCode === 'IP_LIMIT' ||
      apiErrorCode === 'CLOUDFLARE_403' ||
      listError.includes('403') ||
      listError.includes('Cloudflare') ||
      listError.includes('IP_LIMIT') ||
      listError.includes('HOT51_PROXY_URL')

    return (
      <div className="min-h-screen w-full bg-black flex items-center justify-center p-4">
        <div className="max-w-lg w-full">
          {/* Error header */}
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-full bg-red-500/20 flex items-center justify-center flex-shrink-0">
              <ShieldAlert className="w-5 h-5 text-red-400" />
            </div>
            <div>
              <div className="text-white font-bold text-lg leading-tight">
                {apiErrorCode === 'IP_LIMIT'
                  ? 'IP server diblokir (IP_LIMIT)'
                  : isCloudflare
                  ? 'Hot51 API diblokir (Cloudflare 403)'
                  : 'Gagal memuat daftar live'}
              </div>
              <div className="text-gray-500 text-xs mt-0.5">
                {isCloudflare
                  ? 'IP Vercel masuk blacklist Hot51. Butuh residential proxy Indonesia.'
                  : listError}
              </div>
            </div>
          </div>

          {isCloudflare && (
            <div className="bg-white/5 border border-white/10 rounded-xl p-4 mb-4 space-y-4">
              {/* Step 1 */}
              <div>
                <div className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">
                  Langkah 1 — Siapkan proxy Indonesia
                </div>
                <div className="space-y-1.5 text-sm text-gray-300">
                  <div className="flex items-start gap-2">
                    <span className="w-5 h-5 rounded-full bg-blue-500/20 text-blue-400 text-[10px] font-bold flex items-center justify-center flex-shrink-0 mt-0.5">A</span>
                    <span>
                      <span className="text-white font-medium">Gratis:</span>{' '}
                      Oracle Cloud Free Tier di region{' '}
                      <code className="bg-white/10 px-1 rounded text-[11px]">ap-jakarta-1</code>{' '}
                      + Squid proxy
                    </span>
                  </div>
                  <div className="flex items-start gap-2">
                    <span className="w-5 h-5 rounded-full bg-amber-500/20 text-amber-400 text-[10px] font-bold flex items-center justify-center flex-shrink-0 mt-0.5">B</span>
                    <span>
                      <span className="text-white font-medium">Berbayar:</span>{' '}
                      Smartproxy / Bright Data / Oxylabs residential ID
                    </span>
                  </div>
                </div>
              </div>

              {/* Step 2 */}
              <div>
                <div className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">
                  Langkah 2 — Set environment variable
                </div>
                <div className="bg-black/60 rounded-lg p-3 font-mono text-xs text-green-400 space-y-1">
                  <div>HOT51_PROXY_URL=<span className="text-gray-300">http://user:pass@host:port</span></div>
                  <div className="text-gray-600"># atau socks5://user:pass@host:port</div>
                  <div className="text-gray-600"># atau http://host:port (tanpa auth)</div>
                </div>
                <div className="text-[11px] text-gray-500 mt-1.5">
                  Buka <span className="text-gray-300">Settings (pojok kanan atas) → Vars</span> untuk menambahkan env var.
                </div>
              </div>

              {/* Step 3 */}
              <div>
                <div className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">
                  Langkah 3 — Test koneksi
                </div>
                <div className="text-sm text-gray-300">
                  Setelah proxy di-set, buka{' '}
                  <a
                    href="/api/proxy-test"
                    target="_blank"
                    rel="noopener"
                    className="text-blue-400 hover:text-blue-300 underline inline-flex items-center gap-1"
                  >
                    /api/proxy-test
                    <ExternalLink className="w-3 h-3" />
                  </a>{' '}
                  untuk melihat laporan diagnostik.
                </div>
              </div>
            </div>
          )}

          {!isCloudflare && (
            <div className="bg-red-500/10 border border-red-500/20 rounded-xl p-3 mb-4 text-xs text-red-300 font-mono break-all">
              {listError}
            </div>
          )}

          <div className="flex gap-3">
            <button
              onClick={() => {
                setOffset(0)
                loadRooms(0, false)
              }}
              className="flex-1 bg-red-500 hover:bg-red-600 text-white px-4 py-2.5 rounded-lg font-semibold inline-flex items-center justify-center gap-2 transition-colors text-sm"
            >
              <RotateCw className="w-4 h-4" />
              Coba lagi
            </button>
            <a
              href="/api/proxy-test"
              target="_blank"
              rel="noopener"
              className="flex-shrink-0 bg-white/5 hover:bg-white/10 border border-white/10 text-gray-300 px-4 py-2.5 rounded-lg font-semibold inline-flex items-center gap-2 transition-colors text-sm"
            >
              <FlaskConical className="w-4 h-4" />
              Diagnostik
            </a>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen w-full bg-gradient-to-br from-slate-950 via-black to-slate-950 overflow-auto">
      {/* Header */}
      <header className="sticky top-0 z-30 bg-black/80 backdrop-blur-xl border-b border-white/5">
        <div className="max-w-7xl mx-auto px-4 py-3">
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-3 min-w-0">
              <div className="flex items-center gap-1.5">
                <Radio className="w-5 h-5 text-red-500" />
                <h1 className="text-white text-lg sm:text-xl font-bold whitespace-nowrap">
                  Live Directory
                </h1>
              </div>
              <div className="hidden sm:flex items-center gap-3 text-xs text-gray-500">
                <span className="flex items-center gap-1">
                  <span className="w-1.5 h-1.5 bg-red-500 rounded-full animate-pulse" />
                  Channel 501
                </span>
              </div>
            </div>

            <button
              onClick={() => {
                setOffset(0)
                loadRooms(0, false)
              }}
              disabled={loading}
              className="flex-shrink-0 bg-red-500/10 hover:bg-red-500/20 border border-red-500/30 text-red-400 px-3 py-1.5 rounded-full text-xs font-semibold inline-flex items-center gap-1.5 transition-colors"
            >
              <RotateCw
                className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`}
              />
              Refresh
            </button>
          </div>

          {/* Stats bar */}
          <div className="flex items-center gap-4 mt-2 pb-1 overflow-x-auto">
            <StatBadge
              icon={<Radio className="w-3.5 h-3.5" />}
              label="Total Rooms"
              value={totalRooms.toLocaleString('id-ID')}
              color="text-red-400"
            />
            <StatBadge
              icon={<Eye className="w-3.5 h-3.5" />}
              label="Loaded"
              value={rooms.length.toString()}
              color="text-blue-400"
            />
            <StatBadge
              icon={<Users className="w-3.5 h-3.5" />}
              label="Total Viewers"
              value={totalViewers.toLocaleString('id-ID')}
              color="text-green-400"
            />
          </div>

          {/* Search */}
          <div className="relative mt-2">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
            <input
              type="text"
              placeholder="Search by name, ID, or game..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-lg pl-9 pr-4 py-2 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-red-500/50 focus:ring-1 focus:ring-red-500/30 transition-colors"
            />
          </div>
        </div>
      </header>

      {/* Room Grid */}
      <main className="max-w-7xl mx-auto px-4 py-4">
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-2.5 sm:gap-3">
          {filteredRooms.map((room) => (
            <RoomCard
              key={room.id}
              room={room}
              onClick={() => setActiveRoom(room)}
            />
          ))}
        </div>

        {filteredRooms.length === 0 && !loading && (
          <div className="text-center py-20">
            <div className="text-gray-500 text-sm">
              {searchQuery
                ? `Tidak ada room yang cocok "${searchQuery}"`
                : 'Tidak ada room yang tersedia'}
            </div>
          </div>
        )}

        {/* Infinite scroll sentinel */}
        <div
          ref={sentinelRef}
          className="h-12 mt-4 flex items-center justify-center"
        >
          {loadingMore && (
            <div className="w-6 h-6 border-2 border-red-500 border-t-transparent rounded-full animate-spin" />
          )}
          {!hasMore && rooms.length > 0 && !searchQuery && (
            <div className="text-xs text-gray-600">Semua room dimuat</div>
          )}
        </div>
      </main>

      {/* Keyboard hint */}
      <div className="fixed bottom-4 right-4 z-10 hidden md:flex items-center gap-2 text-[10px] text-gray-600">
        <kbd className="bg-white/5 border border-white/10 px-1.5 py-0.5 rounded text-gray-400">
          R
        </kbd>
        <span>Refresh</span>
        <kbd className="bg-white/5 border border-white/10 px-1.5 py-0.5 rounded text-gray-400 ml-2">
          ESC
        </kbd>
        <span>Close</span>
      </div>

      {/* Player Modal */}
      {activeRoom && (
        <PlayerModal room={activeRoom} onClose={() => setActiveRoom(null)} />
      )}
    </div>
  )
}

function StatBadge({
  icon,
  label,
  value,
  color,
}: {
  icon: React.ReactNode
  label: string
  value: string
  color: string
}) {
  return (
    <div className="flex items-center gap-1.5 whitespace-nowrap">
      <span className={color}>{icon}</span>
      <span className="text-gray-500 text-xs">{label}</span>
      <span className={`text-xs font-bold ${color}`}>{value}</span>
    </div>
  )
}

function RoomCard({ room, onClick }: { room: LiveRoom; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="group relative aspect-[3/4] rounded-xl overflow-hidden bg-slate-900 text-left transition-transform hover:-translate-y-1 hover:shadow-2xl hover:shadow-red-500/10 focus:outline-none focus:ring-2 focus:ring-red-500/50"
    >
      {room.cover ? (
        <Image
          src={room.cover}
          alt={room.name}
          fill
          sizes="(min-width: 1280px) 16vw, (min-width: 1024px) 20vw, (min-width: 640px) 33vw, 50vw"
          className="object-cover transition-transform group-hover:scale-105"
          unoptimized
        />
      ) : (
        <div className="absolute inset-0 bg-gradient-to-br from-red-950 via-slate-900 to-black" />
      )}

      {/* Gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent" />

      {/* LIVE badge */}
      <div className="absolute top-2 left-2 flex items-center gap-1 bg-red-600 text-white px-1.5 py-0.5 rounded text-[10px] font-bold tracking-wide">
        <span className="w-1.5 h-1.5 bg-white rounded-full animate-pulse" />
        LIVE
      </div>

      {/* Viewer count */}
      <div className="absolute top-2 right-2 bg-black/60 backdrop-blur-sm text-white px-1.5 py-0.5 rounded text-[10px] font-semibold flex items-center gap-1">
        <Eye className="w-3 h-3" />
        {room.viewers.toLocaleString('id-ID')}
      </div>

      {/* Bauble/PW indicator */}
      {room.bauble && (
        <div className="absolute top-8 right-2 bg-amber-500/90 text-white px-1.5 py-0.5 rounded text-[9px] font-bold">
          PW
        </div>
      )}

      {/* Info */}
      <div className="absolute bottom-0 left-0 right-0 p-2.5">
        <div className="text-white text-xs sm:text-sm font-semibold truncate">
          {room.name}
        </div>
        {room.game && (
          <div className="text-gray-400 text-[10px] truncate mt-0.5">
            {room.game}
          </div>
        )}
      </div>

      {/* Hover play button */}
      <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
        <div className="w-12 h-12 rounded-full bg-red-500/80 flex items-center justify-center shadow-2xl backdrop-blur-sm">
          <Play className="w-6 h-6 text-white fill-white ml-0.5" />
        </div>
      </div>
    </button>
  )
}

function PlayerModal({
  room,
  onClose,
}: {
  room: LiveRoom
  onClose: () => void
}) {
  const [streamUrl, setStreamUrl] = useState<string | null>(null)
  const [resolving, setResolving] = useState(true)
  const [resolveError, setResolveError] = useState<string | null>(null)
  const [liked, setLiked] = useState(false)
  const [showDebug, setShowDebug] = useState(false)
  const [probes, setProbes] = useState<any[]>([])

  const resolve = useCallback(async () => {
    setResolving(true)
    setResolveError(null)
    setStreamUrl(null)
    setProbes([])

    // Try /api/room-stream (unified with all endpoint probing)
    try {
      const res = await fetch(
        `/api/room-stream?roomId=${encodeURIComponent(room.id)}`,
      )
      const data = await res.json()
      if (data.streamUrl) {
        setStreamUrl(data.streamUrl)
        setProbes(data.probes ?? [])
        setResolving(false)
        return
      }
    } catch {
      // continue to fallback
    }

    // Fallback: try /api/stream (legacy multi-probe)
    try {
      const res = await fetch(
        `/api/stream?roomId=${encodeURIComponent(room.id)}`,
      )
      const data = await res.json()
      if (data.streamUrl) {
        setStreamUrl(data.streamUrl)
        setProbes(data.probes ?? [])
        setResolving(false)
        return
      }
      setProbes(data.probes ?? [])
    } catch {
      // continue
    }

    setResolveError(
      'Tidak dapat menemukan URL stream untuk room ini. Stream mungkin sudah berakhir.',
    )
    setResolving(false)
  }, [room.id])

  useEffect(() => {
    resolve()
  }, [resolve])

  // Close on Escape
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose()
    }
    document.addEventListener('keydown', handler)
    return () => document.removeEventListener('keydown', handler)
  }, [onClose])

  return (
    <div
      className="fixed inset-0 z-50 bg-black flex flex-col"
      role="dialog"
      aria-label={`Live ${room.name}`}
    >
      {/* Header */}
      <header className="flex items-center justify-between px-4 py-3 border-b border-white/10 bg-black/80 backdrop-blur-md">
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-red-500 to-rose-600 flex items-center justify-center text-white font-bold flex-shrink-0 text-sm">
            {room.name?.charAt(0)?.toUpperCase() || 'L'}
          </div>
          <div className="min-w-0">
            <div className="text-white font-semibold truncate text-sm">
              {room.name}
            </div>
            <div className="text-xs text-red-400 font-medium flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 bg-red-500 rounded-full animate-pulse" />
              LIVE
              <span className="text-gray-500">
                {room.viewers.toLocaleString('id-ID')} viewers
              </span>
            </div>
          </div>
        </div>
        <button
          onClick={onClose}
          className="text-gray-400 hover:text-white p-2 hover:bg-white/10 rounded-full transition"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>
      </header>

      {/* Player area */}
      <main className="flex-1 flex items-center justify-center p-2 sm:p-4 overflow-hidden">
        <div className="w-full max-w-4xl aspect-[9/16] sm:aspect-video bg-black rounded-lg overflow-hidden relative">
          {resolving && (
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-3">
              <div className="w-10 h-10 border-4 border-red-500 border-t-transparent rounded-full animate-spin" />
              <div className="text-gray-400 text-sm">
                Mencari URL stream...
              </div>
            </div>
          )}

          {!resolving && resolveError && (
            <div className="absolute inset-0 flex flex-col items-center justify-center text-center px-6 gap-3">
              <div className="text-red-400 font-semibold text-sm">
                Stream tidak tersedia
              </div>
              <div className="text-xs text-gray-500 max-w-sm">
                {resolveError}
              </div>
              <button
                onClick={resolve}
                className="mt-2 inline-flex items-center gap-2 bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg text-xs font-semibold transition-colors"
              >
                <RotateCw className="w-3.5 h-3.5" />
                Coba lagi
              </button>
            </div>
          )}

          {!resolving && streamUrl && (
            <FlvPlayer url={streamUrl} poster={room.cover} />
          )}
        </div>
      </main>

      {/* Footer */}
      <footer className="px-4 py-2.5 border-t border-white/10 bg-black/80 backdrop-blur-md">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowDebug((v) => !v)}
              className="text-[10px] font-mono text-gray-600 hover:text-gray-400 transition-colors flex items-center gap-1"
            >
              Room: {room.id}
              <ChevronUp
                className={`w-3 h-3 transition-transform ${showDebug ? '' : 'rotate-180'}`}
              />
            </button>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setLiked((v) => !v)}
              className={`p-2 rounded-full hover:bg-white/10 transition ${
                liked ? 'text-red-500' : 'text-gray-400'
              }`}
              aria-label="Like"
            >
              <Heart
                className={`w-5 h-5 ${liked ? 'fill-red-500' : ''}`}
              />
            </button>
            <button
              className="p-2 rounded-full text-gray-400 hover:text-white hover:bg-white/10 transition"
              aria-label="Comment"
            >
              <MessageCircle className="w-5 h-5" />
            </button>
            <button
              className="p-2 rounded-full text-gray-400 hover:text-white hover:bg-white/10 transition"
              aria-label="Share"
            >
              <Share2 className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Debug probe results */}
        {showDebug && probes.length > 0 && (
          <div className="mt-2 max-h-32 overflow-auto rounded bg-white/5 p-2 text-[10px] font-mono text-gray-500">
            {probes.map((p: any, i: number) => (
              <div key={i} className="flex gap-2">
                <span
                  className={p.streamUrl ? 'text-green-400' : 'text-gray-600'}
                >
                  {p.endpoint}
                </span>
                <span className="text-gray-600">
                  {p.status ?? 'err'}
                </span>
                {p.streamUrl && (
                  <span className="text-green-400 truncate">
                    {p.streamUrl}
                  </span>
                )}
                {p.error && (
                  <span className="text-red-400 truncate">{p.error}</span>
                )}
              </div>
            ))}
          </div>
        )}
      </footer>
    </div>
  )
}
