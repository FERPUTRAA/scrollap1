'use client'

import { DeanurAnalytics } from './deanur-analytics'

export function GamingDashboard() {
  return <DeanurAnalytics />
}
