'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { FlvPlayer } from '@/components/flv-player'

// ─── Types matching /api/all-rooms response ───────────────────────────────────

interface Room {
  id: string
  name: string
  viewers: number
  game: string
  cover: string
  avatar: string
  liveName: string
  bauble: boolean
}

interface ApiResponse {
  success: boolean
  total?: number
  rooms?: Room[]
  cached?: boolean
  revalidating?: boolean
  proxyConfigured?: boolean
  error?: string
  errorCode?: string
  hint?: string
}

// ─── Main Feed ────────────────────────────────────────────────────────────────

export function Hot51Rooms() {
  const [rooms, setRooms] = useState<Room[]>([])
  const [total, setTotal] = useState(0)
  const [proxyConfigured, setProxyConfigured] = useState(false)
  const [error, setError] = useState<{ msg: string; hint?: string } | null>(null)
  const [loading, setLoading] = useState(true)
  const [activeIndex, setActiveIndex] = useState(0)
  const feedRef = useRef<HTMLDivElement>(null)

  // ── Fetch real room list from API ─────────────────────────────────────────
  const loadRooms = useCallback(async (silent = false) => {
    if (!silent) setError(null)
    try {
      const res = await fetch('/api/all-rooms?limit=50', { cache: 'no-store' })
      const data: ApiResponse = await res.json()
      if (!data.success) {
        if (!silent) {
          setError({
            msg: data.error ?? 'Gagal memuat ruangan',
            hint: data.hint,
          })
        }
        return
      }
      setRooms(data.rooms ?? [])
      setTotal(data.total ?? 0)
      setProxyConfigured(!!data.proxyConfigured)
    } catch (err) {
      if (!silent) setError({ msg: (err as Error).message })
    } finally {
      setLoading(false)
    }
  }, [])

  // Initial load + auto-refresh every 30s (silent so it doesn't flicker)
  useEffect(() => {
    loadRooms(false)
    const id = setInterval(() => loadRooms(true), 30_000)
    return () => clearInterval(id)
  }, [loadRooms])

  // ── Track active slide via IntersectionObserver ───────────────────────────
  useEffect(() => {
    const feed = feedRef.current
    if (!feed || rooms.length === 0) return
    const slides = feed.querySelectorAll<HTMLElement>('.tiktok-slide')
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) {
            const idx = Number((entry.target as HTMLElement).dataset.index)
            if (!isNaN(idx)) setActiveIndex(idx)
          }
        }
      },
      { root: feed, threshold: 0.6 },
    )
    slides.forEach((el) => observer.observe(el))
    return () => observer.disconnect()
  }, [rooms])

  const scrollTo = (idx: number) => {
    const feed = feedRef.current
    if (!feed) return
    const slide = feed.querySelector<HTMLElement>(`.tiktok-slide[data-index="${idx}"]`)
    slide?.scrollIntoView({ behavior: 'smooth' })
  }

  // ── Render ────────────────────────────────────────────────────────────────
  return (
    <>
      {/* Top nav — fixed */}
      <nav className="pointer-events-none fixed inset-x-0 top-0 z-40 flex items-center justify-between px-4 py-3">
        <div className="pointer-events-auto flex items-center gap-2 rounded-full bg-black/50 px-3 py-1.5 backdrop-blur-md">
          <span
            className={`h-2 w-2 rounded-full live-dot ${
              proxyConfigured ? 'bg-green-400' : 'bg-yellow-400'
            }`}
          />
          <span className="text-xs font-semibold text-white">
            {proxyConfigured ? 'Proxy Aktif' : 'Direct'}
          </span>
        </div>

        <div className="flex gap-6">
          <button className="pointer-events-auto text-sm font-bold text-white/50 transition hover:text-white">
            For You
          </button>
          <button className="pointer-events-auto border-b-2 border-white pb-0.5 text-sm font-bold text-white">
            Live
          </button>
        </div>

        <div className="pointer-events-auto rounded-full bg-black/50 px-3 py-1.5 backdrop-blur-md">
          <span className="text-xs font-semibold text-white tabular-nums">
            {loading ? '…' : total.toLocaleString('id-ID')} live
          </span>
        </div>
      </nav>

      {/* Loading skeleton */}
      {loading && rooms.length === 0 && (
        <div className="flex h-dvh items-center justify-center bg-background">
          <div className="flex flex-col items-center gap-3">
            <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
            <p className="text-sm text-muted-foreground">Memuat rooms dari Hot51…</p>
          </div>
        </div>
      )}

      {/* Error state — no mock fallback */}
      {error && rooms.length === 0 && (
        <div className="flex h-dvh flex-col items-center justify-center gap-4 bg-background px-8 text-center">
          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/20">
            <svg className="h-6 w-6 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </div>
          <p className="text-base font-semibold text-foreground">Tidak dapat terhubung</p>
          <p className="text-sm leading-relaxed text-muted-foreground">{error.msg}</p>
          {error.hint && (
            <p className="max-w-sm rounded-xl bg-secondary px-4 py-3 text-xs leading-relaxed text-muted-foreground">
              {error.hint}
            </p>
          )}
          <button
            onClick={() => loadRooms(false)}
            className="mt-2 rounded-full bg-primary px-6 py-2.5 text-sm font-bold text-primary-foreground transition active:scale-95"
          >
            Coba Lagi
          </button>
        </div>
      )}

      {/* TikTok vertical snap feed — all real data, no mock */}
      {rooms.length > 0 && (
        <div ref={feedRef} className="tiktok-feed">
          {rooms.slice(0, 50).map((room, idx) => (
            <FeedSlide
              key={room.id}
              room={room}
              index={idx}
              isActive={activeIndex === idx}
              onNext={() => scrollTo(Math.min(idx + 1, rooms.length - 1))}
              onPrev={() => scrollTo(Math.max(idx - 1, 0))}
            />
          ))}
        </div>
      )}
    </>
  )
}

// ─── Single Feed Slide ────────────────────────────────────────────────────────

function FeedSlide({
  room,
  index,
  isActive,
  onNext,
  onPrev,
}: {
  room: Room
  index: number
  isActive: boolean
  onNext: () => void
  onPrev: () => void
}) {
  const [playing, setPlaying] = useState(false)
  const [streamError, setStreamError] = useState<string | null>(null)

  // Auto-play when slide comes into view, stop when leaving
  useEffect(() => {
    if (isActive) {
      setPlaying(true)
      setStreamError(null)
    } else {
      setPlaying(false)
    }
  }, [isActive])

  return (
    <div
      className="tiktok-slide relative flex w-full overflow-hidden bg-black"
      data-index={index}
    >
      {/* ── Background: cover image when not playing, FLV when playing ── */}
      {playing ? (
        <div className="absolute inset-0">
          <FlvPlayer
            url={`/api/stream-proxy?roomId=${room.id}`}
            poster={room.cover || undefined}
            autoPlay
            className="absolute inset-0 h-full w-full"
            onError={(msg) => {
              setStreamError(msg)
              setPlaying(false)
            }}
          />
        </div>
      ) : room.cover ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img
          src={room.cover}
          alt={`Cover ${room.name}`}
          className="absolute inset-0 h-full w-full object-cover"
        />
      ) : (
        <div className="absolute inset-0 bg-gradient-to-br from-zinc-900 to-zinc-800" />
      )}

      {/* Gradients for readability */}
      <div className="tiktok-gradient-top pointer-events-none absolute inset-x-0 top-0 h-32" />
      <div className="tiktok-gradient-bottom pointer-events-none absolute inset-x-0 bottom-0 h-3/5" />

      {/* Tap-to-play overlay — only shown when NOT playing and no error */}
      {!playing && !streamError && (
        <button
          onClick={() => { setPlaying(true); setStreamError(null) }}
          className="absolute inset-0 flex items-center justify-center"
          aria-label="Putar live stream"
        >
          <div className="rounded-full bg-white/20 p-5 backdrop-blur-sm transition hover:bg-white/30 active:scale-95">
            <svg className="h-10 w-10 translate-x-0.5 text-white" fill="currentColor" viewBox="0 0 24 24">
              <path d="M8 5v14l11-7z" />
            </svg>
          </div>
        </button>
      )}

      {/* Stream error banner — real error from API/CDN, not mock */}
      {streamError && (
        <div className="absolute inset-x-4 top-20 rounded-xl bg-black/70 px-4 py-3 backdrop-blur-sm">
          <p className="text-center text-xs text-red-400">Stream gagal: {streamError}</p>
          <button
            onClick={() => { setStreamError(null); setPlaying(true) }}
            className="mx-auto mt-2 block rounded-full bg-primary px-4 py-1 text-xs font-bold text-white"
          >
            Coba lagi
          </button>
        </div>
      )}

      {/* ── Bottom-left: real streamer info from API ── */}
      <div className="absolute bottom-20 left-4 right-20 flex flex-col gap-2">
        {/* Live badge + real viewer count */}
        <div className="flex items-center gap-2">
          <span className="flex items-center gap-1.5 rounded-sm bg-primary px-2 py-0.5 text-xs font-bold uppercase text-white">
            <span className="live-dot h-1.5 w-1.5 rounded-full bg-white" />
            Live
          </span>
          {room.viewers > 0 && (
            <span className="rounded-full bg-black/50 px-2.5 py-0.5 text-xs font-semibold text-white backdrop-blur-sm">
              {room.viewers.toLocaleString('id-ID')} penonton
            </span>
          )}
        </div>

        {/* Streamer name from API */}
        <p className="text-balance text-lg font-bold leading-tight text-white drop-shadow-lg">
          {room.name}
        </p>

        {/* Live title from API */}
        {room.liveName && (
          <p className="line-clamp-2 text-sm leading-snug text-white/80 drop-shadow">
            {room.liveName}
          </p>
        )}

        {/* Game/category from API */}
        {room.game && (
          <div className="flex items-center gap-1.5">
            <svg className="h-3.5 w-3.5 text-white/70" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 5v2m0 4v2m0 4v2M5 5a2 2 0 00-2 2v3a2 2 0 110 4v3a2 2 0 002 2h14a2 2 0 002-2v-3a2 2 0 110-4V7a2 2 0 00-2-2H5z" />
            </svg>
            <span className="text-xs font-medium text-white/80">{room.game}</span>
          </div>
        )}

        {/* Room ID — real, from API */}
        <p className="font-mono text-[10px] text-white/30">{room.id}</p>
      </div>

      {/* ── Right sidebar action buttons ── */}
      <div className="absolute bottom-20 right-3 flex flex-col items-center gap-5">
        {/* Avatar with real image from API */}
        <div className="relative">
          <div className="h-11 w-11 overflow-hidden rounded-full border-2 border-white bg-zinc-800">
            {room.avatar ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                src={room.avatar}
                alt={room.name}
                className="h-full w-full object-cover"
              />
            ) : (
              <div className="flex h-full w-full items-center justify-center text-lg font-bold text-white">
                {room.name.charAt(0).toUpperCase()}
              </div>
            )}
          </div>
          <div className="absolute -bottom-2 left-1/2 -translate-x-1/2">
            <div className="flex h-5 w-5 items-center justify-center rounded-full bg-primary">
              <svg className="h-3 w-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M12 4v16m8-8H4" />
              </svg>
            </div>
          </div>
        </div>

        {/* Viewer count as like proxy (real data from API, no random) */}
        <div className="flex flex-col items-center gap-1">
          <div className="text-white drop-shadow-lg">
            <svg className="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
            </svg>
          </div>
          <span className="text-[11px] font-semibold text-white drop-shadow">
            {formatCount(room.viewers)}
          </span>
        </div>

        {/* Share — uses Web Share API */}
        <button
          onClick={() => {
            if (navigator.share) {
              navigator.share({
                title: `${room.name} - Hot51 Live`,
                text: room.liveName || `Tonton ${room.name} live di Hot51`,
                url: window.location.href,
              }).catch(() => {/* user cancelled */})
            }
          }}
          className="flex flex-col items-center gap-1 transition active:scale-90"
          aria-label="Bagikan"
        >
          <div className="text-white drop-shadow-lg">
            <svg className="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
            </svg>
          </div>
          <span className="text-[11px] font-semibold text-white drop-shadow">Bagikan</span>
        </button>
      </div>

      {/* Scroll hint arrows */}
      <div className="absolute bottom-4 left-1/2 flex -translate-x-1/2 flex-col items-center gap-1">
        {index > 0 && (
          <button
            onClick={onPrev}
            className="rounded-full p-1.5 text-white/40 transition hover:text-white"
            aria-label="Room sebelumnya"
          >
            <svg className="h-4 w-4 rotate-180" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
            </svg>
          </button>
        )}
        <button
          onClick={onNext}
          className="flex flex-col items-center text-white/40 transition hover:text-white"
          aria-label="Room berikutnya"
        >
          <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
          </svg>
          <span className="text-[10px] font-medium">Berikutnya</span>
        </button>
      </div>
    </div>
  )
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function formatCount(n: number): string {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`
  if (n >= 1_000) return `${(n / 1_000).toFixed(1)}K`
  return String(n)
}
