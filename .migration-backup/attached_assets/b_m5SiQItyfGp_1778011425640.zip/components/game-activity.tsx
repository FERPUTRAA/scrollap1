'use client'

import { useEffect, useState } from 'react'

interface Activity {
  id: string
  event: string
  time: string
  type: 'join' | 'finish' | 'error' | 'update'
}

export function GameActivity() {
  const [activities, setActivities] = useState<Activity[]>([])

  useEffect(() => {
    const initialActivities = [
      { id: '1', event: 'Player joined room #5430', time: 'now', type: 'join' as const },
      { id: '2', event: 'Game completed - 234 points', time: '2s ago', type: 'finish' as const },
      { id: '3', event: 'Server update deployed', time: '5s ago', type: 'update' as const },
      { id: '4', event: 'Player left room #5428', time: '8s ago', type: 'join' as const },
      { id: '5', event: 'Connection timeout (auto-reconnect)', time: '12s ago', type: 'error' as const },
    ]
    setActivities(initialActivities)

    const interval = setInterval(() => {
      const events = ['Player joined', 'Game completed', 'Player disconnected', 'Voice chat started', 'Gift received']
      const newActivity: Activity = {
        id: Math.random().toString(),
        event: events[Math.floor(Math.random() * events.length)],
        time: 'now',
        type: ['join', 'finish', 'error'][Math.floor(Math.random() * 3)] as any,
      }

      setActivities((prev) => [
        newActivity,
        ...prev.map((a) => ({
          ...a,
          time: a.time === 'now' ? '2s ago' : a.time.replace(/(\d+)s/, (match, p1) => `${parseInt(p1) + 1}s`),
        })),
      ].slice(0, 5))
    }, 4000)

    return () => clearInterval(interval)
  }, [])

  const getActivityColor = (type: string) => {
    switch (type) {
      case 'join': return 'bg-accent/10 border-accent/30 text-accent'
      case 'finish': return 'bg-primary/10 border-primary/30 text-primary'
      case 'error': return 'bg-destructive/10 border-destructive/30 text-destructive'
      case 'update': return 'bg-muted/20 border-muted/50 text-muted-foreground'
      default: return 'bg-card border-border text-foreground'
    }
  }

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'join': return '👤'
      case 'finish': return '✓'
      case 'error': return '⚠️'
      case 'update': return '⚙️'
      default: return '•'
    }
  }

  return (
    <div className="rounded-lg bg-card border border-border p-6">
      <h2 className="text-lg font-semibold mb-6 text-foreground">Live Activity</h2>
      <div className="space-y-2">
        {activities.map((activity) => (
          <div key={activity.id} className={`rounded-lg p-3 border ${getActivityColor(activity.type)}`}>
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-start gap-2 flex-1">
                <span className="text-base mt-0.5">{getActivityIcon(activity.type)}</span>
                <p className="text-sm text-foreground flex-1">{activity.event}</p>
              </div>
              <span className="text-xs text-muted-foreground whitespace-nowrap">{activity.time}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
