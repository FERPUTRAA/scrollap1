'use client'

import { useState, useEffect } from 'react'
import Image from 'next/image'

interface Room {
  id: string
  name: string
  type: string
  category: string
  viewers: number
  status: string
  streamer: string
  avatar: string
  thumbnail: string
  description: string
  buyIn: number
  maxPlayers: number
  currentPlayers: number
  language: string
  region: string
}

const GAME_TYPES = [
  { value: 'ALL', label: 'All Games' },
  { value: 'POKER', label: 'Poker' },
  { value: 'BLACKJACK', label: 'Blackjack' },
  { value: 'ROULETTE', label: 'Roulette' },
  { value: 'DRAGON_TIGER', label: 'Dragon Tiger' },
  { value: 'SICBO', label: 'Sic Bo' },
  { value: 'BACCARAT', label: 'Baccarat' },
  { value: 'SLOTS', label: 'Slots' },
  { value: 'GAME_SHOW', label: 'Game Show' },
  { value: 'LOTTERY', label: 'Lottery' },
  { value: 'CRYPTO_DICE', label: 'Crypto Dice' },
]

const REGIONS = [
  { value: 'ALL', label: 'All Regions' },
  { value: 'US-East', label: 'US East' },
  { value: 'EU-West', label: 'EU West' },
  { value: 'Asia-Pacific', label: 'Asia Pacific' },
  { value: 'SA-Brazil', label: 'South America' },
  { value: 'Global', label: 'Global' },
]

const SORT_OPTIONS = [
  { value: 'viewers', label: 'Most Popular' },
  { value: 'players', label: 'Most Players' },
  { value: 'newest', label: 'Newest' },
]

export function RoomsIndex() {
  const [rooms, setRooms] = useState<Room[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedType, setSelectedType] = useState('ALL')
  const [selectedRegion, setSelectedRegion] = useState('ALL')
  const [sortBy, setSortBy] = useState('viewers')
  const [selectedRoom, setSelectedRoom] = useState<Room | null>(null)

  useEffect(() => {
    const fetchRooms = async () => {
      try {
        setLoading(true)
        const params = new URLSearchParams()
        if (selectedType !== 'ALL') params.append('type', selectedType)
        if (selectedRegion !== 'ALL') params.append('region', selectedRegion)
        params.append('sortBy', sortBy)

        const response = await fetch(`/api/rooms?${params.toString()}`)
        const data = await response.json()
        setRooms(data.rooms)
      } catch (error) {
        console.error('Failed to fetch rooms:', error)
      } finally {
        setLoading(false)
      }
    }

    fetchRooms()
  }, [selectedType, selectedRegion, sortBy])

  return (
    <div className="min-h-screen bg-background text-foreground overflow-auto">
      {/* Header */}
      <header className="sticky top-0 z-40 border-b border-border bg-card/95 backdrop-blur">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <h1 className="text-2xl font-bold mb-4">Deanur Gaming Rooms</h1>
          <div className="text-sm text-muted-foreground mb-4">
            {rooms.length} rooms available • {rooms.reduce((sum, r) => sum + r.viewers, 0).toLocaleString()} watching
          </div>

          {/* Filters */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Type Filter */}
            <div>
              <label className="text-xs font-semibold text-muted-foreground mb-2 block">Game Type</label>
              <select
                value={selectedType}
                onChange={(e) => setSelectedType(e.target.value)}
                className="w-full bg-input border border-border rounded-lg px-3 py-2 text-sm text-foreground"
              >
                {GAME_TYPES.map((type) => (
                  <option key={type.value} value={type.value}>
                    {type.label}
                  </option>
                ))}
              </select>
            </div>

            {/* Region Filter */}
            <div>
              <label className="text-xs font-semibold text-muted-foreground mb-2 block">Region</label>
              <select
                value={selectedRegion}
                onChange={(e) => setSelectedRegion(e.target.value)}
                className="w-full bg-input border border-border rounded-lg px-3 py-2 text-sm text-foreground"
              >
                {REGIONS.map((region) => (
                  <option key={region.value} value={region.value}>
                    {region.label}
                  </option>
                ))}
              </select>
            </div>

            {/* Sort */}
            <div>
              <label className="text-xs font-semibold text-muted-foreground mb-2 block">Sort By</label>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="w-full bg-input border border-border rounded-lg px-3 py-2 text-sm text-foreground"
              >
                {SORT_OPTIONS.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-6 py-8">
        {loading ? (
          <div className="text-center py-12">
            <div className="inline-block">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
            </div>
            <p className="mt-4 text-muted-foreground">Loading rooms...</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {rooms.map((room) => (
              <div
                key={room.id}
                onClick={() => setSelectedRoom(room)}
                className="bg-card border border-border rounded-xl overflow-hidden hover:border-primary transition-colors cursor-pointer group"
              >
                {/* Thumbnail */}
                <div className="relative h-40 bg-secondary overflow-hidden">
                  <img
                    src={room.thumbnail}
                    alt={room.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  {/* Status Badge */}
                  <div className="absolute top-3 right-3 flex items-center gap-1 bg-accent/90 px-3 py-1 rounded-full text-xs font-bold text-accent-foreground">
                    <div className="w-2 h-2 rounded-full bg-current animate-pulse"></div>
                    LIVE
                  </div>
                  {/* Viewers Badge */}
                  <div className="absolute top-3 left-3 bg-black/60 px-3 py-1 rounded-full text-xs font-semibold text-white">
                    {room.viewers.toLocaleString()} watching
                  </div>
                </div>

                {/* Content */}
                <div className="p-4">
                  {/* Streamer Info */}
                  <div className="flex items-center gap-3 mb-3">
                    <img
                      src={room.avatar}
                      alt={room.streamer}
                      className="w-10 h-10 rounded-full"
                    />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold truncate">{room.streamer}</p>
                      <p className="text-xs text-muted-foreground">{room.language}</p>
                    </div>
                  </div>

                  {/* Room Name */}
                  <h3 className="font-bold text-base mb-2 line-clamp-2">{room.name}</h3>

                  {/* Room Type */}
                  <div className="flex items-center gap-2 mb-3">
                    <span className="text-xs font-semibold bg-primary/20 text-primary px-2 py-1 rounded">
                      {room.category}
                    </span>
                    <span className="text-xs text-muted-foreground">{room.region}</span>
                  </div>

                  {/* Stats */}
                  <div className="flex gap-4 text-xs text-muted-foreground mb-3 pb-3 border-b border-border">
                    <div>
                      <p className="font-semibold text-foreground">{room.currentPlayers}/{room.maxPlayers}</p>
                      <p>Players</p>
                    </div>
                    <div>
                      <p className="font-semibold text-foreground">${room.buyIn}</p>
                      <p>Buy-in</p>
                    </div>
                  </div>

                  {/* Join Button */}
                  <button className="w-full bg-primary text-primary-foreground py-2 rounded-lg font-semibold hover:opacity-90 transition-opacity text-sm">
                    Enter Room
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {!loading && rooms.length === 0 && (
          <div className="text-center py-12">
            <p className="text-muted-foreground mb-4">No rooms found matching your filters.</p>
            <button
              onClick={() => {
                setSelectedType('ALL')
                setSelectedRegion('ALL')
              }}
              className="text-primary hover:underline text-sm font-semibold"
            >
              Reset Filters
            </button>
          </div>
        )}
      </main>

      {/* Room Detail Modal */}
      {selectedRoom && (
        <div
          className="fixed inset-0 bg-black/80 backdrop-blur z-50 flex items-center justify-center p-4"
          onClick={() => setSelectedRoom(null)}
        >
          <div
            className="bg-card border border-border rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Thumbnail */}
            <div className="relative h-64 bg-secondary overflow-hidden">
              <img
                src={selectedRoom.thumbnail}
                alt={selectedRoom.name}
                className="w-full h-full object-cover"
              />
              <button
                onClick={() => setSelectedRoom(null)}
                className="absolute top-4 right-4 w-8 h-8 rounded-full bg-black/60 hover:bg-black/80 flex items-center justify-center"
              >
                <svg className="w-5 h-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>

            {/* Modal Content */}
            <div className="p-6">
              {/* Streamer */}
              <div className="flex items-center gap-4 mb-6">
                <img
                  src={selectedRoom.avatar}
                  alt={selectedRoom.streamer}
                  className="w-16 h-16 rounded-full"
                />
                <div>
                  <p className="text-lg font-bold">{selectedRoom.streamer}</p>
                  <p className="text-sm text-muted-foreground">{selectedRoom.language} • {selectedRoom.region}</p>
                </div>
              </div>

              {/* Room Info */}
              <h2 className="text-2xl font-bold mb-3">{selectedRoom.name}</h2>
              <p className="text-muted-foreground mb-6">{selectedRoom.description}</p>

              {/* Details Grid */}
              <div className="grid grid-cols-2 gap-4 mb-6">
                <div className="bg-secondary p-4 rounded-lg">
                  <p className="text-xs text-muted-foreground mb-1">Type</p>
                  <p className="font-bold">{selectedRoom.category}</p>
                </div>
                <div className="bg-secondary p-4 rounded-lg">
                  <p className="text-xs text-muted-foreground mb-1">Viewers</p>
                  <p className="font-bold">{selectedRoom.viewers.toLocaleString()}</p>
                </div>
                <div className="bg-secondary p-4 rounded-lg">
                  <p className="text-xs text-muted-foreground mb-1">Players</p>
                  <p className="font-bold">{selectedRoom.currentPlayers}/{selectedRoom.maxPlayers}</p>
                </div>
                <div className="bg-secondary p-4 rounded-lg">
                  <p className="text-xs text-muted-foreground mb-1">Buy-in</p>
                  <p className="font-bold">${selectedRoom.buyIn}</p>
                </div>
              </div>

              {/* Action Button */}
              <button className="w-full bg-primary text-primary-foreground py-3 rounded-lg font-bold text-lg hover:opacity-90 transition-opacity mb-3">
                Enter Room Now
              </button>
              <button
                onClick={() => setSelectedRoom(null)}
                className="w-full border border-border py-3 rounded-lg font-semibold hover:bg-secondary transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
