/**
 * GET /api/proxy-test
 *
 * Diagnostics endpoint — tests connectivity to Hot51 API
 * via each available method and returns a detailed report.
 * Open in browser or curl to debug proxy issues.
 */

import { NextResponse } from 'next/server'
import { ProxyAgent, fetch as undiciFetch } from 'undici'
import { buildHot51Headers, getProxyUrl, hasProxy, HOT51 } from '@/lib/hot51-config'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'
export const maxDuration = 30

// Exact URL from curl — query param ?room-Id= must be present
const TEST_URL =
  'https://api.fsccdn.com/501/api/plr/v3/public/live/room-index?room-Id='

const TIMEOUT_MS = 8_000

interface TestResult {
  method: string
  ok: boolean
  status?: number
  apiCode?: number
  apiError?: string
  responseSnippet?: string
  error?: string
  durationMs: number
}

async function testDirect(headers: Record<string, string>): Promise<TestResult> {
  const start = Date.now()
  try {
    const ctrl = new AbortController()
    const t = setTimeout(() => ctrl.abort(), TIMEOUT_MS)
    const res = await fetch(TEST_URL, {
      method: 'POST',
      headers,
      body: JSON.stringify({ area: 'ID', gameType: 0, offset: 0, limit: 1 }),
      signal: ctrl.signal,
    })
    clearTimeout(t)
    const text = await res.text()
    let apiCode: number | null = null
    let apiError: string | null = null
    try {
      const parsed = JSON.parse(text)
      apiCode = parsed?.code ?? null
      apiError = parsed?.data?.errorCode ?? parsed?.data?.localizedKey ?? null
    } catch { /* not JSON */ }
    const apiOk = apiCode === 0
    return {
      method: 'direct (no proxy)',
      ok: res.status === 200 && apiOk,
      status: res.status,
      apiCode: apiCode ?? undefined,
      apiError: apiError ?? undefined,
      responseSnippet: text.slice(0, 200),
      durationMs: Date.now() - start,
    }
  } catch (e) {
    return {
      method: 'direct (no proxy)',
      ok: false,
      error: (e as Error).message,
      durationMs: Date.now() - start,
    }
  }
}

async function testProxy(
  proxyUrl: string,
  headers: Record<string, string>,
): Promise<TestResult> {
  const start = Date.now()
  const label = proxyUrl.replace(/:[^@/]+@/, ':***@')
  try {
    const dispatcher = new ProxyAgent({
      uri: proxyUrl,
      connectTimeout: 5_000,
      headersTimeout: TIMEOUT_MS,
      bodyTimeout: TIMEOUT_MS,
    })
    const res = await undiciFetch(TEST_URL, {
      method: 'POST',
      headers,
      body: JSON.stringify({ area: 'ID', gameType: 0, offset: 0, limit: 1 }),
      dispatcher,
    })
    const text = await res.text()
    let apiCode: number | null = null
    let apiError: string | null = null
    try {
      const parsed = JSON.parse(text)
      apiCode = parsed?.code ?? null
      apiError = parsed?.data?.errorCode ?? parsed?.data?.localizedKey ?? null
    } catch { /* not JSON */ }
    const apiOk = apiCode === 0
    return {
      method: `proxy: ${label}`,
      ok: res.status === 200 && apiOk,
      status: res.status,
      apiCode: apiCode ?? undefined,
      apiError: apiError ?? undefined,
      responseSnippet: text.slice(0, 200),
      durationMs: Date.now() - start,
    }
  } catch (e) {
    return {
      method: `proxy: ${label}`,
      ok: false,
      error: (e as Error).message,
      durationMs: Date.now() - start,
    }
  }
}

export async function GET() {
  const headers = buildHot51Headers()
  const results: TestResult[] = []

  // Test 1: direct
  results.push(await testDirect(headers))

  // Test 2: configured proxy (if set)
  const proxyUrl = getProxyUrl()
  if (proxyUrl) {
    results.push(await testProxy(proxyUrl, headers))
  }

  const anyOk = results.some((r) => r.ok)
  const proxyConfigured = hasProxy()

  return NextResponse.json({
    timestamp: new Date().toISOString(),
    proxyConfigured,
    proxyUrl: proxyUrl
      ? proxyUrl.replace(/:[^@/]+@/, ':***@')
      : null,
    envVarsPresent: {
      HOT51_PROXY_URL: Boolean(process.env.HOT51_PROXY_URL),
      HOT51_MERCHANT_ID: Boolean(process.env.HOT51_MERCHANT_ID),
      HOT51_AUTHORIZATION: Boolean(process.env.HOT51_AUTHORIZATION),
      HOT51_PROXY_USER: Boolean(process.env.HOT51_PROXY_USER),
      HOT51_PROXY_PASS: Boolean(process.env.HOT51_PROXY_PASS),
    },
    results,
    summary: anyOk
      ? 'OK — API reachable and returned code:0.'
      : (() => {
          const ipLimit = results.some(r => r.apiError === 'IP_LIMIT' || r.apiError === 'G10001')
          if (ipLimit) return 'IP_LIMIT — Vercel IP diblokir oleh Hot51. Set HOT51_PROXY_URL ke residential proxy Indonesia di Settings → Vars.'
          if (proxyConfigured) return 'All methods failed — periksa format/kredensial HOT51_PROXY_URL dan coba lagi.'
          return 'All methods failed — Vercel IP diblokir (403). Set HOT51_PROXY_URL di Settings → Vars.'
        })(),
  })
}
