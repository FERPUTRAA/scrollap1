import { NextRequest, NextResponse } from 'next/server'
import { proxyFetch } from '@/lib/proxy-fetch'

export const runtime = 'nodejs'
export const maxDuration = 60

const HOT51_HEADERS: Record<string, string> = {
  merchantId: '501',
  Authorization: 'Basic YXBwLXBsYXNlcjphcHB0bGF5ZXIyMDIxKjk2My4=',
  'locale-language': 'ENU',
  device: '08b55ddbd0debc1fa8cdc7127240d402',
  area: 'ID',
  'dev-type': 'android_realme_RMX2030',
  'system-version': '10',
  versionCode: '999',
  'time-zone': 'GMT+07:00',
  username: 'feyy',
  ac: '245689',
  'client-type': '1',
  sign: '6952b8eeac35657a68664dd9a5674757',
  'Content-Type': 'application/x-www-form-urlencoded',
  'User-Agent': 'okhttp/4.10.0',
  'Accept-Encoding': 'gzip',
}

// Field names where stream URL may live (from LiveManager.smali)
const STREAM_FIELDS = [
  'pullAddr',
  'pullUrl',
  'pullFlvUrl',
  'flvUrl',
  'playUrl',
  'streamUrl',
  'rtmpUrl',
  'hlsUrl',
  'm3u8Url',
  'liveUrl',
  'cdnUrl',
  'url',
]

function extractStreamUrl(obj: unknown, depth = 0): string | null {
  if (!obj || typeof obj !== 'object' || depth > 6) return null
  const o = obj as Record<string, unknown>

  for (const key of STREAM_FIELDS) {
    const v = o[key]
    if (
      typeof v === 'string' &&
      /^https?:\/\//.test(v) &&
      /(\.flv|\.m3u8|rtmp:)/i.test(v)
    ) {
      return v
    }
  }

  // Check streamUrls object (common pattern)
  if (o.streamUrls && typeof o.streamUrls === 'object') {
    const su = o.streamUrls as Record<string, unknown>
    for (const v of Object.values(su)) {
      if (typeof v === 'string' && /^https?:\/\//.test(v)) {
        return v
      }
    }
  }

  for (const v of Object.values(o)) {
    if (v && typeof v === 'object') {
      const found = extractStreamUrl(v, depth + 1)
      if (found) return found
    }
  }
  return null
}

export async function GET(req: NextRequest) {
  const roomId = req.nextUrl.searchParams.get('roomId')
  if (!roomId) {
    return NextResponse.json({ error: 'Missing roomId parameter' }, { status: 400 })
  }

  // All endpoint candidates from LiveManager.smali + known API patterns
  const candidates = [
    {
      url: 'https://api.fsccdn.com/501/api/plr/v3/public/live/into-room',
      body: `roomId=${encodeURIComponent(roomId)}&liveId=${encodeURIComponent(roomId)}`,
    },
    {
      url: 'https://api.fsccdn.com/501/api/plr/v3/public/live/subscribe',
      body: `roomId=${encodeURIComponent(roomId)}`,
    },
    {
      url: 'https://api.fsccdn.com/501/api/plr/v3/public/live/room-detail',
      body: `roomId=${encodeURIComponent(roomId)}`,
    },
    {
      url: 'https://api.fsccdn.com/501/api/plr/v3/public/live/pull-addr',
      body: `roomId=${encodeURIComponent(roomId)}`,
    },
    {
      url: 'https://api.fsccdn.com/501/api/plr/v3/public/live/play-info',
      body: `roomId=${encodeURIComponent(roomId)}`,
    },
    {
      url: 'https://api.fsccdn.com/501/api/plr/v3/public/live/room-info',
      body: `roomId=${encodeURIComponent(roomId)}`,
    },
    {
      url: 'https://api.fsccdn.com/501/api/plr/v3/public/live/enter-room',
      body: `roomId=${encodeURIComponent(roomId)}`,
    },
    {
      url: 'https://api.fsccdn.com/501/api/plr/v3/public/live/play-url',
      body: `roomId=${encodeURIComponent(roomId)}`,
    },
    // Also try liveId as param name
    {
      url: 'https://api.fsccdn.com/501/api/plr/v3/public/live/into-room',
      body: `liveId=${encodeURIComponent(roomId)}`,
    },
    // JSON body attempt for room-info
    {
      url: 'https://api.fsccdn.com/501/api/plr/live/room-info',
      body: JSON.stringify({ roomId }),
      contentType: 'application/json',
    },
  ]

  const probes: Array<Record<string, unknown>> = []

  for (const c of candidates) {
    try {
      const headers = { ...HOT51_HEADERS }
      if ((c as any).contentType) {
        headers['Content-Type'] = (c as any).contentType
      }

      const { status, body } = await proxyFetch(c.url, {
        method: 'POST',
        headers,
        body: c.body,
      })

      let parsed: unknown = body
      try {
        parsed = JSON.parse(body)
      } catch {
        // keep as string
      }

      const streamUrl = extractStreamUrl(parsed)
      const endpoint = c.url.split('/').slice(-1)[0]
      probes.push({ endpoint, status, streamUrl, response: parsed })

      console.log('[v0] stream probe', endpoint, 'status', status, 'found:', !!streamUrl)

      if (streamUrl) {
        return NextResponse.json({
          ok: true,
          roomId,
          streamUrl,
          source: endpoint,
          probes,
        })
      }
    } catch (e) {
      probes.push({
        endpoint: c.url.split('/').slice(-1)[0],
        error: e instanceof Error ? e.message : String(e),
      })
    }
  }

  // Fallback: generate stream URL from known CDN pattern
  const txTime = Math.floor(Date.now() / 1000 + 7200)
    .toString(16)
    .toUpperCase()
  const fallbackUrl = `https://bcdn5.livcdn.com/live/501_${roomId}_auto.flv?txTime=${txTime}`

  return NextResponse.json({
    ok: true,
    roomId,
    streamUrl: fallbackUrl,
    source: 'pattern-fallback',
    message: 'No API returned stream URL, using CDN pattern fallback',
    probes,
  })
}
