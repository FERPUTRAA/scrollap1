import { NextResponse } from 'next/server'

// Indexed rooms from Deanur gaming platform
const DEANUR_ROOMS = [
  {
    id: 'room_1001',
    name: 'Poker Championship Hall',
    type: 'POKER',
    category: 'Card Games',
    viewers: 2547,
    status: 'LIVE',
    streamer: 'ProPlayer_Alpha',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=ProPlayer_Alpha',
    thumbnail: 'https://images.unsplash.com/photo-1516975080664-ed2fc6a32937?w=400&h=300&fit=crop',
    description: 'High stakes poker tournament with professional dealers',
    buyIn: 100,
    maxPlayers: 8,
    currentPlayers: 7,
    language: 'EN',
    region: 'US-East',
  },
  {
    id: 'room_1002',
    name: 'Roulette Spins Arena',
    type: 'ROULETTE',
    category: 'Table Games',
    viewers: 1892,
    status: 'LIVE',
    streamer: 'LuckySpinner',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=LuckySpinner',
    thumbnail: 'https://images.unsplash.com/photo-1570190772185-fc6f65f64804?w=400&h=300&fit=crop',
    description: 'Fast-paced roulette with live commentary',
    buyIn: 50,
    maxPlayers: 20,
    currentPlayers: 18,
    language: 'EN',
    region: 'EU-West',
  },
  {
    id: 'room_1003',
    name: 'Blackjack VIP Table',
    type: 'BLACKJACK',
    category: 'Card Games',
    viewers: 3421,
    status: 'LIVE',
    streamer: 'CardMaster_Elite',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=CardMaster_Elite',
    thumbnail: 'https://images.unsplash.com/photo-1551896369-40604a1492e2?w=400&h=300&fit=crop',
    description: 'Premium blackjack table with professional dealers',
    buyIn: 200,
    maxPlayers: 6,
    currentPlayers: 5,
    language: 'EN',
    region: 'Asia-Pacific',
  },
  {
    id: 'room_1004',
    name: 'Baccarat Lounge',
    type: 'BACCARAT',
    category: 'Card Games',
    viewers: 1345,
    status: 'LIVE',
    streamer: 'BaccaratPro',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=BaccaratPro',
    thumbnail: 'https://images.unsplash.com/photo-1516975080664-ed2fc6a32937?w=400&h=300&fit=crop',
    description: 'Classic baccarat with Asian betting style',
    buyIn: 150,
    maxPlayers: 12,
    currentPlayers: 9,
    language: 'ZH',
    region: 'Asia-Pacific',
  },
  {
    id: 'room_1005',
    name: 'Dragon Tiger Clash',
    type: 'DRAGON_TIGER',
    category: 'Table Games',
    viewers: 4821,
    status: 'LIVE',
    streamer: 'TigerMaster88',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=TigerMaster88',
    thumbnail: 'https://images.unsplash.com/photo-1516975080664-ed2fc6a32937?w=400&h=300&fit=crop',
    description: 'Fast card comparison game - Dragon vs Tiger',
    buyIn: 75,
    maxPlayers: 50,
    currentPlayers: 45,
    language: 'ZH',
    region: 'Asia-Pacific',
  },
  {
    id: 'room_1006',
    name: 'Sicbo Fortune Wheel',
    type: 'SICBO',
    category: 'Dice Games',
    viewers: 2156,
    status: 'LIVE',
    streamer: 'DiceMaster777',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=DiceMaster777',
    thumbnail: 'https://images.unsplash.com/photo-1516975080664-ed2fc6a32937?w=400&h=300&fit=crop',
    description: 'Traditional Sic Bo dice game with multiple betting options',
    buyIn: 60,
    maxPlayers: 30,
    currentPlayers: 28,
    language: 'ZH',
    region: 'Asia-Pacific',
  },
  {
    id: 'room_1007',
    name: 'Slot Machine Paradise',
    type: 'SLOTS',
    category: 'Machines',
    viewers: 5632,
    status: 'LIVE',
    streamer: 'SlotWinner99',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=SlotWinner99',
    thumbnail: 'https://images.unsplash.com/photo-1516975080664-ed2fc6a32937?w=400&h=300&fit=crop',
    description: 'Multiple themed slot machines with jackpot tracking',
    buyIn: 10,
    maxPlayers: 100,
    currentPlayers: 87,
    language: 'EN',
    region: 'Global',
  },
  {
    id: 'room_1008',
    name: 'Crypto Dice Arena',
    type: 'CRYPTO_DICE',
    category: 'Web3 Games',
    viewers: 1234,
    status: 'LIVE',
    streamer: 'CryptoDemon',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=CryptoDemon',
    thumbnail: 'https://images.unsplash.com/photo-1516975080664-ed2fc6a32937?w=400&h=300&fit=crop',
    description: 'Decentralized dice game with blockchain verification',
    buyIn: 0.001,
    maxPlayers: 50,
    currentPlayers: 34,
    language: 'EN',
    region: 'Global',
  },
  {
    id: 'room_1009',
    name: 'Live Game Show',
    type: 'GAME_SHOW',
    category: 'Entertainment',
    viewers: 8234,
    status: 'LIVE',
    streamer: 'HostMaster',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=HostMaster',
    thumbnail: 'https://images.unsplash.com/photo-1516975080664-ed2fc6a32937?w=400&h=300&fit=crop',
    description: 'Interactive game show with audience participation',
    buyIn: 5,
    maxPlayers: 1000,
    currentPlayers: 892,
    language: 'EN',
    region: 'Global',
  },
  {
    id: 'room_1010',
    name: 'Lottery Draw Show',
    type: 'LOTTERY',
    category: 'Games',
    viewers: 3456,
    status: 'LIVE',
    streamer: 'LotteryHost',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=LotteryHost',
    thumbnail: 'https://images.unsplash.com/photo-1516975080664-ed2fc6a32937?w=400&h=300&fit=crop',
    description: 'Daily lottery draw with live number picking',
    buyIn: 1,
    maxPlayers: 5000,
    currentPlayers: 4521,
    language: 'EN',
    region: 'Global',
  },
  {
    id: 'room_2001',
    name: 'Texas Hold\'em Masters',
    type: 'TEXAS_HOLDEM',
    category: 'Poker Variants',
    viewers: 3987,
    status: 'LIVE',
    streamer: 'PokerLegend',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=PokerLegend',
    thumbnail: 'https://images.unsplash.com/photo-1516975080664-ed2fc6a32937?w=400&h=300&fit=crop',
    description: 'Professional Texas Hold\'em tournament',
    buyIn: 500,
    maxPlayers: 9,
    currentPlayers: 8,
    language: 'EN',
    region: 'EU-West',
  },
  {
    id: 'room_2002',
    name: 'Omaha Hi-Lo Challenge',
    type: 'OMAHA',
    category: 'Poker Variants',
    viewers: 987,
    status: 'LIVE',
    streamer: 'OmahaExpert',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=OmahaExpert',
    thumbnail: 'https://images.unsplash.com/photo-1516975080664-ed2fc6a32937?w=400&h=300&fit=crop',
    description: 'Complex Omaha Hi-Lo game with split pots',
    buyIn: 250,
    maxPlayers: 8,
    currentPlayers: 6,
    language: 'EN',
    region: 'SA-Brazil',
  },
  {
    id: 'room_2003',
    name: 'Hi-Lo Stud Table',
    type: 'STUD',
    category: 'Poker Variants',
    viewers: 654,
    status: 'LIVE',
    streamer: 'StudPlayer',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=StudPlayer',
    thumbnail: 'https://images.unsplash.com/photo-1516975080664-ed2fc6a32937?w=400&h=300&fit=crop',
    description: 'Classic 7-Card Stud with community play',
    buyIn: 150,
    maxPlayers: 8,
    currentPlayers: 7,
    language: 'EN',
    region: 'US-East',
  },
]

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const type = searchParams.get('type')
  const region = searchParams.get('region')
  const status = searchParams.get('status') || 'LIVE'
  const sortBy = searchParams.get('sortBy') || 'viewers'

  let rooms = DEANUR_ROOMS

  // Filter by type
  if (type && type !== 'ALL') {
    rooms = rooms.filter((room) => room.type === type)
  }

  // Filter by region
  if (region && region !== 'ALL') {
    rooms = rooms.filter((room) => room.region === region || room.region === 'Global')
  }

  // Filter by status
  if (status && status !== 'ALL') {
    rooms = rooms.filter((room) => room.status === status)
  }

  // Sort
  if (sortBy === 'viewers') {
    rooms = rooms.sort((a, b) => b.viewers - a.viewers)
  } else if (sortBy === 'newest') {
    rooms = rooms.sort((a, b) => b.id.localeCompare(a.id))
  } else if (sortBy === 'players') {
    rooms = rooms.sort((a, b) => b.currentPlayers - a.currentPlayers)
  }

  return NextResponse.json({
    rooms,
    total: rooms.length,
    timestamp: new Date().toISOString(),
  })
}
