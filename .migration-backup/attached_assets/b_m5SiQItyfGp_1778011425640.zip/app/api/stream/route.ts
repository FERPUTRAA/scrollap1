import { NextRequest, NextResponse } from 'next/server';
import { proxyFetch } from '@/lib/proxy-fetch';

export const runtime = 'nodejs';
export const maxDuration = 60;

const HOT51_HEADERS: Record<string, string> = {
  merchantId: '501',
  Authorization: 'Basic YXBwLXBsYXNlcjphcHB0bGF5ZXIyMDIxKjk2My4=',
  'locale-language': 'ENU',
  device: '08b55ddbd0debc1fa8cdc7127240d402',
  area: 'ID',
  'dev-type': 'android_realme_RMX2030',
  'system-version': '10',
  versionCode: '999',
  'time-zone': 'GMT+07:00',
  username: 'feyy',
  ac: '245689',
  'client-type': '1',
  sign: '6952b8eeac35657a68664dd9a5674757',
  'Content-Type': 'application/json',
  'User-Agent': 'okhttp/4.10.0',
  'Accept-Encoding': 'gzip',
  // IP Spoof Indonesia
  'X-Forwarded-For': '103.147.31.122',
  'X-Real-IP': '114.125.1.242',
  'CF-Connecting-IP': '157.20.219.184',
};

// Common field names where stream URL may live (from LiveManager.smali: pullAddr, pullUrl)
const STREAM_FIELDS = [
  'pullAddr',
  'pullUrl',
  'pullFlvUrl',
  'flvUrl',
  'playUrl',
  'streamUrl',
  'rtmpUrl',
  'hlsUrl',
  'm3u8Url',
  'liveUrl',
  'cdnUrl',
  'url',
];

function extractStreamUrl(obj: unknown, depth = 0): string | null {
  if (!obj || typeof obj !== 'object' || depth > 6) return null;
  const o = obj as Record<string, unknown>;

  for (const key of STREAM_FIELDS) {
    const v = o[key];
    if (typeof v === 'string' && /^https?:\/\//.test(v) && /(\.flv|\.m3u8|rtmp:)/i.test(v)) {
      return v;
    }
  }

  for (const v of Object.values(o)) {
    if (v && typeof v === 'object') {
      const found = extractStreamUrl(v, depth + 1);
      if (found) return found;
    }
  }
  return null;
}

export async function GET(req: NextRequest) {
  const roomId = req.nextUrl.searchParams.get('roomId');
  if (!roomId) {
    return NextResponse.json({ error: 'roomId required' }, { status: 400 });
  }

  // Endpoint candidates derived from LiveManager.smali:
  // subscribeIntoRoom, initPullAddress, startPlay, pullAddr, liveId, roomId
  const candidates = [
    // Most likely: "into-room" or "subscribe" gives pullAddr
    {
      url: `https://api.fsccdn.com/501/api/plr/v3/public/live/into-room`,
      method: 'POST' as const,
      body: JSON.stringify({ roomId, liveId: roomId }),
    },
    {
      url: `https://api.fsccdn.com/501/api/plr/v3/public/live/subscribe`,
      method: 'POST' as const,
      body: JSON.stringify({ roomId }),
    },
    {
      url: `https://api.fsccdn.com/501/api/plr/v3/public/live/room-detail`,
      method: 'POST' as const,
      body: JSON.stringify({ roomId }),
    },
    {
      url: `https://api.fsccdn.com/501/api/plr/v3/public/live/pull-addr`,
      method: 'POST' as const,
      body: JSON.stringify({ roomId }),
    },
    {
      url: `https://api.fsccdn.com/501/api/plr/v3/public/live/play-info`,
      method: 'POST' as const,
      body: JSON.stringify({ roomId }),
    },
    {
      url: `https://api.fsccdn.com/501/api/plr/v3/public/live/room-info`,
      method: 'POST' as const,
      body: JSON.stringify({ roomId }),
    },
    {
      url: `https://api.fsccdn.com/501/api/plr/v3/public/live/enter-room`,
      method: 'POST' as const,
      body: JSON.stringify({ roomId }),
    },
    {
      url: `https://api.fsccdn.com/501/api/plr/v3/public/live/play-url`,
      method: 'POST' as const,
      body: JSON.stringify({ roomId }),
    },
  ];

  const probes: Array<Record<string, unknown>> = [];

  for (const c of candidates) {
    try {
      const { status, body } = await proxyFetch(c.url, {
        method: c.method,
        headers: HOT51_HEADERS,
        body: c.body,
      });
      let parsed: unknown = body;
      try {
        parsed = JSON.parse(body);
      } catch {
        // keep as string
      }
      const streamUrl = extractStreamUrl(parsed);
      const probe = {
        endpoint: c.url.split('/').slice(-1)[0],
        body: c.body,
        status,
        streamUrl,
        // Return full parsed response so we can see every field
        response: parsed,
      };
      probes.push(probe);
      console.log('[v0] probe', probe.endpoint, 'status', status, 'streamUrl', streamUrl);
      if (streamUrl) {
        return NextResponse.json({ ok: true, roomId, streamUrl, probes });
      }
    } catch (e) {
      probes.push({
        endpoint: c.url.split('/').slice(-1)[0],
        error: e instanceof Error ? e.message : String(e),
      });
    }
  }

  return NextResponse.json(
    { ok: false, roomId, streamUrl: null, probes },
    { status: 404 },
  );
}
