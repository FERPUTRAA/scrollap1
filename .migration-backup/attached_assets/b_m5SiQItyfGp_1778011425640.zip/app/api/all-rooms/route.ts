import { NextRequest, NextResponse } from 'next/server'
import { proxyFetch } from '@/lib/proxy-fetch'
import { buildHot51Headers, buildRoomIndexUrl, buildStreamUrl, hasProxy } from '@/lib/hot51-config'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'
export const maxDuration = 60

// Longer cache = fewer slow upstream hits. Auto-refresh on client is 30s,
// so 90s TTL means most refreshes are served instantly from cache.
const CACHE_TTL_MS = 90_000
// Stale-while-revalidate window — beyond this, we still serve stale on error
const STALE_TTL_MS = 5 * 60_000
let cachedData: { ts: number; data: RoomFetchResult } | null = null
let inflight: Promise<RoomFetchResult> | null = null

interface RoomRecord {
  id: string
  anchorNickname?: string
  onlineCount?: number
  gameName?: string
  coverUrl?: string
  anchorAvatarUrl?: string
  liveName?: string
  bauble?: boolean
}

interface ProcessedRoom {
  id: string
  name: string
  viewers: number
  game: string
  cover: string
  avatar: string
  liveName: string
  streamPattern: string
  bauble: boolean
}

interface RoomFetchResult {
  total: number
  rooms: ProcessedRoom[]
}

function mapRecord(room: RoomRecord): ProcessedRoom {
  return {
    id: room.id,
    name: room.anchorNickname || 'Unknown',
    viewers: room.onlineCount ?? 0,
    game: room.gameName || '',
    cover: room.coverUrl || '',
    avatar: room.anchorAvatarUrl || room.coverUrl || '',
    liveName: room.liveName || '',
    streamPattern: buildStreamUrl(room.id),
    bauble: room.bauble ?? false,
  }
}

async function fetchAllRooms(): Promise<RoomFetchResult> {
  const headers = buildHot51Headers()
  // Resolve API host via DNS TXT (same as APK DNSLookup.kt)
  const ROOM_INDEX_URL = await buildRoomIndexUrl()

  const requestBody = JSON.stringify({
    area: 'ID',
    gameType: 0,
    offset: 0,
    limit: 111110050,
    sortBy: 'onlineCount',
    sortOrder: 'desc',
  })

  // Primary: JSON body mass-fetch sorted by viewers (exact curl replica)
  const { status, body, proxyUsed } = await proxyFetch(ROOM_INDEX_URL, {
    method: 'POST',
    headers,
    body: requestBody,
  })

  console.log('[all-rooms] upstream via', proxyUsed, 'HTTP', status)

  let data: any
  try {
    data = JSON.parse(body)
  } catch {
    throw new Error(`Hot51 returned non-JSON (HTTP ${status}): ${body.slice(0, 200)}`)
  }

  // Hot51 uses code=200 for success (not 0). Any other code is an error.
  const apiCode: number = data?.code ?? 0
  if (apiCode !== 200) {
    const errorCode: string =
      data?.data?.errorCode ?? data?.data?.localizedKey ?? 'UNKNOWN'
    const localizedKey: string = data?.data?.localizedKey ?? ''

    if (localizedKey === 'IP_LIMIT' || errorCode === 'G10001' || apiCode === 10001) {
      throw new Error(`IP_LIMIT — Hot51 memblokir IP server Vercel (code: ${apiCode}). HOT51_PROXY_URL dibutuhkan.`)
    }
    throw new Error(`Hot51 API error code=${apiCode}: ${errorCode} — body: ${body.slice(0, 200)}`)
  }

  const records: RoomRecord[] = data?.data?.records ?? []
  const total: number = data?.data?.total ?? records.length

  return { total, rooms: records.map(mapRecord) }
}

export async function GET(req: NextRequest) {
  const { searchParams } = req.nextUrl
  const limit = Math.min(200, Math.max(1, parseInt(searchParams.get('limit') ?? '50', 10)))
  const offset = Math.max(0, parseInt(searchParams.get('offset') ?? '0', 10))

  try {
    const now = Date.now()
    const age = cachedData ? now - cachedData.ts : Infinity

    // Helper: kick off a background refresh (fire-and-forget, deduped)
    const triggerBackgroundRefresh = () => {
      if (inflight) return
      inflight = fetchAllRooms()
        .then((data) => {
          cachedData = { ts: Date.now(), data }
          return data
        })
        .catch((err) => {
          console.warn('[all-rooms] background refresh failed:', (err as Error).message)
          throw err
        })
        .finally(() => { inflight = null })
    }

    // Fresh cache → instant response
    if (cachedData && age < CACHE_TTL_MS) {
      const { total, rooms } = cachedData.data
      return NextResponse.json({
        success: true,
        total,
        rooms: rooms.slice(offset, offset + limit),
        cached: true,
        proxyConfigured: hasProxy(),
      })
    }

    // Stale cache → return it immediately, refresh in background (SWR)
    if (cachedData && age < STALE_TTL_MS) {
      triggerBackgroundRefresh()
      const { total, rooms } = cachedData.data
      return NextResponse.json({
        success: true,
        total,
        rooms: rooms.slice(offset, offset + limit),
        cached: true,
        revalidating: true,
        proxyConfigured: hasProxy(),
      })
    }

    // No cache or expired → must wait for upstream
    if (!inflight) {
      inflight = fetchAllRooms()
        .then((data) => {
          cachedData = { ts: Date.now(), data }
          return data
        })
        .finally(() => { inflight = null })
    }

    const { total, rooms } = await inflight
    return NextResponse.json({
      success: true,
      total,
      rooms: rooms.slice(offset, offset + limit),
      proxyConfigured: hasProxy(),
    })
  } catch (error) {
    const msg = error instanceof Error ? error.message : 'Unknown error'
    console.error('[all-rooms] error:', msg)

    // Serve stale cache on error
    if (cachedData) {
      const { total, rooms } = cachedData.data
      return NextResponse.json({
        success: true,
        total,
        rooms: rooms.slice(offset, offset + limit),
        stale: true,
        proxyConfigured: hasProxy(),
      })
    }

    const isIpLimit = msg.startsWith('IP_LIMIT') || msg.includes('IP_LIMIT')
    const isCloudflare = msg.includes('403') || msg.includes('Cloudflare')
    const needsProxy = isIpLimit || isCloudflare

    return NextResponse.json(
      {
        success: false,
        error: msg,
        errorCode: isIpLimit ? 'IP_LIMIT' : isCloudflare ? 'CLOUDFLARE_403' : 'FETCH_ERROR',
        proxyConfigured: hasProxy(),
        hint: needsProxy
          ? 'Hot51 API memblokir IP server Vercel (IP_LIMIT/403). Set HOT51_PROXY_URL ke residential proxy Indonesia di Settings → Vars.'
          : 'Terjadi kesalahan saat mengambil data. Coba lagi.',
      },
      { status: 502 },
    )
  }
}

export async function POST(req: NextRequest) {
  return GET(req)
}
