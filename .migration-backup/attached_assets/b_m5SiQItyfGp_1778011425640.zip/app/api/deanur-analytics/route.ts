import { NextRequest, NextResponse } from 'next/server'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'
export const maxDuration = 30

interface DeanurMetrics {
  timestamp: number
  activePlayers: number
  totalGames: number
  peakCCU: number
  avgLatency: number
  serverHealth: number
  regions: Array<{
    name: string
    status: 'online' | 'offline' | 'degraded'
    latency: number
    health: number
  }>
  recentActivity: Array<{
    id: string
    type: 'join' | 'leave' | 'complete' | 'error' | 'update'
    playerId: string
    gameId: string
    timestamp: number
    message: string
  }>
  playerStats: {
    newPlayers: number
    avgSessionDuration: number
    retentionRate: number
    dailyActiveUsers: number
  }
}

// Simulate Deanur gaming metrics based on repository data structure
function generateDeanurMetrics(): DeanurMetrics {
  const baseMetrics = {
    activePlayers: 2847 + Math.floor(Math.random() * 500),
    totalGames: 456 + Math.floor(Math.random() * 50),
    peakCCU: 5230 + Math.floor(Math.random() * 200),
    avgLatency: 32 + Math.floor(Math.random() * 20),
    serverHealth: 98.5 - Math.random() * 5,
  }

  const regions = [
    { 
      name: 'US-East', 
      status: Math.random() > 0.05 ? 'online' : 'degraded' as const,
      latency: 24 + Math.random() * 10,
      health: 95 + Math.random() * 5,
    },
    { 
      name: 'EU-West', 
      status: Math.random() > 0.03 ? 'online' : 'degraded' as const,
      latency: 28 + Math.random() * 15,
      health: 94 + Math.random() * 6,
    },
    { 
      name: 'Asia-Pacific', 
      status: Math.random() > 0.08 ? 'online' : 'degraded' as const,
      latency: 38 + Math.random() * 12,
      health: 92 + Math.random() * 8,
    },
    { 
      name: 'SA-Brazil', 
      status: Math.random() > 0.1 ? 'online' : 'degraded' as const,
      latency: 45 + Math.random() * 18,
      health: 90 + Math.random() * 9,
    },
  ]

  const activityTypes: Array<'join' | 'leave' | 'complete' | 'error' | 'update'> = [
    'join', 'leave', 'complete', 'error', 'update'
  ]
  
  const recentActivity = Array.from({ length: 10 }, (_, i) => ({
    id: `event-${Date.now()}-${i}`,
    type: activityTypes[Math.floor(Math.random() * activityTypes.length)],
    playerId: `player-${Math.floor(Math.random() * 1000)}`,
    gameId: `game-${Math.floor(Math.random() * 100)}`,
    timestamp: Date.now() - Math.random() * 60000,
    message: generateActivityMessage(),
  }))

  return {
    timestamp: Date.now(),
    ...baseMetrics,
    regions,
    recentActivity,
    playerStats: {
      newPlayers: 145 + Math.floor(Math.random() * 50),
      avgSessionDuration: 24.5 + Math.random() * 10,
      retentionRate: 72 + Math.random() * 15,
      dailyActiveUsers: 8234 + Math.floor(Math.random() * 500),
    },
  }
}

function generateActivityMessage(): string {
  const messages = [
    'Player joined game session',
    'Live stream started',
    'Game completed successfully',
    'Network latency spike detected',
    'Server maintenance scheduled',
    'New player registered',
    'Game session updated',
    'Player achievement unlocked',
    'Server health check passed',
    'Connection established',
  ]
  return messages[Math.floor(Math.random() * messages.length)]
}

export async function GET(req: NextRequest) {
  try {
    const metrics = generateDeanurMetrics()
    
    return NextResponse.json({
      success: true,
      data: metrics,
      cached: false,
      timestamp: new Date().toISOString(),
    }, {
      headers: {
        'Cache-Control': 'no-store, must-revalidate',
        'Content-Type': 'application/json',
      },
    })
  } catch (error) {
    console.error('[v0] Error generating Deanur analytics:', error)
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to fetch analytics',
        message: String(error),
      },
      { status: 500 }
    )
  }
}

export async function POST(req: NextRequest) {
  return GET(req)
}
