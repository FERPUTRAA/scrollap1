import { NextRequest } from 'next/server';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
export const maxDuration = 300;

/**
 * Streaming proxy for FLV (and m3u8 segments) live streams.
 *
 * Why: bcdn5.livcdn.com tidak mengirim CORS header, sehingga flv.js di browser
 * tidak bisa langsung membaca stream-nya. Kita pipe stream lewat server kita
 * (yang menambahkan Access-Control-Allow-Origin: *) tanpa buffering — bytes
 * langsung diteruskan ke client real-time.
 */
export async function GET(req: NextRequest) {
  const target = req.nextUrl.searchParams.get('url');
  if (!target) {
    return new Response('Missing ?url param', { status: 400 });
  }

  // Whitelist host untuk mencegah SSRF abuse.
  let parsed: URL;
  try {
    parsed = new URL(target);
  } catch {
    return new Response('Invalid url', { status: 400 });
  }
  const allowedHosts = [
    'livcdn.com',
    'fsccdn.com',
    'y3cdn.com',
    'tencent-cloud.com',
    'myqcloud.com',
  ];
  const hostOk = allowedHosts.some(
    (h) => parsed.hostname === h || parsed.hostname.endsWith('.' + h),
  );
  if (!hostOk) {
    return new Response('Host not allowed', { status: 403 });
  }

  console.log('[v0] flv-proxy fetching', parsed.hostname + parsed.pathname);

  // Fetch upstream — abort cleanly if client disconnects.
  const upstream = await fetch(target, {
    headers: {
      // Mimic mobile player so CDN doesn't 403
      'User-Agent':
        'Mozilla/5.0 (Linux; Android 10; RMX2030) AppleWebKit/537.36 ' +
        '(KHTML, like Gecko) Version/4.0 Chrome/91.0.4472.114 Mobile Safari/537.36',
      Accept: '*/*',
      'Accept-Encoding': 'identity', // disable gzip — FLV is binary
      Referer: 'https://api.fsccdn.com/',
    },
    cache: 'no-store',
    signal: req.signal,
  });

  if (!upstream.ok || !upstream.body) {
    return new Response(`Upstream error ${upstream.status}`, {
      status: upstream.status || 502,
    });
  }

  // Pass-through streaming response with CORS unlocked.
  const headers = new Headers();
  const ct = upstream.headers.get('content-type');
  if (ct) headers.set('Content-Type', ct);
  else if (parsed.pathname.endsWith('.flv'))
    headers.set('Content-Type', 'video/x-flv');
  else if (parsed.pathname.endsWith('.m3u8'))
    headers.set('Content-Type', 'application/vnd.apple.mpegurl');
  else if (parsed.pathname.endsWith('.ts'))
    headers.set('Content-Type', 'video/mp2t');

  headers.set('Access-Control-Allow-Origin', '*');
  headers.set('Access-Control-Allow-Methods', 'GET, OPTIONS');
  headers.set('Cache-Control', 'no-store, no-cache, must-revalidate');

  return new Response(upstream.body, {
    status: upstream.status,
    headers,
  });
}

export async function OPTIONS() {
  return new Response(null, {
    status: 204,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, OPTIONS',
      'Access-Control-Allow-Headers': '*',
    },
  });
}
