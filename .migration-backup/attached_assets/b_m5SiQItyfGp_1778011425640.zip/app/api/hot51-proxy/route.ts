import { NextRequest, NextResponse } from 'next/server'
import { proxyFetch } from '@/lib/proxy-fetch'
import { buildHot51Headers, buildRoomIndexUrl, buildStreamUrl } from '@/lib/hot51-config'

export const runtime = 'nodejs'
export const maxDuration = 60

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    // Resolve API host and build URL
    const roomIndexUrl = await buildRoomIndexUrl()

    // Build request body
    const requestBody = JSON.stringify({
      area: body.area || 'ID',
      gameType: body.gameType !== undefined ? body.gameType : 0,
      offset: body.offset || 0,
      limit: body.limit || 50,
      sortBy: body.sortBy || 'onlineCount',
      sortOrder: body.sortOrder || 'desc',
    })

    // Fetch with proxy
    const result = await proxyFetch(roomIndexUrl, {
      method: 'POST',
      headers: buildHot51Headers(),
      body: requestBody,
    })

    let data
    try {
      data = JSON.parse(result.body)
    } catch (e) {
      console.error('[v0] Failed to parse response:', result.body.slice(0, 200))
      return NextResponse.json(
        { success: false, error: 'Invalid JSON response from API' },
        { status: 500 }
      )
    }

    // Enhance rooms with stream URLs
    const roomsWithStreams = (data.data?.records || []).map((room: any) => ({
      ...room,
      // Stream URL pattern: https://bcdn5.livcdn.com/live/501_roomId_suffix.flv
      streamUrl: buildStreamUrl(room.id, 'auto'),
      // Local proxy endpoint for stream
      streamProxyUrl: `/api/stream?roomId=${room.id}`,
    }))

    return NextResponse.json({
      success: true,
      total: data.data?.total || 0,
      rooms: roomsWithStreams,
      message: data.message,
      proxyUsed: result.proxyUsed,
    })
  } catch (error: any) {
    console.error('[v0] Hot51 Proxy Error:', error.message)
    return NextResponse.json(
      {
        success: false,
        error: error.message || 'Failed to fetch live rooms',
      },
      { status: 500 }
    )
  }
}

export async function GET(request: NextRequest) {
  return POST(request)
}
