import { NextRequest, NextResponse } from 'next/server';
import { proxyFetch } from '@/lib/proxy-fetch';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
export const maxDuration = 60;

const CACHE_TTL_MS = 30_000;
const cacheByPage = new Map<string, { ts: number; data: unknown }>();
const inflightByPage = new Map<string, Promise<unknown>>();

async function fetchUpstream(page: number, pageSize: number): Promise<unknown> {
  const ac = '245689';
  const formBody =
    `ac=${ac}` +
    `&pageNo=${page}` +
    `&pageNum=${page}` +
    `&page=${page}` +
    `&pageSize=${pageSize}`;

  const { status, body, proxyUsed } = await proxyFetch(
    'https://api.fsccdn.com/501/api/plr/v3/public/live/room-index',
    {
      method: 'POST',
      headers: {
        merchantId: '501',
        Authorization: 'Basic YXBwLXBsYXNlcjphcHB0bGF5ZXIyMDIxKjk2My4=',
        'locale-language': 'ENU',
        device: '08b55ddbd0debc1fa8cdc7127240d402',
        area: 'ID',
        'dev-type': 'android_realme_RMX2030',
        'system-version': '10',
        versionCode: '999',
        'time-zone': 'GMT+07:00',
        username: 'feyy',
        ac,
        'client-type': '1',
        sign: '6952b8eeac35657a68664dd9a5674757',
        'Content-Type': 'application/x-www-form-urlencoded',
        'User-Agent': 'okhttp/4.10.0',
        'Accept-Encoding': 'gzip',
      },
      body: formBody,
    },
  );

  console.log('[v0] Upstream done via', proxyUsed, 'status', status, 'page', page);

  let data: unknown;
  try {
    data = JSON.parse(body);
  } catch {
    throw new Error(`Invalid JSON from upstream: ${body.slice(0, 200)}`);
  }
  return data;
}

export async function GET(req: NextRequest) {
  const page = Math.max(1, parseInt(req.nextUrl.searchParams.get('page') ?? '1', 10) || 1);
  const pageSize = Math.min(
    100,
    Math.max(10, parseInt(req.nextUrl.searchParams.get('pageSize') ?? '30', 10) || 30),
  );
  const key = `${page}:${pageSize}`;

  try {
    const cached = cacheByPage.get(key);
    if (cached && Date.now() - cached.ts < CACHE_TTL_MS) {
      console.log('[v0] Serving live page', key, 'from cache');
      return NextResponse.json(cached.data);
    }

    let pending = inflightByPage.get(key);
    if (!pending) {
      console.log('[v0] Fetching live page', key, 'from upstream');
      pending = fetchUpstream(page, pageSize)
        .then((data) => {
          cacheByPage.set(key, { ts: Date.now(), data });
          return data;
        })
        .finally(() => {
          inflightByPage.delete(key);
        });
      inflightByPage.set(key, pending);
    }

    const data = await pending;
    return NextResponse.json(data);
  } catch (error) {
    console.error('[v0] Error fetching live streams:', error);
    const stale = cacheByPage.get(key);
    if (stale) {
      console.log('[v0] Serving stale cache for', key);
      return NextResponse.json(stale.data);
    }
    return NextResponse.json(
      {
        error: 'upstream_blocked',
        message: String(error),
        hint:
          'Hot51 API memblokir IP server (Cloudflare 403). Set HOT51_PROXY_URL ke residential proxy Indonesia.',
      },
      { status: 502 },
    );
  }
}

export async function POST(req: NextRequest) {
  return GET(req);
}
