import { NextRequest, NextResponse } from 'next/server'
import { proxyFetch } from '@/lib/proxy-fetch'
import {
  buildHot51Headers,
  buildStreamHeaders,
  buildRoomInfoUrl,
  buildStreamUrl,
  hasProxy,
} from '@/lib/hot51-config'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'
export const maxDuration = 30

/**
 * Combined stream proxy:
 *   1. Resolve the live FLV/m3u8 URL for `roomId` via Hot51 room-info API
 *      (using the residential proxy / public proxy pool).
 *   2. Fall back to deterministic CDN URL pattern if API doesn't return one.
 *   3. Pipe the FLV bytes back to the browser with CORS unlocked, so flv.js
 *      can consume it without bcdn5.livcdn.com's missing CORS headers.
 */

const STREAM_FIELDS = [
  'pullAddr', 'pullUrl', 'pullFlvUrl', 'flvUrl', 'playUrl',
  'streamUrl', 'rtmpUrl', 'hlsUrl', 'm3u8Url', 'liveUrl', 'cdnUrl', 'url',
]

function extractStreamUrl(obj: unknown, depth = 0): string | null {
  if (!obj || typeof obj !== 'object' || depth > 6) return null
  const o = obj as Record<string, unknown>
  for (const key of STREAM_FIELDS) {
    const v = o[key]
    if (typeof v === 'string' && /^https?:\/\//.test(v) && /(\.flv|\.m3u8|rtmp:)/i.test(v)) {
      return v
    }
  }
  if (o.streamUrls && typeof o.streamUrls === 'object') {
    for (const v of Object.values(o.streamUrls as Record<string, unknown>)) {
      if (typeof v === 'string' && /^https?:\/\//.test(v)) return v
    }
  }
  for (const v of Object.values(o)) {
    if (v && typeof v === 'object') {
      const found = extractStreamUrl(v, depth + 1)
      if (found) return found
    }
  }
  return null
}

async function resolveStreamUrl(roomId: string): Promise<string> {
  // Build headers — form-urlencoded body for into-room endpoint
  const headers = {
    ...buildHot51Headers(),
    'Content-Type': 'application/x-www-form-urlencoded',
  }

  // DNS-resolved primary endpoint + hardcoded fallback candidates
  const primaryUrl = await buildRoomInfoUrl()
  const candidates = [
    primaryUrl,
    // Additional endpoints from APK (room-info, play-info variants)
    primaryUrl.replace('into-room', 'room-info'),
    primaryUrl.replace('into-room', 'play-info'),
    primaryUrl.replace('into-room', 'room-detail'),
  ]

  for (const url of candidates) {
    try {
      const { body } = await proxyFetch(url, {
        method: 'POST',
        headers,
        body: `roomId=${encodeURIComponent(roomId)}&liveId=${encodeURIComponent(roomId)}`,
      })
      const data = JSON.parse(body)
      const streamUrl = extractStreamUrl(data)
      if (streamUrl) {
        console.log('[stream-proxy] resolved via', url.split('/').pop(), '→', streamUrl)
        return streamUrl
      }
    } catch (err) {
      console.warn('[stream-proxy] candidate failed:', url, (err as Error).message)
    }
  }

  // Fallback: deterministic CDN pattern (txTime already embedded by buildStreamUrl)
  const fallback = buildStreamUrl(roomId)
  console.log('[stream-proxy] using pattern fallback →', fallback)
  return fallback
}

export async function GET(req: NextRequest) {
  const roomId = req.nextUrl.searchParams.get('roomId')
  if (!roomId) {
    return NextResponse.json({ error: 'Missing ?roomId param' }, { status: 400 })
  }

  let streamUrl: string
  try {
    streamUrl = await resolveStreamUrl(roomId)
  } catch (err) {
    const msg = (err as Error).message
    return NextResponse.json(
      {
        error: 'Failed to resolve stream URL',
        detail: msg,
        proxyConfigured: hasProxy(),
        hint: hasProxy()
          ? 'Proxy gagal kontak Hot51 API. Cek HOT51_PROXY_URL.'
          : 'Hot51 API memblokir IP server. Set HOT51_PROXY_URL ke residential proxy Indonesia.',
      },
      { status: 502 },
    )
  }

  // Pipe FLV stream → browser, with CORS unlocked
  let upstream: Response
  try {
    upstream = await fetch(streamUrl, {
      headers: buildStreamHeaders(),
      cache: 'no-store',
      signal: req.signal,
    })
  } catch (err) {
    return NextResponse.json(
      { error: 'Stream CDN unreachable', detail: (err as Error).message },
      { status: 502 },
    )
  }

  if (!upstream.ok || !upstream.body) {
    return NextResponse.json(
      { error: `Upstream CDN ${upstream.status}`, streamUrl },
      { status: upstream.status || 502 },
    )
  }

  const headers = new Headers()
  const ct = upstream.headers.get('content-type')
  if (ct) headers.set('Content-Type', ct)
  else if (streamUrl.includes('.m3u8')) headers.set('Content-Type', 'application/vnd.apple.mpegurl')
  else headers.set('Content-Type', 'video/x-flv')

  headers.set('Access-Control-Allow-Origin', '*')
  headers.set('Cache-Control', 'no-store, no-cache, must-revalidate')
  headers.set('X-Resolved-Stream', streamUrl)

  return new Response(upstream.body, { status: 200, headers })
}

export async function OPTIONS() {
  return new Response(null, {
    status: 204,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, OPTIONS',
    },
  })
}
