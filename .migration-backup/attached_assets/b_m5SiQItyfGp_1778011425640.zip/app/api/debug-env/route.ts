import { NextResponse } from 'next/server'
import { APP_KEY, APP_ID, APP_SIGN, MERCHANT_ID, resolveApiHost } from '@/lib/hot51-config'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

/**
 * Debug endpoint — shows Hot51 env vars (values masked) + smali constants.
 * Also runs DNS TXT resolution so you can verify host lookup.
 * GET /api/debug-env
 */
export async function GET() {
  const vars = [
    'HOT51_PROXY_URL',
    'HOT51_PROXY_USER',
    'HOT51_PROXY_PASS',
    'HOT51_MERCHANT_ID',
    'HOT51_AUTHORIZATION',
    'HOT51_DEVICE',
    'HOT51_USERNAME',
    'HOT51_AC',
    'HOT51_SIGN',
    'HOT51_STREAM_BASE',
    'HOT51_REFERER',
    'HOT51_USER_AGENT',
    'HOT51_RATE_LIMIT',
  ]

  const status: Record<string, string> = {}
  for (const key of vars) {
    const val = process.env[key]
    if (!val) {
      status[key] = 'NOT SET'
    } else if (key.includes('AUTHORIZATION') || key.includes('SIGN') || key.includes('PASS')) {
      status[key] = `SET (${val.length} chars)`
    } else if (key.includes('PROXY_URL')) {
      try {
        const u = new URL(val)
        status[key] = `SET → ${u.protocol}//${u.host}`
      } catch {
        status[key] = `SET (${val.length} chars)`
      }
    } else {
      status[key] = `SET → ${val}`
    }
  }

  // Run DNS TXT resolution and report result
  let dnsHost = '(not resolved yet)'
  let dnsError: string | null = null
  try {
    dnsHost = await resolveApiHost()
  } catch (e) {
    dnsError = (e as Error).message
  }

  return NextResponse.json({
    ok: true,
    env: status,
    smali: {
      APP_KEY: `${APP_KEY.slice(0, 8)}…(${APP_KEY.length} chars)`,
      APP_ID,
      APP_SIGN: `${APP_SIGN.slice(0, 12)}…(${APP_SIGN.length} chars)`,
      MERCHANT_ID,
    },
    dns: {
      resolvedHost: dnsHost,
      error: dnsError,
    },
    nodeVersion: process.version,
    timestamp: new Date().toISOString(),
  })
}
