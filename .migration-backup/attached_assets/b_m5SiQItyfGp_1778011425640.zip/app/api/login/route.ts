import { NextRequest, NextResponse } from 'next/server';
import { proxyFetch } from '@/lib/proxy-fetch';

export async function POST(request: NextRequest) {
  try {
    const credentials = await request.json();

    // Validate required credentials
    if (!credentials.merchantId || !credentials.username || !credentials.ac) {
      return NextResponse.json(
        { error: 'Missing required credentials' },
        { status: 400 }
      );
    }

    console.log('[v0] Login attempt via Indonesian proxy:', {
      merchantId: credentials.merchantId,
      username: credentials.username,
      ac: credentials.ac,
    });

    // Test API connection with the provided credentials
    const testResponse = await proxyFetch(
      'https://api.fsccdn.com/501/api/plr/v3/public/live/room-index',
      {
        method: 'POST',
        headers: {
          'merchantId': credentials.merchantId,
          'Authorization': credentials.authorization,
          'locale-language': 'ENU',
          'device': credentials.device,
          'area': 'ID',
          'dev-type': 'android_realme_RMX2030',
          'system-version': '10',
          'versionCode': '999',
          'time-zone': 'GMT+07:00',
          'username': credentials.username,
          'ac': credentials.ac,
          'client-type': '1',
          'sign': credentials.sign,
          'Content-Type': 'application/x-www-form-urlencoded',
          'User-Agent': 'okhttp/4.10.0',
          'Accept-Encoding': 'gzip',
        },
        body: `ac=${credentials.ac}`,
      }
    );

    let testData: unknown;
    try {
      testData = JSON.parse(testResponse.body);
    } catch {
      return NextResponse.json(
        { error: 'Invalid JSON from upstream', preview: testResponse.body.slice(0, 200) },
        { status: 502 }
      );
    }
    console.log('[v0] Login API response:', JSON.stringify(testData).slice(0, 200));

    if (testResponse.status >= 400) {
      return NextResponse.json(
        { error: 'Invalid credentials or API error', details: testData },
        { status: 401 }
      );
    }

    // Create response with credentials stored in session
    const response = NextResponse.json({
      success: true,
      message: 'Login successful',
      data: testData,
    });

    // Store credentials in HTTP-only cookie for security
    response.cookies.set({
      name: 'fsc_credentials',
      value: JSON.stringify(credentials),
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 7 * 24 * 60 * 60, // 7 days
    });

    return response;
  } catch (error) {
    console.error('[v0] Login error:', error);
    return NextResponse.json(
      {
        error: 'Login failed',
        details: error instanceof Error ? error.message : 'Unknown error',
      },
      { status: 500 }
    );
  }
}
