import { NextRequest, NextResponse } from 'next/server'

export const runtime = 'nodejs'
export const maxDuration = 60

// API Headers dari repository Solid - AppConfig.smali
const HEADERS = {
  'merchantId': '501',
  'Authorization': 'Basic YXBwLXBsYXNlcjphcHB0bGF5ZXIyMDIxKjk2My4=',
  'locale-language': 'ENU',
  'device': '08b55ddbd0debc1fa8cdc7127240d402',
  'area': 'ID',
  'dev-type': 'android_realme_RMX2030',
  'system-version': '10',
  'versionCode': '999',
  'time-zone': 'GMT+07:00',
  'username': 'feyy',
  'ac': '245689',
  'client-type': '1',
  'sign': '6952b8eeac35657a68664dd9a5674757',
  'Content-Type': 'application/json',
  'User-Agent': 'okhttp/4.10.0',
  // IP spoofing Indonesia untuk bypass geo-restriction
  'X-Forwarded-For': '103.147.31.122',
  'X-Real-IP': '114.125.1.242',
  'CF-Connecting-IP': '157.20.219.184',
}

async function fetchWithRetry(url: string, options: any, retries = 3): Promise<any> {
  for (let i = 0; i < retries; i++) {
    try {
      const controller = new AbortController()
      const timeoutId = setTimeout(() => controller.abort(), 15000)
      
      const response = await fetch(url, {
        ...options,
        signal: controller.signal,
      })
      
      clearTimeout(timeoutId)

      if (response.ok) {
        return response
      }
      
      // Retry on Cloudflare block
      if (response.status === 403 || response.status === 429) {
        console.log(`[v0] Cloudflare block detected (${response.status}), retrying...`)
        await new Promise(r => setTimeout(r, 2000 * (i + 1)))
        continue
      }
      
      return response
    } catch (error: any) {
      console.error(`[v0] Attempt ${i + 1} failed:`, error.message)
      if (i < retries - 1) {
        await new Promise(r => setTimeout(r, 2000 * (i + 1)))
      }
    }
  }
  
  throw new Error('All retries failed')
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { limit = 50, offset = 0, area = 'ID' } = body

    const payload = {
      area: area,
      gameType: 0,
      offset: offset,
      limit: limit,
      sortBy: 'onlineCount',
      sortOrder: 'desc',
    }

    console.log('[v0] Fetching live rooms from api.fsccdn.com...')

    // Main API endpoint dari AppConfig.smali
    const response = await fetchWithRetry(
      'https://api.fsccdn.com/501/api/plr/v3/public/live/room-index',
      {
        method: 'POST',
        headers: HEADERS,
        body: JSON.stringify(payload),
      }
    )

    const data = await response.json()

    console.log('[v0] API Response:', {
      status: response.status,
      success: data.code === 0,
      roomCount: data.data?.records?.length,
      total: data.data?.total,
    })

    if (data.code === 0 && data.data?.records) {
      // Transform response ke format frontend
      const rooms = data.data.records.map((room: any) => ({
        // Room ID dan basic info
        id: room.roomId || room.id,
        roomId: room.roomId || room.id,
        liveId: room.liveId,
        roomName: room.roomName,
        nickName: room.nickName || room.anchorName,
        anchorName: room.anchorName || room.nickName,
        
        // Image assets
        avatar: room.avatar,
        thumb: room.thumb,
        icon: room.icon,
        pic: room.pic,
        
        // Live stats
        onlineCount: room.onlineCount || 0,
        viewCount: room.viewCount || 0,
        followCount: room.followCount || 0,
        
        // Stream info
        streamUrl: buildStreamUrl(room.roomId || room.id, room.liveId),
        pullAddr: room.pullAddr,
        pullUrl: room.pullUrl,
        flvUrl: room.flvUrl,
        
        // Description
        description: room.description || room.desc || '',
        
        // Game type
        gameType: room.gameType,
        
        // Status
        isLive: room.isLive !== false,
      }))

      return NextResponse.json({
        code: 0,
        success: true,
        message: 'OK',
        data: {
          total: data.data.total,
          records: rooms,
        },
      })
    }

    // Error response dari API
    return NextResponse.json({
      code: data.code || -1,
      success: false,
      message: data.message || 'Failed to fetch rooms',
      error: data,
    })
  } catch (error: any) {
    console.error('[v0] Live rooms API error:', error.message)
    return NextResponse.json(
      {
        code: -1,
        success: false,
        message: error.message || 'Internal server error',
        error: error.message,
      },
      { status: 500 }
    )
  }
}

export async function GET(request: NextRequest) {
  return POST(request)
}

// Helper: Build stream URL sesuai pattern dari repository
function buildStreamUrl(roomId: string | number, liveId?: string | number): string {
  // Pattern dari Deanur repository:
  // https://bcdn5.livcdn.com/live/501_{ROOM_ID}_{STREAM_KEY}.flv
  const streamKey = '4ad75f5e2eb06d315ea14e8484a29e1d'
  return `https://bcdn5.livcdn.com/live/501_${roomId}_${streamKey}.flv`
}
