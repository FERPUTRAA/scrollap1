import { TikTokLiveReal } from '@/components/tiktok-live-real'

export const metadata = {
  title: 'Deanur Live - Real TikTok Style Live Streaming',
  description:
    'Real-time live streaming from Hot51 gaming platform. Watch professional live streams in TikTok-style interface with thousands of live rooms from Indonesia.',
}

export default function Home() {
  return <TikTokLiveReal />
}
