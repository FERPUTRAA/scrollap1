/**
 * hot51-config.ts
 *
 * All credentials sourced from APK smali (github.com/FERPUTRAA/Solid):
 *
 *  AppConfig.smali  → KEY="3b5949e0c26b87767a4752a276de9570", merchantId=501
 *  App.smali        → appID=0x3a121375 (976758645), appSign
 *  DNSLookup.smali  → host resolved via DNS TXT record (DNSSEC + AES decrypt)
 *  BuildConfig.smali→ APPLICATION_ID="com.tencent.thumbplayer.core.tpdownloadproxy"
 *
 * DNS strategy (from DNSLookup$updateHost$2.smali):
 *  - App queries DnssecResolverApi for TXT record of the domain
 *  - TXT value is AES-CBC encrypted with KEY, IV = first 16 bytes
 *  - Strip "https://" prefix after decrypt
 *  - We replicate this on the server and cache for 5 minutes
 */

import * as crypto from 'node:crypto'

// ── Smali-extracted constants ────────────────────────────────────────────────

/** From AppConfig.smali: KEY field = "3b5949e0c26b87767a4752a276de9570" */
export const APP_KEY = '3b5949e0c26b87767a4752a276de9570'

/** From App.smali: const-wide/32 v0, 0x3a121375 → appID */
export const APP_ID = 976758645

/** From App.smali: final const-string appSign (obfuscator kept last value) */
export const APP_SIGN =
  '968077d0acc44519d02de6d9c5ed7b0885479810224e9b3ac1c59d20dc25b009'

/** From AppConfig.smali flavor: "app_y501Release" → channel 501 */
export const MERCHANT_ID = process.env.HOT51_MERCHANT_ID ?? '501'

/** From env / APK BuildConfig */
export const PACKAGE_NAME =
  process.env.HOT51_PACKAGE ?? 'com.sagadsg.user.mady501857'
export const APP_VERSION = process.env.HOT51_VERSION ?? '1.1.586'

/** Known fallback API host (DNS cache miss) */
const FALLBACK_API_HOST = 'api.fsccdn.com'

/** Convenience re-export used by stream-proxy */
export const HOT51 = {
  MERCHANT_ID,
  REFERER: process.env.HOT51_REFERER ?? 'https://hot51.com',
  USER_AGENT: process.env.HOT51_USER_AGENT ?? 'okhttp/4.10.0',
  STREAM_BASE: process.env.HOT51_STREAM_BASE ?? 'https://bcdn5.livcdn.com/live',
  RATE_LIMIT: parseInt(process.env.HOT51_RATE_LIMIT ?? '100', 10),
} as const

// ── DNS TXT host resolver (mirrors DNSLookup$updateHost$2.smali) ─────────────

let _resolvedHost: string | null = null
let _resolvedAt = 0
const DNS_CACHE_MS = 5 * 60_000

/**
 * Decrypt AES-256-CBC TXT record value using APP_KEY.
 * Format: Base64( IV[16] + Ciphertext )
 */
function tryDecryptTxt(encrypted: string): string | null {
  try {
    const buf = Buffer.from(encrypted, 'base64')
    if (buf.length < 32) return null
    const iv = buf.subarray(0, 16)
    const ciphertext = buf.subarray(16)
    // KEY is 32 hex chars = 32 bytes (used as UTF-8 key, padded to 32 if shorter)
    const keyBuf = Buffer.from(APP_KEY.padEnd(32, '0').slice(0, 32), 'utf-8')
    const decipher = crypto.createDecipheriv('aes-256-cbc', keyBuf, iv)
    const plain = Buffer.concat([decipher.update(ciphertext), decipher.final()])
    return plain.toString('utf-8').replace(/\0+$/, '').trim()
  } catch {
    return null
  }
}

/**
 * Resolve live API host via DNS TXT lookup — same logic as DNSLookup.kt.
 * Falls back to FALLBACK_API_HOST on any error.
 */
export async function resolveApiHost(): Promise<string> {
  if (_resolvedHost && Date.now() - _resolvedAt < DNS_CACHE_MS) {
    return _resolvedHost
  }

  // Candidate domains for TXT record — channel 501
  const candidates = [
    `_dnsapi.${MERCHANT_ID}.fsccdn.com`,
    `_api.fsccdn.com`,
    `dns.${MERCHANT_ID}.fsccdn.com`,
  ]

  try {
    const dns = await import('node:dns/promises')
    for (const domain of candidates) {
      try {
        const records = await Promise.race([
          dns.resolveTxt(domain),
          new Promise<never>((_, rej) =>
            setTimeout(() => rej(new Error('DNS timeout')), 3_000),
          ),
        ])
        for (const parts of records as string[][]) {
          const txt = parts.join('')
          // Plain host (no spaces, has dots, short)
          if (txt.includes('.') && !txt.includes(' ') && txt.length < 100) {
            _resolvedHost = txt.replace(/^https?:\/\//, '')
            _resolvedAt = Date.now()
            console.log('[hot51-config] DNS TXT host (plain):', _resolvedHost)
            return _resolvedHost
          }
          // Encrypted TXT
          const decrypted = tryDecryptTxt(txt)
          if (decrypted?.includes('.')) {
            _resolvedHost = decrypted.replace(/^https?:\/\//, '')
            _resolvedAt = Date.now()
            console.log('[hot51-config] DNS TXT host (decrypted):', _resolvedHost)
            return _resolvedHost
          }
        }
      } catch {
        // next candidate
      }
    }
  } catch {
    // dns module not available (edge runtime)
  }

  _resolvedHost = FALLBACK_API_HOST
  _resolvedAt = Date.now()
  console.log('[hot51-config] DNS TXT fallback host:', _resolvedHost)
  return _resolvedHost
}

// ── Header builder (exact curl replica from APK) ─────────────────────────────

export function buildHot51Headers(
  extra?: Record<string, string>,
): Record<string, string> {
  // Read env fresh — never use module-level cached singleton
  const merchantId  = process.env.HOT51_MERCHANT_ID    ?? MERCHANT_ID
  const auth        = process.env.HOT51_AUTHORIZATION  ?? 'Basic YXBwLXBsYXNlcjphcHB0bGF5ZXIyMDIxKjk2My4='
  const device      = process.env.HOT51_DEVICE         ?? '08b55ddbd0debc1fa8cdc7127240d402'
  const username    = process.env.HOT51_USERNAME        ?? 'feyy'
  const ac          = process.env.HOT51_AC              ?? '245689'
  const sign        = process.env.HOT51_SIGN            ?? '6952b8eeac35657a68664dd9a5674757'
  const userAgent   = process.env.HOT51_USER_AGENT      ?? 'okhttp/4.10.0'

  return {
    // Headers extracted from APK curl captures — order preserved
    'merchantId':       merchantId,
    'Authorization':    auth,
    'locale-language':  'ENU',
    'device':           device,
    'area':             'ID',
    'dev-type':         'android_realme_RMX2030',
    'system-version':   '10',
    'versionCode':      '999',
    'time-zone':        'GMT+07:00',
    'username':         username,
    'ac':               ac,
    'client-type':      '1',
    'sign':             sign,
    'Content-Type':     'application/json',
    'User-Agent':       userAgent,
    'Accept-Encoding':  'gzip',
    'Accept':           '*/*',
    'Connection':       'Keep-Alive',
    ...extra,
  }
}

export function buildStreamHeaders(): Record<string, string> {
  return {
    'Referer':    process.env.HOT51_REFERER    ?? 'https://hot51.com',
    'Origin':     process.env.HOT51_REFERER    ?? 'https://hot51.com',
    'User-Agent': process.env.HOT51_USER_AGENT ?? 'okhttp/4.10.0',
    'Accept':     '*/*',
    'Accept-Encoding': 'identity',
  }
}

// ── URL builders ─────────────────────────────────────────────────────────────

export async function buildRoomIndexUrl(): Promise<string> {
  const host = await resolveApiHost()
  return `https://${host}/${MERCHANT_ID}/api/plr/v3/public/live/room-index`
}

export async function buildRoomInfoUrl(): Promise<string> {
  const host = await resolveApiHost()
  return `https://${host}/${MERCHANT_ID}/api/plr/v3/public/live/into-room`
}

/**
 * FLV pattern URL — from TPDownloadProxyEnum + stream config in APK.
 * txTime = expiry token = now + 2h in hex.
 */
export function buildStreamUrl(roomId: string, suffix = 'auto'): string {
  const base = process.env.HOT51_STREAM_BASE ?? 'https://bcdn5.livcdn.com/live'
  const txTime = Math.floor(Date.now() / 1000 + 7200).toString(16).toUpperCase()
  return `${base}/${MERCHANT_ID}_${roomId}_${suffix}.flv?txTime=${txTime}`
}

/** Whether a residential proxy is configured — reads env fresh */
export function hasProxy(): boolean {
  return Boolean(process.env.HOT51_PROXY_URL?.trim())
}

/** Get effective proxy URL — injects credentials if provided separately */
export function getProxyUrl(): string | null {
  const base = process.env.HOT51_PROXY_URL?.trim()
  if (!base) return null
  const user = process.env.HOT51_PROXY_USER?.trim() ?? ''
  const pass = process.env.HOT51_PROXY_PASS?.trim() ?? ''
  if (user && pass) {
    try {
      const u = new URL(base)
      if (!u.username) {
        u.username = encodeURIComponent(user)
        u.password = encodeURIComponent(pass)
        return u.toString()
      }
    } catch { /* leave as-is */ }
  }
  return base
}
