/**
 * proxyFetch — Hot51 API fetch using node-fetch + HttpsProxyAgent.
 *
 * Uses the exact same pattern as the original working spec:
 *   import fetch from 'node-fetch'
 *   import { HttpsProxyAgent } from 'https-proxy-agent'
 *   const agent = new HttpsProxyAgent(proxyUrl)
 *   fetch(url, { agent, headers })
 *
 * node-fetch v3 + HttpsProxyAgent is the only combination confirmed to work
 * with HTTP CONNECT tunneling proxies like http://157.20.219.184:5555.
 * native fetch / undici / raw node:https all handle agents differently and
 * can silently ignore the proxy or fail on CONNECT.
 *
 * env vars are read FRESH on every call — never cached at module level.
 */

import nodeFetch from 'node-fetch'
import { HttpsProxyAgent } from 'https-proxy-agent'
import { SocksProxyAgent } from 'socks-proxy-agent'

// ---------------------------------------------------------------------------
// Timeouts
// ---------------------------------------------------------------------------
const PROXY_TIMEOUT_MS  = 25_000
const DIRECT_TIMEOUT_MS = 8_000

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------
export interface FetchOptions {
  method?:  string
  headers?: Record<string, string>
  body?:    string
}

export interface ProxyResult {
  status:    number
  body:      string
  proxyUsed: string
}

// ---------------------------------------------------------------------------
// Rate limiter
// ---------------------------------------------------------------------------
const rateWindow: number[] = []
function checkRateLimit() {
  const now   = Date.now()
  const limit = parseInt(process.env.HOT51_RATE_LIMIT ?? '100', 10)
  while (rateWindow.length && rateWindow[0] < now - 60_000) rateWindow.shift()
  if (rateWindow.length >= limit) throw new Error(`Rate limit: ${limit} req/min exceeded.`)
  rateWindow.push(now)
}

// ---------------------------------------------------------------------------
// Block detection
// ---------------------------------------------------------------------------
function isBlocked(body: string, status: number): boolean {
  if (status === 403 || status === 429) return true
  if (body.includes('cdn-cgi/') || body.includes('Cloudflare')) return true
  if (body.trimStart().startsWith('<') && !body.includes('"code"')) return true
  return false
}

// ---------------------------------------------------------------------------
// Build effective proxy URL (merge separate credentials if any)
// ---------------------------------------------------------------------------
function buildProxyUrl(): string | null {
  const base = process.env.HOT51_PROXY_URL?.trim() ?? ''
  if (!base) return null

  const user = process.env.HOT51_PROXY_USER?.trim() ?? ''
  const pass = process.env.HOT51_PROXY_PASS?.trim() ?? ''
  if (user && pass) {
    try {
      const u = new URL(base)
      if (!u.username) {
        u.username = encodeURIComponent(user)
        u.password = encodeURIComponent(pass)
        return u.toString()
      }
    } catch { /* not a valid URL, use as-is */ }
  }
  return base
}

// ---------------------------------------------------------------------------
// Strategy 1 — node-fetch + proxy agent (proven working pattern)
// ---------------------------------------------------------------------------
async function fetchViaProxy(url: string, opts: FetchOptions): Promise<ProxyResult> {
  const proxyUrl = buildProxyUrl()
  if (!proxyUrl) throw new Error('HOT51_PROXY_URL tidak diset.')

  const isSocks = /^socks[45]?:\/\//i.test(proxyUrl)
  const agent   = isSocks
    ? new SocksProxyAgent(proxyUrl)
    : new HttpsProxyAgent(proxyUrl)

  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), PROXY_TIMEOUT_MS)

  try {
    const res = await nodeFetch(url, {
      method : opts.method ?? 'GET',
      headers: {
        ...(opts.headers ?? {}),
        ...(opts.body ? { 'Content-Length': String(Buffer.byteLength(opts.body, 'utf-8')) } : {}),
      },
      body   : opts.body,
      agent,
      signal : controller.signal as any,
    })

    const body   = await res.text()
    const status = res.status

    if (isBlocked(body, status)) {
      throw new Error(
        `Proxy ${proxyUrl} tidak bisa bypass Hot51 (HTTP ${status}). ` +
        `Gunakan residential proxy Indonesia.`
      )
    }

    return { status, body, proxyUsed: proxyUrl }
  } finally {
    clearTimeout(timer)
  }
}

// ---------------------------------------------------------------------------
// Strategy 2 — direct + Indonesian IP spoof headers (fallback, usually fails)
// ---------------------------------------------------------------------------
const ID_IPS = [
  '36.85.131.229', '114.125.45.100', '103.172.48.1',
  '140.213.0.1',   '182.253.109.23', '125.164.0.1',
  '118.98.0.1',    '180.244.132.105','202.67.40.15',
  '103.28.248.1',
]

async function fetchDirect(url: string, opts: FetchOptions): Promise<ProxyResult> {
  const ip = ID_IPS[Math.floor(Math.random() * ID_IPS.length)]

  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), DIRECT_TIMEOUT_MS)

  try {
    // Use node-fetch for direct too — consistent behavior
    const res = await nodeFetch(url, {
      method : opts.method ?? 'GET',
      headers: {
        ...(opts.headers ?? {}),
        'X-Forwarded-For' : ip,
        'X-Real-IP'       : ip,
        'CF-Connecting-IP': ip,
        'True-Client-IP'  : ip,
        ...(opts.body ? { 'Content-Length': String(Buffer.byteLength(opts.body, 'utf-8')) } : {}),
      },
      body  : opts.body,
      signal: controller.signal as any,
    })

    const body   = await res.text()
    const status = res.status

    if (isBlocked(body, status)) {
      throw new Error('Direct fetch diblokir Cloudflare (IP_LIMIT). Set HOT51_PROXY_URL.')
    }

    return { status, body, proxyUsed: 'direct' }
  } finally {
    clearTimeout(timer)
  }
}

// ---------------------------------------------------------------------------
// Main export
// ---------------------------------------------------------------------------
export async function proxyFetch(
  url: string,
  options: FetchOptions = {},
): Promise<ProxyResult> {
  checkRateLimit()

  const proxyUrl = buildProxyUrl()

  if (proxyUrl) {
    // Proxy configured — use it exclusively, fail-fast with clear message
    try {
      return await fetchViaProxy(url, options)
    } catch (err) {
      throw new Error(
        `HOT51_PROXY_URL (${proxyUrl}) gagal: ${(err as Error).message}`,
      )
    }
  }

  // No proxy — try direct (will fail on blocked IPs)
  try {
    return await fetchDirect(url, options)
  } catch (err) {
    throw new Error(
      `Tidak ada HOT51_PROXY_URL dan direct fetch gagal: ${(err as Error).message}. ` +
      `Set HOT51_PROXY_URL=http://157.20.219.184:5555 di Settings → Vars.`,
    )
  }
}
