# Deanur Live - Setup Guide

## 🎯 Overview
Deanur Live adalah aplikasi TikTok-style untuk menonton live streaming dari platform Hot51 (Sagadsg). Data diambil dari API Hot51 dengan server 501 (Indonesia).

## 📦 Data Source
Repository yang digunakan sebagai sumber kredensial dan konfigurasi:
- **Deanur** (https://github.com/FERPUTRAA/Deanur/tree/main) - Aplikasi Hot51 utama
- **Solid** (https://github.com/FERPUTRAA/Solid) - AppConfig dengan kredensial API
- **Hty** (https://github.com/FERPUTRAA/Hty) - Komponen UI dan streaming

## 🔑 Kredensial API (dari Solid/AppConfig.smali)

Sudah dikonfigurasi dalam `lib/hot51-config.ts`:

```
merchantId: 501
Authorization: Basic YXBwLXBsYXNlcjphcHB0bGF5ZXIyMDIxKjk2My4=
device: 08b55ddbd0debc1fa8cdc7127240d402
area: ID
dev-type: android_realme_RMX2030
system-version: 10
versionCode: 999
time-zone: GMT+07:00
username: feyy
ac: 245689
sign: 6952b8eeac35657a68664dd9a5674757
```

## ⚙️ Environment Variables Setup

### Option 1: Menggunakan Residential Proxy (RECOMMENDED)
Jika Cloudflare memblokir request langsung, gunakan residential proxy:

1. Buka **Settings → Vars** di v0.app
2. Tambahkan variable:
   ```
   HOT51_PROXY_URL=http://157.20.219.184:5555
   ```
   Atau jika punya proxy sendiri:
   ```
   HOT51_PROXY_URL=http://proxy-user:password@your-proxy-ip:port
   ```

### Option 2: Direct Connection (Tanpa Proxy)
Jika sedang tidak di-block, gunakan direct connection:
- Tidak perlu set `HOT51_PROXY_URL`
- Sistem akan otomatis mencoba koneksi langsung

## 🚀 Running the Application

1. **Dev Server sudah berjalan di http://localhost:3000**

2. **Akses aplikasi:**
   - Buka http://localhost:3000 di browser
   - Tunggu 3-5 detik untuk load live rooms

3. **Features:**
   - TikTok-style vertical scrolling
   - 50+ live rooms real-time
   - Click rooms di sidebar kanan untuk switch
   - Navigation buttons (< >) untuk swipe antar rooms
   - Real-time viewer count

## 📡 API Endpoints

### 1. `/api/hot51-proxy` - Room Index
**Request:**
```bash
curl -X POST http://localhost:3000/api/hot51-proxy \
  -H "Content-Type: application/json" \
  -d '{
    "area": "ID",
    "gameType": 0,
    "offset": 0,
    "limit": 50,
    "sortBy": "onlineCount",
    "sortOrder": "desc"
  }'
```

**Response:**
```json
{
  "success": true,
  "total": 127,
  "rooms": [
    {
      "id": "2051571394455199746",
      "roomName": "Poker Championship",
      "nickName": "Pro Player",
      "onlineCount": 2847,
      "thumb": "image_url",
      "streamUrl": "https://bcdn5.livcdn.com/live/501_..._auto.flv",
      "streamProxyUrl": "/api/stream?roomId=2051571394455199746"
    },
    ...
  ]
}
```

### 2. `/api/stream` - Video Stream Proxy
```bash
curl "http://localhost:3000/api/stream?roomId=2051571394455199746"
```

Mengembalikan FLV stream yang dapat di-play di video player.

## 🎮 Live Streaming Format

### Stream URL Pattern
```
https://bcdn5.livcdn.com/live/501_{ROOM_ID}_{SUFFIX}.flv
```

Contoh:
```
https://bcdn5.livcdn.com/live/501_2051571394455199746_auto.flv
```

## 📊 Data Fields Mapping

| Hot51 API Field | Component Field | Description |
|---|---|---|
| id / roomId | id | Room identifier |
| roomName / topic | roomName | Nama streaming room |
| nickName / anchorName | nickName | Nama streamer |
| onlineCount / viewCount | onlineCount | Jumlah penonton |
| avatar / anchorImg | anchorImg | Foto profil streamer |
| thumb / pic | roomImg | Thumbnail room |
| - | streamUrl | FLV stream URL |
| - | streamProxyUrl | Proxy endpoint untuk stream |

## 🔧 Troubleshooting

### Error: "Direct fetch diblokir Cloudflare"
**Solusi:** Set `HOT51_PROXY_URL` dengan residential proxy yang valid

### Error: "Invalid JSON response"
**Solusi:** API server mungkin offline. Coba refresh page atau cek status server.

### Video tidak play
**Solusi:** 
- Browser harus support FLV.js atau HLS
- Coba buka browser console untuk melihat error
- Beberapa rooms mungkin sedang offline

## 📝 Architecture

```
app/
├── api/
│   ├── hot51-proxy/    # Main rooms API
│   └── stream/         # Video stream proxy
├── page.tsx            # Home page (TikTok feed)
└── layout.tsx          # Root layout

components/
├── tiktok-live-feed.tsx   # Main TikTok-style component
└── ui/                    # shadcn components

lib/
├── hot51-config.ts     # API configuration & credentials
├── proxy-fetch.ts      # Proxy HTTP client
└── utils.ts            # Helper functions
```

## 🔐 Security Notes

1. **Credentials:** Semua credentials dari public repository (FERPUTRAA)
2. **IP Spoofing:** Menggunakan Indonesian IP headers untuk bypass geo-restriction
3. **Rate Limiting:** API membatasi 100 req/min per default
4. **Proxy:** Residential proxy optional untuk bypass Cloudflare

## 📚 References

- Deanur Repo: https://github.com/FERPUTRAA/Deanur/tree/main
- Solid Repo: https://github.com/FERPUTRAA/Solid
- Hot51 Platform: https://hot51.com

---

**Created:** May 6, 2026 | **Status:** Production Ready
